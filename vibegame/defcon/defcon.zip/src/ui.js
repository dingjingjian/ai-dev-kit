/*
 * defcon — ui.js
 * HUD 更新：顶栏（DEFCON / 危机值 / 阶段）、抽屉（阵营 / 图例 / 城市）、
 *          事件卡（危机博弈阶段的玩家决策入口）、两段式发射条、终局计分
 * 依赖：data.js → geo.js → sim.js（本文件在 render 之后加载）
 * 命名空间：window.DC（经典脚本，无 import/export/type=module）
 * 加载顺序：data.js → geo.js → sim.js → ai.js → render.js → ui.js → game.js
 *
 * 交互绑定一律走 addEventListener —— 小工具红线禁止 onclick= 行内事件（DESIGN §7.6）。
 * 本文件只负责「画」和「把点击翻译成意图」；意图通过 init 时传入的 cmd 回调交给 game.js 执行，
 * 因此 UI 不直接改游戏状态，无头测试也能绕过 DOM 直接测命令层。
 * 列表重建有节流：仅在内容签名变化时重排 DOM，避免每帧刷 DOM 拖垮帧率。
 *
 * ── 竖屏重构（Wave 3）─────────────────────────────────────────
 * 阵营与城市列表收进右侧抽屉，地球让出完整主视觉；常驻信息只剩顶栏一行四格 + 底部情境面板。
 * 核弹不可逆，所以发射必须是两段式：先选目标（点地球 / 点城市行），再按「发 射」确认。
 * 唯一的例外是「已选中目标后再点一次同一目标」—— 两次有意的点击等价于确认，
 * 既保留防误触，又不逼玩家在小屏上把手指从地球挪到底部按钮。
 */
(function (global) {
  'use strict';
  var DC = global.DC = global.DC || {};
  var CONFIG = DC.CONFIG || {};
  var S = DC.sim;

  var el = {};
  var cmd = {};
  var cur = null;                 // 最近一次 update 的 state，供行点击回调判断当前阶段
  var pending = null;             // 已选定但未发射的目标城市 id（两段式发射的第一段）
  var salvo = 1;                  // 单次发射枚数：1 或 3（齐射）
  var bound = false;              // 事件只绑一次：init 若被重入不会叠加出双份监听
  var sig = { factions: '', cities: '', card: '', choice: -2, war: -1, over: false,
              dc: 0, impacts: 0, target: null, fireOk: null, tip: '', sheet: null, tone: '' };

  var PHASE_NAME = {
    briefing: '态势简报', crisis: '危机博弈', war: '热核战争', over: '终局'
  };

  // 事件卡附加效果的中文说明（与 sim.applyEffects 的实现一一对应）
  var EFFECT_TEXT = {
    reveal_radar: '暴露全部敌方雷达',
    expose_silo: '暴露己方全部发射井',
    radar_down: '己方预警网失效',
    pop_loss: '己方规模受损',
    city_defense: '己方城市获得防御层',
    add_radar: '己方增建雷达',
    add_sam: '己方增建防空',
    add_missiles: '己方补充核弹',
    boost_pop: '己方规模回升',
    intel_city: '获取敌方城市情报',
    degrade_facility: '削弱敌方设施',
    destroy_facility: '摧毁敌方设施'
  };

  /* §11.9 城市列表军事单位改用图例图形 × 数量，复用 index.html 图例区的 SVG path。
   * 内联 SVG 在 HTML5 里无需 xmlns，红线扫描不会误判为外部 URL。
   * 图形与图例区一一对应：发射井六边形 / 防空三角形 / 雷达椭圆+竖线。 */
  var SVG_SILO = '<svg width="11" height="11" viewBox="0 0 12 12"><polygon points="6,1 10.3,3.5 10.3,8.5 6,11 1.7,8.5 1.7,3.5" fill="rgba(127,212,232,.22)" stroke="#7fd4e8" stroke-width="1"/></svg>';
  var SVG_SAM = '<svg width="11" height="11" viewBox="0 0 12 12"><polygon points="6,1.5 10.5,10.5 1.5,10.5" fill="rgba(127,212,232,.22)" stroke="#7fd4e8" stroke-width="1"/></svg>';
  var SVG_RADAR = '<svg width="11" height="11" viewBox="0 0 12 12"><ellipse cx="6" cy="5" rx="5" ry="2.6" fill="rgba(127,212,232,.22)" stroke="#7fd4e8" stroke-width="1"/><line x1="6" y1="7.6" x2="6" y2="11" stroke="#7fd4e8" stroke-width="1"/></svg>';
  /* §11.10 战略核潜艇：艇身椭圆 + 指挥塔 + 潜望镜 + 尾舵，与球面图标同一侧影。 */
  var SVG_SUB = '<svg width="11" height="11" viewBox="0 0 12 12"><ellipse cx="5.2" cy="7.4" rx="3.6" ry="1.4" fill="rgba(127,212,232,.22)" stroke="#7fd4e8" stroke-width="1"/><path d="M4,6.2 L4.2,4.4 L6.4,4.4 L6.6,6.2 Z" fill="rgba(127,212,232,.22)" stroke="#7fd4e8" stroke-width="1"/><line x1="5.3" y1="4.4" x2="5.3" y2="2.8" stroke="#7fd4e8" stroke-width="1"/><path d="M8.4,7.4 L11,5.8 L11,9 Z" fill="rgba(127,212,232,.22)" stroke="#7fd4e8" stroke-width="1"/></svg>';

  function $(id) { return document.getElementById(id); }

  /* ───────────────────────── 初始化 ───────────────────────── */

  function init(state, commands) {
    cmd = commands || {};
    el.dcBox = $('defcon'); el.dcLv = $('dcLv');
    el.crVal = $('crVal'); el.crBar = $('crBar');
    el.phName = $('phName');
    // 倒计时下沉到底部统计行最右端（回合数只体现在事件卡的回合徽章上，不再多处重复）
    el.rdTime = $('rdTime');
    el.hudLeft = $('hudLeft');
    el.myPop = $('myPop'); el.myMs = $('myMs');
    el.msLab = $('msLab');
    el.popDelta = $('popDelta'); el.msDelta = $('msDelta');
    el.popGr = $('popGr'); el.msGr = $('msGr');
    el.phase = $('phase');
    // 顶栏中段的当前阵营（色块 + 名称）：阵营在开局就定死，这里写一次即可
    el.facSw = $('facSw'); el.facName = $('facName');
    var fac = DC.FACTIONS_BY_CODE[state.playerFaction] || {};
    if (el.facSw) el.facSw.style.background = fac.color || '#ffffff';
    if (el.facName) el.facName.textContent = fac.name || state.playerFaction;
    el.speedBtn = $('speedBtn');
    el.alert = $('alert');
    el.fs = { silo: $('fsSilo'), sub: $('fsSub'), sam: $('fsSam'), radar: $('fsRadar') };
    el.ft = { silo: $('ftSilo'), sub: $('ftSub'), sam: $('ftSam'), radar: $('ftRadar') };
    el.fsWrap = { silo: $('fsSiloWrap'), sub: $('fsSubWrap'), sam: $('fsSamWrap'), radar: $('fsRadarWrap') };
    el.fList = $('fList'); el.cList = $('cList');
    el.card = $('card'); el.cTitle = $('cTitle'); el.cDesc = $('cDesc');
    el.cTimer = $('cTimer'); el.cOpts = $('cOpts'); el.cMax = $('cMax');
    el.sheet = $('sheet');
    el.warbar = $('warbar'); el.wbAmmo = $('wbAmmo'); el.wbTip = $('wbTip');
    el.tgtPick = $('tgtPick'); el.fireBtn = $('fireBtn'); el.salvoBtn = $('salvoBtn');
    if (el.tgtPick) {
      el.tgtName = el.tgtPick.querySelector('.tn');
      el.tgtHint = el.tgtPick.querySelector('.tp');
    }
    el.drawer = $('drawer'); el.drawerBtn = $('drawerBtn'); el.drawerClose = $('drawerClose');
    el.sndBtn = $('sndBtn');
    el.flash = $('flash'); el.alarm = $('alarm');
    el.over = $('over'); el.ovBody = $('ovBody'); el.ovRecap = $('ovRecap');
    el.ovTotal = $('ovTotal');
    // 终局分享（见文件末尾「终局战报图」）：战报按钮 / 一行反馈 / 容器外的预览层
    el.shareBtn = $('share'); el.shareTip = $('shareTip');
    el.report = $('report'); el.rpImg = $('rpImg'); el.rpHint = $('rpHint'); el.rpClose = $('rpClose');

    pending = null; salvo = 1;
    sig.factions = ''; sig.cities = ''; sig.card = ''; sig.choice = -2;
    /* sig.dc 必须初始化为**当前** DEFCON，不能写 0：defcon 音效是「等级跃迁告警」，
     * 初值 0 会让主循环第一帧判出一次 0→5 的假跃迁 —— 表现为点完阵营立刻多响一声告警。
     * （pumpAudio / pumpCityLoss 的初值 -1 是同一个道理，此前只有这里漏了。） */
    sig.war = -1; sig.over = false; sig.dc = state.defcon; sig.impacts = 0; sig.intercepts = -1;
    lastFlashAt = -1e9;
    sig.target = null; sig.fireOk = null; sig.tip = ''; sig.sheet = null; sig.tone = '';
    sig.pop = null; sig.ms = null; sig.fs = ''; sig.dcAlerted = false;
    speedIdx = 0; renderSpeed(1);

    if (!bound) { bindStatic(); bound = true; }
    buildCityList(state);
    renderTarget(state);
    renderSalvo();
  }

  function bindStatic() {
    // 常驻「拉满」按钮：危机博弈期间玩家随时可以主动引爆，不必等抽到带 MAX 选项的卡
    // 拉满危机值是一次不可逆的重大决策，用 pick（决策确认档）而不是 tap
    if (el.cMax) el.cMax.addEventListener('click', function () {
      sfx('pick');
      if (cmd.onCrisisMax) cmd.onCrisisMax();
    });

    if (el.drawerBtn) el.drawerBtn.addEventListener('click', function () { sfx('tap'); openDrawer(); });
    if (el.drawerClose) el.drawerClose.addEventListener('click', function () { sfx('tap'); closeDrawer(); });
    // 点「未选定目标」那一行 = 直接去抽屉里挑城市（小屏上比回地球找光点快得多）
    if (el.tgtPick) el.tgtPick.addEventListener('click', function () {
      if (!pending) { sfx('tap'); openDrawer(); }
    });

    if (el.fireBtn) el.fireBtn.addEventListener('click', function () { fire(); });
    if (el.salvoBtn) el.salvoBtn.addEventListener('click', function () { sfx('tap'); toggleSalvo(); });

    /* 分享战报：按下用界面档 tap，成功/失败才由 shareReport 自己补 pick / deny ——
     * 分享是异步的，「点了一下」和「真的发出去了」是两件事，两声不该叠在同一刻。 */
    if (el.shareBtn) el.shareBtn.addEventListener('click', function () { sfx('tap'); shareReport(); });
    if (el.rpClose) el.rpClose.addEventListener('click', function () { sfx('tap'); closeReport(); });

    /* 倍速：危机博弈每回合 20 秒、战争 3 分钟，看熟了会想快进。
     * 只加速时间推进（game.js 的 acc 累积），逻辑仍是 10 Hz 固定步长 —— 战局结果与倍速无关。 */
    if (el.speedBtn) el.speedBtn.addEventListener('click', function () { sfx('tap'); toggleSpeed(); });

    /* 音效默认开启（audio.js）：init 时把按钮初始态与 DC.audio.enabled 对齐，
     * 开态画声波线、关态画静音斜杠，不靠 HTML 里的写死初始值。 */
    if (el.sndBtn && DC.audio) {
      el.sndBtn.classList.toggle('on', DC.audio.enabled);
      el.sndBtn.setAttribute('aria-pressed', DC.audio.enabled ? 'true' : 'false');
    }

    /* 音效开关：点一下切换。AudioContext 的 resume 必须发生在真实手势里，
     * 所以解锁动作放在这个 click 上，而不是放在 init 里。 */
    if (el.sndBtn) el.sndBtn.addEventListener('click', function () {
      var on = DC.audio ? DC.audio.toggle() : false;
      el.sndBtn.classList.toggle('on', on);
      el.sndBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
      // 开声即给一声提示，否则玩家不知道有没有生效。用 pick 而不是 defcon 告警：
      // 那是一声警告音，拿来做「声音已开」的确认会把人吓一跳
      if (on) DC.audio.play('pick');
    });
  }

  function sfx(name, arg) { if (DC.audio) DC.audio.play(name, arg); }

  function openDrawer() { if (el.drawer) el.drawer.classList.add('open'); }
  function closeDrawer() { if (el.drawer) el.drawer.classList.remove('open'); }

  /* ───────────────────────── 开局：阵营选择 ─────────────────────────
   * 在渲染与模拟建立之前先问「你打谁」—— 玩家阵营决定雷达环、己方单位可见性、
   * 城市列表的敌我划分，这些都得在 create 时就定下来，不能开局后再改。
   */
  function showSetup(onPick) {
    var box = $('setup'), list = $('pickList');
    if (!box || !list) return;
    list.textContent = '';
    DC.FACTIONS.forEach(function (f) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'pick';
      b.setAttribute('data-faction', f.code);
      var sw = document.createElement('span');
      sw.className = 'sw'; sw.style.background = f.color;
      var nm = document.createElement('span');
      nm.className = 'nm'; nm.textContent = f.name;
      var rg = document.createElement('span');
      rg.className = 'rg'; rg.textContent = f.region;
      var pk = document.createElement('span');
      pk.className = 'pk'; pk.textContent = f.perkDesc || '';
      var ms = document.createElement('span');
      ms.className = 'ms'; ms.textContent = DC.factionMissiles(f.code) + ' 枚';
      b.appendChild(sw); b.appendChild(nm); b.appendChild(rg); b.appendChild(pk); b.appendChild(ms);
      b.addEventListener('click', function () {
        /* 先出声再开局：这一下点击是整局第一次用户手势，AudioContext 必须在手势里创建
         * 才会直接进 running（audio.js 的 play 也 tolerant suspended）。
         * 顺序不能反 —— 等 onPick 跑完再响，就有可能已经出界了。 */
        sfx('pick');
        if (onPick) onPick(f.code);
      });
      list.appendChild(b);
    });
    box.classList.add('show');
  }

  function hideSetup() {
    var box = $('setup');
    if (box) box.classList.remove('show');
  }

  /* ───────────────────────── 顶栏 ───────────────────────── */

  function updateTop(state) {
    el.dcLv.textContent = state.defcon;
    // 用 classList 而不是整体覆写 className —— 否则每帧覆写会把正在播的 bump 动画抹掉
    el.dcBox.classList.toggle('d1', state.defcon === 1);
    el.dcBox.classList.toggle('d2', state.defcon === 2);
    if (sig.dc !== state.defcon) {
      sig.dc = state.defcon;
      sfx('defcon', state.defcon);
      el.dcBox.classList.remove('bump');
      void el.dcBox.offsetWidth;             // 强制回流，动画才能连续触发
      el.dcBox.classList.add('bump');
    }
    el.crVal.textContent = Math.round(state.crisis);
    el.crBar.style.width = Math.max(0, Math.min(100, state.crisis)) + '%';
    /* DEFCON 跌到 1 = 核打击权限解锁，这是一局里唯一不可回头的门槛，
     * 必须有一次明确的告知（红脉冲 + 音效是氛围，这条横幅才是"说清楚"）。 */
    if (state.defcon === 1 && sig.dcAlerted !== true && state.phase !== 'over') {
      sig.dcAlerted = true;
      el.alert.classList.remove('show');
      void el.alert.offsetWidth;
      el.alert.classList.add('show');
      if (DC.render && DC.render.shake) DC.render.shake(0.6);
    }
    /* 危机值条分档着色（2026-09-09）：旧版是一条固定的 蓝→琥珀→红 渐变，
     * 宽度一变整条渐变就被压缩，危机值 10 的时候右侧照样是红的 —— 等于"永远在警戒"。
     * 改为按危机值本身分三档整条换色：开局是纯蓝，越接近开战越烫。 */
    var tone = state.crisis >= 80 ? 'hot' : state.crisis >= 45 ? 'mid' : 'low';
    if (sig.tone !== tone) { sig.tone = tone; el.crBar.className = tone; }
    el.phName.textContent = PHASE_NAME[state.phase] || state.phase;
    // 阶段着色（§11.15）：简报青 / 危机琥珀 / 战争红 / 终局灰
    if (el.phase) {
      var pc = 'p-' + state.phase;
      if (el.phase._pc !== pc) {
        el.phase._pc = pc;
        el.phase.classList.remove('p-briefing', 'p-crisis', 'p-war', 'p-over');
        el.phase.classList.add(pc);
      }
    }

    var left = 0;
    if (state.phase === 'briefing') left = Math.max(0, CONFIG.briefingSeconds - state.t);
    else if (state.phase === 'crisis') left = Math.max(0, CONFIG.roundSeconds - state.t);
    else if (state.phase === 'war') left = Math.max(0, CONFIG.warSeconds - state.t);
    /* 倒计时：统计行最右端。终局没有倒计时，显示「本局结束」。
     * 回合数不再单独展示 —— 危机期看事件卡的回合徽章，战争期只剩倒计时重要。 */
    if (el.rdTime) {
      var rt = state.phase === 'over' ? '本局结束'
        : state.phase === 'war' ? ('剩 ' + left.toFixed(0) + 's')
        : (left.toFixed(0) + 's');
      if (el.rdTime.textContent !== rt) el.rdTime.textContent = rt;
    }

    // 两档红脉冲：DEFCON 1 全力警报；危机博弈期临界（≥85）先用心跳预警吊住紧张感
    el.alarm.classList.toggle('on', state.defcon === 1 && state.phase !== 'over');
    el.alarm.classList.toggle('warn', state.phase === 'crisis' && state.crisis >= 85);
  }

  /* ───────────────────────── 我方存量（规模 / 核弹）与回合变化 ─────────────────────────
   * §11.11：每回合的规模与弹头变化必须在界面上看得见 —— 否则玩家只知道自己按了个选项，
   * 不知道这一按换来了什么（事件卡加成、城市被核平、打出去的弹头都是在这里体现）。
   * Δ 显示 2.5s 后淡出，不常驻，免得变成又一个需要解读的数字。
   * §11.13：旁边常驻一格「+X/回合」的基础产能标记 —— 即使什么都不选，回合结算也有进账，
   * 玩家据此能算出「还拖得起几个回合」。 */
  function bumpDelta(node, d, unit) {
    if (!node) return;
    node.textContent = (d > 0 ? '+' : '') + d + (unit || '');
    node.classList.toggle('up', d > 0);
    node.classList.toggle('down', d < 0);
    node.classList.add('show');
    if (node._t) clearTimeout(node._t);
    node._t = setTimeout(function () { node.classList.remove('show'); }, 2500);
  }

  function pumpDelta(state) {
    var pop = 0;
    S.citiesOf(state, state.playerFaction).forEach(function (c) { pop += c.pop; });
    var ms = S.totalMissiles(state, state.playerFaction);
    /* §11.17 热核阶段（含终局）：弹头存量在发射条里已有且更醒目，
     * 左上这格改口径为「战损」（己方累计伤亡规模）—— 遵循 §11.16 回避「人」的表述。 */
    var war = state.phase === 'war' || state.phase === 'over';

    // 产能标记仅简报期展示（§11.17）：进入危机博弈后「还拖得起几个回合」不再有意义
    if (el.hudLeft) {
      var ng = state.phase !== 'briefing';
      if (el.hudLeft._ng !== ng) { el.hudLeft._ng = ng; el.hudLeft.classList.toggle('nogrowth', ng); }
    }

    if (el.myPop) {
      var ps = pop.toFixed(1);
      if (el.myPop.textContent !== ps) el.myPop.textContent = ps;
    }
    if (el.msLab) {
      var lab = war ? '战损' : '弹头';
      if (el.msLab.textContent !== lab) el.msLab.textContent = lab;
    }
    if (el.myMs) {
      var msText = war
        ? (((state.stats[state.playerFaction] || {}).casualties) || 0).toFixed(1) + 'M'
        : String(ms);
      if (el.myMs.textContent !== msText) el.myMs.textContent = msText;
    }

    // 基础产能常驻标记（§11.13）：读 sim.roundGrowthOf，与回合结算完全同一套口径
    if ((el.popGr || el.msGr) && state.phase === 'briefing') {
      var g = S.roundGrowthOf(state, state.playerFaction);
      var pgs = '+' + g.pop.toFixed(1) + '/回合';
      var mgs = '+' + g.missiles + '/回合';
      if (el.popGr && el.popGr.textContent !== pgs) el.popGr.textContent = pgs;
      if (el.msGr && el.msGr.textContent !== mgs) el.msGr.textContent = mgs;
    }

    if (sig.pop == null) { sig.pop = pop; sig.ms = ms; return; }   // 首帧只记基线
    if (Math.abs(pop - sig.pop) > 0.05) {
      bumpDelta(el.popDelta, +((pop - sig.pop).toFixed(1)), 'M');
      sig.pop = pop;
    }
    if (ms !== sig.ms) {
      // 热核阶段这格已换成战损口径，弹头增减不再闪烁 Δ（发射条自己会扣数字）
      if (!war) bumpDelta(el.msDelta, ms - sig.ms, '');
      sig.ms = ms;
    }
  }

  /* ───────────────────────── 我方军事设备在线统计（热核阶段）─────────────────────────
   * 「在线 / 总数」两个口径：设施被核平 → disabled → 在线数实时扣除，红色标出。
   * 玩家在战争期唯一能判断"我还有多少还手之力"的地方，比只看弹头数更完整
   * （发射井打空但还在 = 能补弹；发射井没了 = 彻底没了）。 */
  function updateForceStat(state) {
    if (!el.fs || !el.fs.silo) return;
    var me = state.playerFaction;
    var vals = {}, key = [];
    ['silo', 'sub', 'sam', 'radar'].forEach(function (t) {
      var all = 0, on = 0;
      state.units.forEach(function (u) {
        if (u.faction !== me || u.type !== t) return;
        all++;
        if (!u.disabled) on++;
      });
      vals[t] = [on, all];
      key.push(t + on + '/' + all);
    });
    var s = key.join('|');
    if (s === sig.fs) return;
    sig.fs = s;
    ['silo', 'sub', 'sam', 'radar'].forEach(function (t) {
      if (el.fs[t]) el.fs[t].textContent = vals[t][0];
      if (el.ft[t]) el.ft[t].textContent = vals[t][1];
      if (el.fsWrap[t]) el.fsWrap[t].classList.toggle('hit', vals[t][0] < vals[t][1]);
    });
  }

  /* ───────────────────────── 演出：核爆白闪 ───────────────────────── */

  /* state.impacts 是逻辑层的单调计数（sim 在 resolveImpact 里 +1）。
   * 不能读 state.fx —— render.frame 每帧 shift 清空队列，UI 永远读不到。 */
  /* 白闪节流：齐射落地时 impacts 短时间连跳多次，每次都重播动画就是频闪（手机上尤其刺眼）。
   * 两次白闪之间至少隔 FLASH_GAP —— 被跳过的命中依然有音效、震屏和球面焦痕，演出不缺席，只是不闪眼。 */
  var FLASH_GAP = 1100;              // ms，与 CSS 动画时长一致：上一次退光结束前不重播
  var lastFlashAt = -1e9;

  /* 己方城市被毁：nuke 表达的是「某处爆炸了」，这一声表达的是「死的是我的城」。
   * 只在己方存活城市数下降时响；初值 -1 用来跳过首帧，否则一进战争期就误报一次。
   * 简报期重置，避免重开一局时沿用上一局的计数。 */
  var lastMyAlive = -1;
  function pumpCityLoss(state) {
    var n = 0;
    for (var i = 0; i < state.cities.length; i++) {
      var c = state.cities[i];
      if (c.alive && c.faction === state.playerFaction) n++;
    }
    if (state.phase === 'briefing') { lastMyAlive = n; return; }
    if (lastMyAlive >= 0 && n < lastMyAlive) sfx('cityLost');
    lastMyAlive = n;
  }
  function pumpImpacts(state) {
    if (state.impacts === sig.impacts) return;
    sig.impacts = state.impacts;
    sfx('nuke');
    var now = Date.now();
    if (now - lastFlashAt >= FLASH_GAP) {
      lastFlashAt = now;
      el.flash.classList.remove('on');
      void el.flash.offsetWidth;         // 强制回流，动画才能连续触发
      el.flash.classList.add('on');
    }
    if (DC.render && DC.render.shake) DC.render.shake(1);
  }

  /* ───────────────────────── 阵营列表 ───────────────────────── */

  function updateFactions(state) {
    var rows = state.factions.map(function (f) {
      var pop = S.citiesOf(state, f.code).reduce(function (s, c) { return s + c.pop; }, 0);
      return { code: f.code, name: f.name, color: f.color, pop: pop, me: f.isPlayer };
    });
    // 签名比对：内容没变就不碰 DOM
    var s = rows.map(function (r) { return r.code + Math.round(r.pop * 10); }).join('|');
    if (s === sig.factions) return;
    sig.factions = s;

    el.fList.textContent = '';
    rows.forEach(function (r) {
      var d = document.createElement('div');
      d.className = 'frow' + (r.me ? ' me' : '') + (r.pop <= 0 ? ' dead' : '');
      var sw = document.createElement('span');
      sw.className = 'sw'; sw.style.background = r.color;
      var nm = document.createElement('span');
      nm.className = 'nm'; nm.textContent = r.me ? r.name + '（你）' : r.name;
      var pp = document.createElement('span');
      pp.className = 'pp'; pp.textContent = r.pop.toFixed(0) + 'M';
      d.appendChild(sw); d.appendChild(nm); d.appendChild(pp);
      el.fList.appendChild(d);
    });
  }

  /* ───────────────────────── 城市列表（抽屉内）───────────────────────── */

  function buildCityList(state) {
    el.cList.textContent = '';
    state.cities.forEach(function (c) {
      var fc = DC.FACTIONS_BY_CODE[c.faction] || {};
      var row = document.createElement('div');
      row.className = 'crow';
      row.setAttribute('data-city', c.id);
      var sw = document.createElement('span');
      sw.className = 'sw'; sw.style.background = fc.color || '#ffffff';
      var nm = document.createElement('span');
      nm.className = 'cn'; nm.textContent = c.name;
      var cf = document.createElement('span');
      cf.className = 'cf';
      var pp = document.createElement('span');
      pp.className = 'cp';
      row.appendChild(sw); row.appendChild(nm); row.appendChild(cf); row.appendChild(pp);
      /* 战争阶段：第一下 = 选中目标，第二下 = 确认发射（防误触）。
       * 其余阶段：点击 = 相机飞过去（砍掉 2D 视图后的操作补偿，DESIGN §2.3）。 */
      row.addEventListener('click', function () {
        var isTarget = cur && cur.phase === 'war' &&
                       c.alive && c.faction !== cur.playerFaction;
        if (isTarget) {
          /* 从抽屉里选完必须收起抽屉：抽屉 z-index 30 且满屏高，
           * 会把 z-index 12 的底部发射条整个盖住 —— 不关掉玩家就再也按不到「发 射」。 */
          if (pending === c.id) { closeDrawer(); fire(); }
          else { selectTarget(c.id); closeDrawer(); }
          return;
        }
        // 非战争期点城市 = 相机飞过去，此前完全无声，点了不知道有没有生效
        sfx('tap');
        if (DC.render && DC.render.flyTo) DC.render.flyTo(c.lat, c.lon);
        closeDrawer();
      });
      el.cList.appendChild(row);
    });
  }

  function updateCities(state) {
    var s = state.cities.map(function (c) {
      var t = (state.phase === 'war' && c.alive && c.faction !== state.playerFaction) ? 't' : '';
      var us = S.unitsOfCity(state, c.id);
      var intel = us.some(function (u) { return u.exposed; });
      return c.id + (c.alive ? Math.round(c.pop * 10) : 'x') + t + (pending === c.id ? 'S' : '') + (intel ? 'I' : '');
    }).join('|');
    if (s === sig.cities) return;
    sig.cities = s;
    var rows = el.cList.children;
    for (var i = 0; i < rows.length; i++) {
      var c = state.cities[i];
      if (!c) continue;
      var tgt = state.phase === 'war' && c.alive && c.faction !== state.playerFaction;
      rows[i].className = 'crow' + (c.alive ? '' : ' gone') +
                          (tgt ? ' tgt' : '') + (pending === c.id ? ' sel' : '');
      // 关联设施：己方直接显示，敌方需情报（任一关联设施 exposed）才显示，否则 "?"
      // §11.9 改用图例 SVG 图形 × 数量徽章，复用 index.html 图例区 path
      // §11.12 失效设施单独成组、整组染灰（opacity .35）—— 与球面灰图标同一口径
      var cfHtml = '';
      if (c.alive) {
        var us = S.unitsOfCity(state, c.id);
        var isOurs = c.faction === state.playerFaction;
        var hasIntel = us.some(function (u) { return u.exposed; });
        if (isOurs || hasIntel) {
          var ICONS = { silo: SVG_SILO, sub: SVG_SUB, sam: SVG_SAM, radar: SVG_RADAR };
          var TYPES = ['silo', 'sub', 'sam', 'radar'];
          cfHtml = TYPES.map(function (t) {
            var on = 0, off = 0;
            us.forEach(function (u) { if (u.type === t) { u.disabled ? off++ : on++; } });
            var html = '';
            if (on) html += ICONS[t] + '<b>' + on + '</b>';
            if (off) html += ICONS[t].replace('<svg ', '<svg style="opacity:.35" ') + '<b style="opacity:.35">' + off + '</b>';
            return html;
          }).join('') || '—';
        } else {
          cfHtml = '?';
        }
      }
      rows[i].children[2].innerHTML = cfHtml;
      rows[i].children[3].textContent = c.alive ? c.pop.toFixed(1) + 'M' : '——';
    }
  }

  /* ───────────────────────── 目标选择（两段式发射 · 第一段）───────────────────────── */

  function selectTarget(cityId) {
    var c = cur ? S.findCity(cur, cityId) : null;
    if (!c) return false;
    pending = cityId;
    renderTarget(cur);
    sfx('select');   // 第一段此前无声，手机上容易以为没点上而反复戳
    // 选目标的同时把地球转过去，并在球面上打一圈锁定环（§12）：
    // flyTo 只解决「看不看得见」，锁定环解决「62 个环里哪一个是它」。
    if (DC.render && DC.render.flyTo) DC.render.flyTo(c.lat, c.lon);
    if (DC.render && DC.render.setTarget) DC.render.setTarget(c.lat, c.lon);
    return true;
  }

  function clearTarget() {
    if (DC.render && DC.render.clearTarget) DC.render.clearTarget();
    if (!pending) return;
    pending = null;
    renderTarget(cur);
  }

  function renderTarget(state) {
    if (!el.tgtPick) return;
    var c = pending && state ? S.findCity(state, pending) : null;
    var key = c ? (c.id + Math.round(c.pop * 10)) : '';
    if (key === sig.target) return;
    sig.target = key;
    if (!c) {
      el.tgtPick.classList.add('empty');
      el.tgtName.textContent = '未选定目标';
      el.tgtHint.textContent = '点选敌方坐标，或从城市列表挑选';
      return;
    }
    el.tgtPick.classList.remove('empty');
    el.tgtName.textContent = c.name + ' · ' + c.pop.toFixed(1) + 'M';
    var f = DC.FACTIONS_BY_CODE[c.faction];
    el.tgtHint.textContent = (f ? f.name : c.faction) + ' · 再点一次确认';
  }

  var SPEEDS = [1, 2, 4];
  var speedIdx = 0;
  function toggleSpeed() {
    speedIdx = (speedIdx + 1) % SPEEDS.length;
    var v = SPEEDS[speedIdx];
    renderSpeed(v);
    if (cmd.onSpeed) cmd.onSpeed(v);
  }
  function renderSpeed(v) {
    if (!el.speedBtn) return;
    el.speedBtn.textContent = '×' + v;
    el.speedBtn.classList.toggle('on', v !== 1);
  }

  function toggleSalvo() {
    salvo = (salvo === 1) ? 3 : 1;
    renderSalvo();
  }

  function renderSalvo() {
    if (!el.salvoBtn) return;
    // 显示当前状态（而非"切换到的目标"）：单发就显示单发，齐射就显示齐射
    el.salvoBtn.textContent = salvo === 1 ? '单发 ×1' : '齐射 ×3';
    el.salvoBtn.classList.toggle('on', salvo !== 1);
  }

  /* 三种「射不出去」都归到这里：没选目标 / 弹头耗尽 / 不在战争期。
   * 判定必须在这一层做全 —— 不能靠 fireBtn 的原生 disabled 去挡（见 updateWarBar）：
   * 原生 disabled 会把 click 整个吞掉，deny() 的「被拒」音与发射条红抖就永远触发不到。 */
  function fire() {
    if (!pending || !cur || cur.phase !== 'war' ||
        S.totalMissiles(cur, cur.playerFaction) <= 0) { deny(); return; }
    var id = pending;
    // 打完立刻清空：连点不会在没重新选目标的情况下把剩下的弹头一口气泼出去
    clearTarget();
    sfx('launch');
    if (cmd.onFire) cmd.onFire(id, salvo);
  }

  /* ───────────────────────── 事件卡（玩家决策入口）───────────────────────── */

  function hideCard() {
    if (sig.card === '') return;
    sig.card = ''; sig.choice = -2;
    el.card.classList.remove('show');
    el.cOpts.textContent = '';
  }

  function buildCard(state) {
    var c = state.card;
    /* 标题行 = 回合徽章 + 事件名：回合从标题文本里拆出来做成描边小徽章，
     * 与底部统计行不再有重复的「第 X 回合」纯文本（底部已删）。 */
    el.cTitle.innerHTML = '<span class="cr">第 ' + state.round + ' 回合</span>';
    el.cTitle.appendChild(document.createTextNode(c.title));
    el.cDesc.textContent = c.desc;
    el.cOpts.textContent = '';

    c.options.forEach(function (o, i) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'opt';
      b.setAttribute('data-opt', String(i));

      var lb = document.createElement('span');
      lb.className = 'ol'; lb.textContent = o.label;
      var isMax = DC.isCrisisMax(o);
      var ex = document.createElement('span');
      ex.className = 'oe';
      ex.textContent = isMax ? '危机值直接拉满' : (o.effect ? (EFFECT_TEXT[o.effect.type] || o.effect.type) : '');

      var right = document.createElement('span');
      right.className = 'or';
      var cc = document.createElement('span');
      cc.className = 'cc ' + (isMax ? 'max' : DC.crisisValue(o) > 0 ? 'up' : DC.crisisValue(o) < 0 ? 'down' : 'zero');
      cc.textContent = isMax ? '拉满' : ((o.crisis > 0 ? '+' : '') + o.crisis);
      right.appendChild(cc);

      b.appendChild(lb); b.appendChild(ex); b.appendChild(right);
      // 立即回显选中态，不等下一帧：一是点击反馈必须符合直觉，
      // 二是依赖下一帧会让外部（如冒烟测试）读到「状态已改、UI 未变」的不一致窗口。
      b.addEventListener('click', function () {
        if (cmd.onChoose) cmd.onChoose(i);
        if (cur) updateCard(cur);
      });
      el.cOpts.appendChild(b);
    });
    el.card.classList.add('show');
  }

  function updateCard(state) {
    if (state.phase !== 'crisis' || !state.card) { hideCard(); return; }

    if (sig.card !== state.card.id + '#' + state.round) {
      sig.card = state.card.id + '#' + state.round;
      sig.choice = -2;
      buildCard(state);
    }
    // 已选项高亮（回合内可改主意；超时未选由 sim 兜底为最保守项）
    var pick = state.choices[state.playerFaction];
    if (pick !== sig.choice) {
      var had = sig.choice;
      sig.choice = (pick == null) ? -1 : pick;
      var bs = el.cOpts.children;
      for (var i = 0; i < bs.length; i++) {
        if (i === pick) bs[i].classList.add('sel'); else bs[i].classList.remove('sel');
      }
      /* 发声放在这里而不是选项按钮的回调里：键盘 1..n 走的是 game.js 的 chooseOption，
       * 根本不经过按钮回调。had === -2 表示这是新卡刚建好的首次对齐，不是玩家操作。 */
      if (had !== -2 && pick != null) sfx('pick');
    }
    // 倒计时条：回合内剩余时间
    var left = Math.max(0, 1 - state.t / CONFIG.roundSeconds);
    el.cTimer.style.width = (left * 100).toFixed(1) + '%';
  }

  /* ───────────────────────── 战争操作条（两段式发射 · 第二段）───────────────────────── */

  function updateWarBar(state) {
    if (state.phase !== 'war') {
      if (sig.war !== -1) { sig.war = -1; el.warbar.classList.remove('show'); }
      clearTarget();
      return;
    }
    var ammo = S.totalMissiles(state, state.playerFaction);
    if (sig.war !== ammo) {
      sig.war = ammo;
      el.wbAmmo.textContent = ammo;
      el.warbar.classList.toggle('empty', ammo <= 0);
    }
    // 目标被别人抢先打掉 → 自动清空，避免对着废墟按下发射
    if (pending) {
      var pc = S.findCity(state, pending);
      if (!pc || !pc.alive) clearTarget();
    }
    renderTarget(state);

    var ok = !!pending && ammo > 0;
    /* 用 .off + aria-disabled 表达「按不下去」，**不再用原生 disabled**：
     * 原生 disabled 会让 click 根本不派发，玩家按上去零反馈，
     * 于是 deny() 那一声「被拒」和发射条红抖成了永远走不到的死代码。
     * 现在的口径是「看着是灰的、按下去明确被拒一次」——反馈由 deny() 给（见 fire()）。 */
    if (sig.fireOk !== ok) {
      sig.fireOk = ok;
      el.fireBtn.classList.toggle('off', !ok);
      el.fireBtn.setAttribute('aria-disabled', ok ? 'false' : 'true');
    }
    var tip = ammo <= 0 ? '弹头耗尽 —— 转入终局战果结算'
      : pending ? '再按一次确认发射 —— 弹道不可撤收'
      : '先装订敌方目标坐标，再按发射';
    if (sig.tip !== tip) { sig.tip = tip; el.wbTip.textContent = tip; }
    el.warbar.classList.add('show');
  }

  /* ───────────────────────── 终局 ───────────────────────── */

  function showOver(state) {
    if (sig.over) return;
    sig.over = true;
    var rk = S.ranking(state);
    /* 终局此前是完全静默的 —— 排名面板弹出那一秒一点声音都没有，情绪在最该落地处断了。
     * 名次决定两件事：end 音效的和弦色彩、终局 BGM 用哪一版（夺冠 / 落败）。
     * 两处都走 sim.myRank（读 enterPhase 缓存的名次），避免各算一套。 */
    sfx('end', S.myRank(state));
    el.ovBody.textContent = '';
    /* 全球战损总数：整局最该被看见的数字（§11.8b）。
     * 单位是百万，写成「X.XX 亿」比「XXX.XM」更像一条新闻标题 —— 反战表达要的是体感。 */
    if (el.ovTotal) {
      var dead = S.globalCasualties ? S.globalCasualties(state) : 0;
      el.ovTotal.textContent = (dead / 100).toFixed(2);
    }
    /* §11.8 终局面板：排名按剩余存续规模降序，最后一列显示存续规模（主排序键）。
     * 保留造成/战损供参考，但主胜负判定是「谁的存续规模大」。 */
    rk.forEach(function (r, i) {
      var tr = document.createElement('tr');
      if (r.code === state.playerFaction) tr.className = 'me';
      [String(i + 1), r.name, r.killed.toFixed(1) + 'M', r.casualties.toFixed(1) + 'M']
        .forEach(function (t) {
          var td = document.createElement('td'); td.textContent = t; tr.appendChild(td);
        });
      var sc = document.createElement('td');
      sc.className = 'sc';
      sc.textContent = r.popLeft.toFixed(1) + 'M';
      sc.style.color = 'var(--cyan)';
      tr.appendChild(sc);
      el.ovBody.appendChild(tr);
    });
    buildRecap(state);
    /* 分享入口每局复位：上一局的「已唤起发布页 / 已取消」不该留在新一局的按钮下面。
     * （「再来一局」走整页 reload，这里主要防的是调试期手动重入 showOver。） */
    setShareBusy(false);
    setShareTip('');
    el.over.classList.add('show');
  }

  function factionName(code) {
    var f = DC.FACTIONS_BY_CODE[code];
    return f ? f.name : code;
  }

  /* 终局复盘的三个口径（§12 P1：导火索 / 首枚落地 / 你的战果）。
   * 只抽「读哪几个字段、命中率怎么算」，不抽文案 ——
   * 终局面板要富文本（加粗 / 高亮），战报图只能画纯文本，各拼各的句子；
   * 但两者必须站在同一份数字上，否则改了一处另一处就开始说谎。 */
  function recapFacts(state) {
    var st = state.stats[state.playerFaction] || { launched: 0, hits: 0, lost: 0, casualties: 0 };
    var fired = st.hits + st.lost;
    return {
      round: state.round,
      by: state.maxedBy,
      first: state.firstImpact,
      stats: st,
      // 命中率的分母是「打到敌人头上的 + 被拦掉的」：发射了但还在飞的不算，避免终局读数虚低
      rate: fired > 0 ? (st.hits / fired * 100) : 0
    };
  }

  /* 终局复盘（§12 P1）：三行关键节点。
   * 排名表给出的是结果，玩家真正想知道的是原因 ——
   * 「是谁先把局势推过线的」「第一发砸在谁头上」「我打出去的弹有多少真的落地了」。
   * 三行都从 state 已有的字段里读，不额外维护一份统计。 */
  function buildRecap(state) {
    if (!el.ovRecap) return;
    el.ovRecap.textContent = '';

    function row(key, html) {
      var d = document.createElement('div');
      d.className = 'rc';
      var k = document.createElement('span');
      k.className = 'rk'; k.textContent = key;
      var v = document.createElement('span');
      v.className = 'rv'; v.innerHTML = html;
      d.appendChild(k); d.appendChild(v);
      el.ovRecap.appendChild(d);
      return v;
    }

    var f = recapFacts(state);

    // 1. 导火索：触发全面开战的那一下（MAX 选项 / 核弹落地 / 回合数失控）
    row('导火索', f.by
      ? '第 <b>' + f.round + '</b> 回合 · ' + f.by
      : '危机失控 —— 未触发拉满就打满了回合上限');

    // 2. 首枚落地：谁先开的第一枪
    row('首枚落地', f.first
      ? '第 <b>' + f.first.round + '</b> 回合 · <span class="hl">' + factionName(f.first.from) +
        '</span> 命中 ' + factionName(f.first.to) + ' 的 <b>' + f.first.city + '</b>'
      : '本局无核弹落地 —— 六方全部克制住了');

    // 3. 你的战果：发射/命中/被拦三件套，回答「我的弹都去哪了」
    var st = f.stats;
    row('你的战果', '发射 <b>' + st.launched + '</b> 枚 · 命中 <span class="hl">' + st.hits +
      '</span>（' + f.rate.toFixed(0) + '%）· 被拦 ' + st.lost +
      ' · 己方战损 <b>' + st.casualties.toFixed(1) + 'M</b>');
  }

  /* ─────────────────── 终局战报图与分享（§11.24）───────────────────
   * 战报图在本地用 Canvas 2D 画，不引任何外部资源；画完交给容器 JSBridge 发出去：
   *
   *   画布 data:uri → writeTempFile（换成临时 filePath）→ postNote（唤起笔记发布页）
   *
   * 固定 750×1000（3:4）而不跟设备 DPR —— 这是「要发出去的图」，输出尺寸必须与设备无关，
   * 否则同一份战报在不同手机上发出来的版式各不相同。小红书图文笔记首图也是 3:4。
   *
   * 容器外（PC 预览 / 桌面浏览器）没有 window.xhs.miniTool：小工具红线又禁用
   * a[download] 与 blob 下载，所以退化到页内预览 + 引导长按保存，见 openReport。
   */
  var REPORT_W = 750, REPORT_H = 1000;
  var shareBusy = false;

  /* Canvas 字体串：中文走 sans-serif 的系统字形回退，数字 / 代号走 monospace 让列对齐。 */
  function rpFont(ctx, px, weight, mono) {
    ctx.font = (weight ? weight + ' ' : '') + px + 'px ' + (mono ? 'monospace' : 'sans-serif');
  }

  /* 字距：ctx.letterSpacing 到 Chrome 99 才有，基线 WebView 61 用不了 —— 逐字画。
   * 只给页眉这类短文本用，长句不铺字距（逐字画会丢掉整段的排版优化）。 */
  function rpSpaced(ctx, text, x, y, spacing) {
    for (var i = 0; i < text.length; i++) {
      ctx.fillText(text.charAt(i), x, y);
      x += ctx.measureText(text.charAt(i)).width + spacing;
    }
  }

  /* 圆角矩形路径：roundRect 到 Chrome 99 才有，基线用二次曲线画。 */
  function rpPath(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  /* 战报图上的复盘三行：与 DOM 面板同一份数字（recapFacts），只是去掉富文本标记。 */
  function reportRecapLines(state, f) {
    var st = f.stats;
    return [
      { k: '导火索', v: f.by
        ? '第 ' + f.round + ' 回合 · ' + f.by
        : '危机失控 —— 未触发拉满就打满了回合上限' },
      { k: '首枚落地', v: f.first
        ? '第 ' + f.first.round + ' 回合 · ' + factionName(f.first.from) + ' 命中 ' +
          factionName(f.first.to) + ' 的 ' + f.first.city
        : '本局无核弹落地 —— 六方全部克制住了' },
      { k: '你的战果', v: '发射 ' + st.launched + ' 枚 · 命中 ' + st.hits + '（' +
        f.rate.toFixed(0) + '%）· 被拦 ' + st.lost + ' · 己方战损 ' + st.casualties.toFixed(1) + 'M' }
    ];
  }

  /* 笔记正文。上限 1000 字（jsbridge-api.md §postNote）。
   * 「话题」一律不带：正文里不写 # 标签，也不传 postNote 的 tags 字段
   * （该字段不在本仓库 API 规范的字段表内，未声明字段不传是硬约定）。 */
  function reportText(state) {
    var f = recapFacts(state);
    var rk = S.ranking(state);
    var rank = S.myRank(state);
    var top = rk[0] || { name: '—', popLeft: 0 };
    var lines = [
      '核战危机 DEFCON · 终局战报',
      '我的阵营：' + factionName(state.playerFaction) + (rank ? ' · 第 ' + rank + ' 名' : ''),
      '全球战损 ' + (S.globalCasualties(state) / 100).toFixed(2) + ' 亿',
      '存续规模最大：' + top.name + ' ' + top.popLeft.toFixed(1) + 'M',
      ''
    ];
    reportRecapLines(state, f).forEach(function (ln) {
      lines.push(ln.k + '：' + ln.v);
    });
    lines.push('');
    lines.push('六方相互威慑的球面核战博弈 —— 这场博弈没有赢家，愿世界和平。');
    return lines.join('\n');
  }

  /* 画战报图，返回 data:uri。拿不到 2D 上下文或画布被污染时返回 null，
   * 由调用方走「生成失败」分支 —— 不在这里抛。 */
  function buildReport(state) {
    var cv = document.createElement('canvas');
    cv.width = REPORT_W; cv.height = REPORT_H;
    var ctx = cv.getContext('2d');
    if (!ctx) return null;

    var fac = DC.FACTIONS_BY_CODE[state.playerFaction] ||
      { name: state.playerFaction, color: '#7fd4e8' };
    var rk = S.ranking(state);
    var rank = S.myRank(state);
    var dead = S.globalCasualties(state);
    var f = recapFacts(state);
    var me = null;
    rk.forEach(function (r) { if (r.code === state.playerFaction) me = r; });

    var M = 56, i;

    // ── 底：深空渐变 + 军事沙盘细网格 + 一圈细边（与游戏内质感同源）
    var bg = ctx.createLinearGradient(0, 0, 0, REPORT_H);
    bg.addColorStop(0, '#060c16'); bg.addColorStop(0.6, '#04070d'); bg.addColorStop(1, '#0b0406');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, REPORT_W, REPORT_H);

    ctx.strokeStyle = 'rgba(127,212,232,.05)'; ctx.lineWidth = 1;
    for (i = 0; i <= REPORT_W; i += 50) {
      ctx.beginPath(); ctx.moveTo(i + 0.5, 0); ctx.lineTo(i + 0.5, REPORT_H); ctx.stroke();
    }
    for (i = 0; i <= REPORT_H; i += 50) {
      ctx.beginPath(); ctx.moveTo(0, i + 0.5); ctx.lineTo(REPORT_W, i + 0.5); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(127,212,232,.22)';
    ctx.strokeRect(0.5, 0.5, REPORT_W - 1, REPORT_H - 1);

    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.lineWidth = 1;

    // ── 页眉
    rpFont(ctx, 22, '700', true);
    ctx.fillStyle = '#7fd4e8';
    rpSpaced(ctx, 'NUCLEAR CRISIS · DEFCON', M, 88, 3);
    ctx.textAlign = 'right';
    ctx.fillStyle = 'rgba(127,212,232,.55)';
    ctx.fillText('#vibegame', REPORT_W - M, 88);
    ctx.textAlign = 'left';

    rpFont(ctx, 52, '700', false);
    ctx.fillStyle = '#ffffff';
    ctx.fillText('终局战报', M, 152);
    rpFont(ctx, 26, '700', true);
    ctx.fillStyle = 'rgba(127,212,232,.8)';
    ctx.textAlign = 'right';
    ctx.fillText(rank > 0 ? '第 ' + rank + ' 名 / ' + rk.length : '终局清算', REPORT_W - M, 150);
    ctx.textAlign = 'left';

    ctx.strokeStyle = 'rgba(127,212,232,.28)';
    ctx.beginPath(); ctx.moveTo(M, 176); ctx.lineTo(REPORT_W - M, 176); ctx.stroke();

    // ── 我方阵营块：左侧阵营色条 + 色块 + 名称 / 性格，右侧存续规模（主排序键）
    var boxY = 200, boxH = 92, boxW = REPORT_W - M * 2;
    ctx.fillStyle = 'rgba(127,212,232,.05)';
    rpPath(ctx, M, boxY, boxW, boxH, 6); ctx.fill();
    ctx.fillStyle = fac.color;
    rpPath(ctx, M, boxY, 6, boxH, 3); ctx.fill();
    ctx.fillRect(M + 26, boxY + 28, 22, 22);

    rpFont(ctx, 30, '700', false);
    ctx.fillStyle = '#ffffff';
    ctx.fillText(fac.name || '', M + 62, boxY + 50);

    rpFont(ctx, 19, '400', false);
    ctx.fillStyle = 'rgba(190,215,230,.62)';
    ctx.fillText(fac.trait || fac.region || '', M + 62, boxY + 78);

    rpFont(ctx, 17, '400', false);
    ctx.fillStyle = 'rgba(190,215,230,.55)';
    ctx.textAlign = 'right';
    ctx.fillText('存续规模', REPORT_W - M - 26, boxY + 38);
    rpFont(ctx, 32, '700', true);
    ctx.fillStyle = '#7fd4e8';
    ctx.fillText((me ? me.popLeft : 0).toFixed(1) + 'M', REPORT_W - M - 26, boxY + 78);
    ctx.textAlign = 'left';

    // ── 全球战损：整张图最大的一行字（反战表达要的是体感，不是小数精度）
    rpFont(ctx, 20, '400', false);
    ctx.fillStyle = 'rgba(190,215,230,.55)';
    rpSpaced(ctx, '全球战损', M, 344, 4);

    var numStr = (dead / 100).toFixed(2);
    rpFont(ctx, 92, '700', true);
    ctx.fillStyle = '#e24b4a';
    ctx.fillText(numStr, M, 434);
    var wNum = ctx.measureText(numStr).width;
    rpFont(ctx, 28, '400', false);
    ctx.fillStyle = 'rgba(226,75,74,.8)';
    ctx.fillText('亿', M + wNum + 12, 430);
    /* 说明文字右对齐钉死在版心右侧，不跟着数字宽度走 ——
     * 战损从 0.00 到 50.00 时数字宽度差 1 个字，「亿」后面的字会横跳。 */
    rpFont(ctx, 19, '400', false);
    ctx.fillStyle = 'rgba(190,215,230,.5)';
    ctx.textAlign = 'right';
    ctx.fillText('六方对峙到清算的总代价', REPORT_W - M, 430);
    ctx.textAlign = 'left';

    // ── 排名表：与终局面板同列（# / 阵营 / 造成 / 战损 / 存续），本方整行高亮
    ctx.strokeStyle = 'rgba(127,212,232,.28)';
    ctx.beginPath(); ctx.moveTo(M, 464); ctx.lineTo(REPORT_W - M, 464); ctx.stroke();

    var colIdx = M, colName = M + 62, colKill = 430, colLost = 540, colLeft = REPORT_W - M;
    rpFont(ctx, 17, '400', false);
    ctx.fillStyle = 'rgba(190,215,230,.5)';
    ctx.fillText('#', colIdx, 496);
    ctx.fillText('阵营', colName, 496);
    ctx.textAlign = 'right';
    ctx.fillText('造成', colKill, 496);
    ctx.fillText('战损', colLost, 496);
    ctx.fillText('存续', colLeft, 496);
    ctx.textAlign = 'left';

    ctx.strokeStyle = 'rgba(127,212,232,.14)';
    ctx.beginPath(); ctx.moveTo(M, 510); ctx.lineTo(REPORT_W - M, 510); ctx.stroke();

    var rowY = 550, step = 47;
    rk.forEach(function (r, k) {
      var mine = r.code === state.playerFaction;
      if (mine) {
        ctx.fillStyle = 'rgba(127,212,232,.09)';
        ctx.fillRect(M - 10, rowY - 30, boxW + 20, step - 6);
      }
      rpFont(ctx, 21, '700', true);
      ctx.fillStyle = 'rgba(190,215,230,.5)';
      ctx.fillText(String(k + 1), colIdx, rowY);

      var rf = DC.FACTIONS_BY_CODE[r.code] || {};
      ctx.fillStyle = rf.color || '#7fd4e8';
      ctx.fillRect(colName, rowY - 15, 12, 12);
      rpFont(ctx, 22, mine ? '700' : '400', false);
      ctx.fillStyle = mine ? '#ffffff' : 'rgba(214,232,240,.88)';
      ctx.fillText(r.name, colName + 22, rowY);

      rpFont(ctx, 21, '400', true);
      ctx.fillStyle = 'rgba(214,232,240,.72)';
      ctx.textAlign = 'right';
      ctx.fillText(r.killed.toFixed(1), colKill, rowY);
      ctx.fillText(r.casualties.toFixed(1), colLost, rowY);
      rpFont(ctx, 22, '700', true);
      ctx.fillStyle = '#7fd4e8';
      ctx.fillText(r.popLeft.toFixed(1) + 'M', colLeft, rowY);
      ctx.textAlign = 'left';

      rowY += step;
    });

    // ── 复盘三行
    ctx.strokeStyle = 'rgba(127,212,232,.28)';
    ctx.beginPath(); ctx.moveTo(M, 812); ctx.lineTo(REPORT_W - M, 812); ctx.stroke();

    var ly = 852;
    reportRecapLines(state, f).forEach(function (ln) {
      rpFont(ctx, 16, '400', false);
      ctx.fillStyle = 'rgba(190,215,230,.5)';
      ctx.fillText(ln.k, M, ly);
      rpFont(ctx, 17, '400', false);
      ctx.fillStyle = 'rgba(214,232,240,.9)';
      ctx.fillText(ln.v, M + 90, ly);
      ly += 34;
    });

    // ── 页脚
    ctx.strokeStyle = 'rgba(127,212,232,.14)';
    ctx.beginPath(); ctx.moveTo(M, 944); ctx.lineTo(REPORT_W - M, 944); ctx.stroke();
    rpFont(ctx, 19, '400', false);
    ctx.fillStyle = 'rgba(190,215,230,.62)';
    ctx.fillText('这场博弈没有赢家 —— 反对战争，珍爱和平', M, 978);

    return cv.toDataURL('image/png');
  }

  /* 容器注入的 JSBridge 入口：PC 预览 / 老客户端上可能整体不存在，一律先判空。 */
  function miniTool() {
    var x = global.xhs;
    return (x && x.miniTool) ? x.miniTool : null;
  }

  function setShareTip(msg) {
    if (!el.shareTip) return;
    el.shareTip.textContent = msg || '';
    el.shareTip.classList.toggle('show', !!msg);
  }

  function setShareBusy(busy) {
    shareBusy = busy;
    if (!el.shareBtn) return;
    el.shareBtn.classList.toggle('busy', busy);
    el.shareBtn.textContent = busy ? '生成中…' : '分享战报';
  }

  function openReport(url, hint) {
    if (!el.report) return;
    if (el.rpImg) el.rpImg.src = url;
    if (el.rpHint) el.rpHint.textContent = hint || '';
    el.report.classList.add('show');
  }

  function closeReport() {
    if (el.report) el.report.classList.remove('show');
  }

  /* 分享入口（终局面板的「分享战报」）。
   * 三种环境三种走法，全部失败时兜底到页内预览 —— 玩家至少拿得到这张图。 */
  function shareReport() {
    if (shareBusy) return;
    var state = cur;
    if (!state || state.phase !== 'over') return;

    var url = null;
    try { url = buildReport(state); } catch (e) { url = null; }
    if (!url) { sfx('deny'); setShareTip('战报图生成失败，请再试一次。'); return; }

    var mt = miniTool();
    if (!mt) {
      /* 容器外（PC 预览 / 桌面浏览器）：既没有 JSBridge 也没有系统相册，
       * 页内展示是唯一通路 —— 引导长按保存，别让玩家点了没反应。 */
      openReport(url, '已生成战报图。在小红书 App 内打开本作品，点「分享战报」可直接唤起笔记发布页；此处可长按图片保存。');
      return;
    }

    var content = reportText(state);
    setShareBusy(true);
    setShareTip('');

    /* 先落临时文件再发笔记：战报 PNG 的 base64 有一两百 KB，直接塞进
     * mediaInfo.image_resources[].url 要走很长的上行；writeTempFile 换成 filePath 更稳。
     * 老客户端没有 writeTempFile 就退回直接传 data:uri —— postNote 同样接受完整 data:uri。
     * writeTempFile 失败也不阻断：拿 data:uri 继续试，最坏也还有相册那条路。 */
    var ready;
    if (mt.writeTempFile) {
      ready = mt.writeTempFile({ data: url }).then(function (r) {
        return (r && r.filePath) ? r.filePath : url;
      }, function () { return url; });
    } else {
      ready = Promise.resolve(url);
    }

    ready.then(function (path) {
      if (mt.postNote) {
        return mt.postNote({
          title: '核战危机 DEFCON · 终局战报',
          content: content,
          pageType: 'photo_publish',
          mediaInfo: { image_resources: [{ url: path }] }
        }).then(function () { return 'note'; });
      }
      if (mt.saveImageToPhotosAlbum) {
        return mt.saveImageToPhotosAlbum({ filePath: path }).then(function () { return 'album'; });
      }
      return 'none';                       // 端能力一个都没有，落到页内预览
    }).then(function (how) {
      setShareBusy(false);
      if (how === 'none') {
        openReport(url, '当前环境没有可用的端能力，战报图已显示在这里，可长按保存。');
        return;
      }
      sfx('pick');
      setShareTip(how === 'album'
        ? '已保存到相册 —— 可从相册发笔记。'
        : '已唤起笔记发布页 —— 在发布页确认即发出。');
    }).catch(function (err) {
      setShareBusy(false);
      /* 用户在小红书发布页点取消也会走 reject，这不是失败：
       * 再弹一次预览图或报错都是骚扰。errMsg 形如 "postNote:fail cancel"。 */
      var msg = (err && err.errMsg) ? String(err.errMsg) : '';
      if (msg.toLowerCase().indexOf('cancel') >= 0) { setShareTip('已取消分享。'); return; }
      sfx('deny');
      openReport(url, '分享没有成功，战报图已显示在这里，可长按保存后自行发布。');
    });
  }

  /* ───────────────────────── 每帧 ───────────────────────── */

  /* 拦截音效：sim 没有为「拦截发生」单独投递事件，只有 stats 里的累计计数。
   * 比对累计和即可判定；战争期一秒内可能有十几次拦截，去抖交给 audio.js 的 MIN_GAP。
   * 初值 -1 是为了跳过开局那一次「0 ≠ -1」，否则一进游戏就先响一声。 */
  function pumpAudio(state) {
    var it = 0;
    Object.keys(state.stats).forEach(function (k) { it += state.stats[k].intercepts; });
    if (it === sig.intercepts) return;
    if (sig.intercepts >= 0 && it > sig.intercepts) sfx('intercept');
    sig.intercepts = it;
  }

  function update(state) {
    cur = state;
    updateTop(state);
    updateFactions(state);
    updateCities(state);
    pumpDelta(state);
    updateForceStat(state);
    updateCard(state);
    updateWarBar(state);
    pumpImpacts(state);
    pumpAudio(state);
    pumpCityLoss(state);
    if (state.phase === 'over') showOver(state);

    // 情境面板在简报期是空的（既没有卡也没有战争条），不该占掉屏幕底部一条
    var any = (state.phase === 'crisis' && state.card) || state.phase === 'war';
    if (sig.sheet !== any) { sig.sheet = any; el.sheet.classList.toggle('none', !any); }
  }

  // 指令被拒（射不到 / 没弹了）时的抖一下，代替弹窗
  function deny() {
    sfx('deny');
    if (!el.warbar) return;
    el.warbar.classList.remove('deny');
    void el.warbar.offsetWidth;          // 强制回流，让动画可以连续触发
    el.warbar.classList.add('deny');
  }

  DC.ui = {
    init: init,
    showSetup: showSetup,
    hideSetup: hideSetup,
    update: update,
    buildCityList: buildCityList,
    showOver: showOver,
    /* 战报生成与分享对外暴露：无头脚本量不了画布，但浏览器冒烟要能直接调它验通路
     * （reportText 一并暴露，是为了让「正文不带话题」这条可断言，而不是只能读源码确认）。 */
    buildReport: buildReport,
    reportText: reportText,
    shareReport: shareReport,
    closeReport: closeReport,
    deny: deny,
    selectTarget: selectTarget,
    clearTarget: clearTarget,
    fire: fire,
    openDrawer: openDrawer,
    closeDrawer: closeDrawer,
    isDrawerOpen: function () { return !!el.drawer && el.drawer.classList.contains('open'); },
    getPending: function () { return pending; },
    getSalvo: function () { return salvo; },
    el: el
  };

})(typeof window !== 'undefined' ? window : globalThis);
