(function(){
var cv=document.getElementById('cv');
var renderer=new THREE.WebGLRenderer({canvas:cv,antialias:true});
renderer.outputEncoding=THREE.sRGBEncoding;
renderer.toneMapping=THREE.LinearToneMapping;
renderer.toneMappingExposure=0.92;
var scene=new THREE.Scene();
var SKY1=new THREE.Color(0x549fe2),SKY2=new THREE.Color(0x050810);
scene.background=SKY1.clone();
scene.fog=new THREE.Fog(0x7fb5e4,1500,50000);
var camera=new THREE.PerspectiveCamera(55,16/9,0.5,300000);

/* ---------- 灯光 ---------- */
var hemi=new THREE.HemisphereLight(0xeaf7ff,0x5f9c52,0.78);scene.add(hemi);
var sun=new THREE.DirectionalLight(0xfff3d0,1.0);sun.position.set(400,600,250);scene.add(sun);

/* ---------- 贴图 ---------- */
function puffTex(){var c=document.createElement('canvas');c.width=c.height=64;var x=c.getContext('2d'),g=x.createRadialGradient(32,32,2,32,32,30);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.45,'rgba(255,255,255,.6)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,64,64);var t=new THREE.CanvasTexture(c);return t;}
var PTEX=puffTex();

/* ---------- 地面场景 ---------- */
var ground=new THREE.Mesh(new THREE.CircleGeometry(36000,48),new THREE.MeshStandardMaterial({color:0x65b25a,roughness:1}));
ground.rotation.x=-Math.PI/2;scene.add(ground);
var fieldCols=[0x82c86b,0xa9da80,0x6fbb58,0xc6e78f,0x92d072];
for(var i=0;i<26;i++){var f=new THREE.Mesh(new THREE.PlaneGeometry(1,1),new THREE.MeshStandardMaterial({color:fieldCols[i%5],roughness:1}));
 var an=Math.random()*6.283,sw=300+Math.random()*600,sh=300+Math.random()*600;
 /* 农田块中心最小半径按实际尺寸计算：旋转后对角投影最大 √2*半宽，保证最内角距发射台(半径42)至少留 150 净空，永不遮挡 */
 var rr=42+Math.sqrt(2)*Math.max(sw,sh)/2+150+Math.random()*4800;f.rotation.x=-Math.PI/2;f.rotation.z=Math.random()*6.28;
 f.position.set(Math.cos(an)*rr,0.3+i*0.02,Math.sin(an)*rr);f.scale.set(sw,sh,1);scene.add(f);}
for(i=0;i<7;i++){var h=new THREE.Mesh(new THREE.ConeGeometry(900+Math.random()*900,220+Math.random()*260,7),new THREE.MeshStandardMaterial({color:0x5aa763,roughness:1,flatShading:true}));
 var a2=i/7*6.283+Math.random();h.position.set(Math.cos(a2)*(10000+Math.random()*5000),0,Math.sin(a2)*(10000+Math.random()*5000));scene.add(h);}
var pad=new THREE.Mesh(new THREE.CircleGeometry(42,36),new THREE.MeshStandardMaterial({color:0xa9b4c2,roughness:.9}));
pad.rotation.x=-Math.PI/2;pad.position.y=0.15;scene.add(pad);
var pad2=new THREE.Mesh(new THREE.CircleGeometry(28,32),new THREE.MeshStandardMaterial({color:0x95a2b2,roughness:.9}));
pad2.rotation.x=-Math.PI/2;pad2.position.y=0.2;scene.add(pad2);
/* 发射塔 */
var tower=new THREE.Group(),tm=new THREE.MeshStandardMaterial({color:0xe0503f,roughness:.6});
function tb(w,hh,d,x,y,z,rz){var b=new THREE.Mesh(new THREE.BoxGeometry(w,hh,d),tm);b.position.set(x,y,z);if(rz)b.rotation.z=rz;tower.add(b);}
for(i=0;i<12;i++){var y0=i*4;tb(0.5,0.5,5,-8,y0+2,0);tb(0.5,4.4,0.5,-8,y0+2.2,2.2);tb(0.5,4.4,0.5,-8,y0+2.2,-2.2);tb(0.5,5.4,0.5,-8,y0+2.2,0,i%2?0.72:-0.72);}
tb(0.6,0.6,0.6,-5,42,0);tb(6,0.7,0.7,-4.2,43,0);tb(6,0.7,0.7,-4.2,36,0);
scene.add(tower);
/* 云 */
var clouds=[];
for(i=0;i<14;i++){var cm=new THREE.SpriteMaterial({map:PTEX,transparent:true,opacity:.55,depthWrite:false,fog:false});
 var cs=new THREE.Sprite(cm);var ca=Math.random()*6.283,cr=2500+Math.random()*5000;
 cs.position.set(Math.cos(ca)*cr,1200+Math.random()*1500,Math.sin(ca)*cr);cs.scale.set(900+Math.random()*800,420+Math.random()*300,1);scene.add(cs);clouds.push(cs);}
/* 星星 */
var sg=new THREE.BufferGeometry(),sp=new Float32Array(1400*3);
for(i=0;i<1400;i++){var u=Math.random()*2-1,ph=Math.random()*6.283,rr2=30000,xx=Math.sqrt(1-u*u);sp[i*3]=xx*Math.cos(ph)*rr2;sp[i*3+1]=u*rr2;sp[i*3+2]=xx*Math.sin(ph)*rr2;}
sg.setAttribute('position',new THREE.BufferAttribute(sp,3));
var starMat=new THREE.PointsMaterial({color:0xffffff,size:110,sizeAttenuation:true,transparent:true,opacity:0,depthWrite:false,fog:false});
var stars=new THREE.Points(sg,starMat);scene.add(stars);

/* ---------- 火箭 ---------- */
var matW=new THREE.MeshStandardMaterial({color:0xf8fbff,roughness:.32,metalness:.15}),
    matB=new THREE.MeshStandardMaterial({color:0x0a8fe0,roughness:.35,metalness:.2}),
    matR=new THREE.MeshStandardMaterial({color:0xe03131,roughness:.42}),
    matD=new THREE.MeshStandardMaterial({color:0x3c4756,roughness:.5,metalness:.4});
matW.fog=false;matB.fog=false;matR.fog=false;matD.fog=false;
function makeFlame(s){var g=new THREE.Group();
 var o=new THREE.Mesh(new THREE.ConeGeometry(1.5*s,9*s,18),new THREE.MeshBasicMaterial({color:0xff8a2a,transparent:true,opacity:.72,blending:THREE.AdditiveBlending,depthWrite:false,fog:false}));o.position.y=-4.5*s;
 var n=new THREE.Mesh(new THREE.ConeGeometry(.75*s,5.5*s,14),new THREE.MeshBasicMaterial({color:0xfff3b0,transparent:true,opacity:.88,blending:THREE.AdditiveBlending,depthWrite:false,fog:false}));n.position.y=-2.7*s;
 var gl=new THREE.Sprite(new THREE.SpriteMaterial({map:PTEX,color:0xffb35a,transparent:true,opacity:.65,blending:THREE.AdditiveBlending,depthWrite:false,fog:false}));gl.scale.set(7*s,7*s,1);gl.position.y=-2*s;
 var li=new THREE.PointLight(0xffa640,0,400);li.position.y=-3*s;
 g.add(o,n,gl,li);g.userData={o:o,n:n,gl:gl,li:li};return g;}
var rocket,s1,s2,flame1,flame2,s1On=true;
function buildRocket(){
 rocket=new THREE.Group();
 s1=new THREE.Group();
 var b1=new THREE.Mesh(new THREE.CylinderGeometry(2,2,20,24),matW);b1.position.y=12.6;s1.add(b1);
 var st=new THREE.Mesh(new THREE.CylinderGeometry(2.04,2.04,1.4,24),matB);st.position.y=19.5;s1.add(st);
 var sk=new THREE.Mesh(new THREE.CylinderGeometry(2.1,2.35,2.4,24),matD);sk.position.y=3.4;s1.add(sk);
 var bell=new THREE.Mesh(new THREE.CylinderGeometry(1.1,1.75,2.6,20),matD);bell.position.y=1.3;s1.add(bell);
 for(var k=0;k<4;k++){var fin=new THREE.Mesh(new THREE.BoxGeometry(.3,5,3.4),matR);var an=k*Math.PI/2;fin.position.set(Math.cos(an)*2.5,4.4,Math.sin(an)*2.5);fin.rotation.y=-an;s1.add(fin);}
 flame1=makeFlame(1);flame1.position.y=0.1;flame1.visible=false;s1.add(flame1);
 s2=new THREE.Group();s2.position.y=22.6;
 var b2=new THREE.Mesh(new THREE.CylinderGeometry(2,2,10,24),matW);b2.position.y=5;s2.add(b2);
 var bd=new THREE.Mesh(new THREE.CylinderGeometry(2.04,2.04,.9,24),matR);bd.position.y=9.6;s2.add(bd);
 var nose=new THREE.Mesh(new THREE.ConeGeometry(2,6,24),matW);nose.position.y=13;s2.add(nose);
 var tip=new THREE.Mesh(new THREE.CylinderGeometry(.14,.14,1.3,8),matD);tip.position.y=16.5;s2.add(tip);
 var nz2=new THREE.Mesh(new THREE.CylinderGeometry(.7,1.1,1.6,16),matD);nz2.position.y=-.6;s2.add(nz2);
 flame2=makeFlame(.55);flame2.position.y=-1.3;flame2.visible=false;s2.add(flame2);
 rocket.add(s1,s2);rocket.position.set(0,0.6,0);scene.add(rocket);
}
buildRocket();
/* 影子 */
var blob=new THREE.Mesh(new THREE.CircleGeometry(6,24),new THREE.MeshBasicMaterial({color:0x1e293b,transparent:true,opacity:.28,depthWrite:false}));
blob.rotation.x=-Math.PI/2;blob.position.y=0.28;scene.add(blob);
/* 高空可视标记 */
var marker=new THREE.Sprite(new THREE.SpriteMaterial({map:PTEX,color:0x7fc9ff,transparent:true,opacity:0.26,depthWrite:false,depthTest:false,fog:false}));
marker.renderOrder=950;scene.add(marker);
/* 受力箭头 */
var UP=new THREE.Vector3(0,1,0),DN=new THREE.Vector3(0,-1,0);
var arT=new THREE.ArrowHelper(UP,new THREE.Vector3(),10,0x059669,6,2.4),arW=new THREE.ArrowHelper(DN,new THREE.Vector3(),10,0xdc2626,6,2.4);
arT.visible=arW.visible=false;scene.add(arT);scene.add(arW);
function tuneArrow(a){
  a.renderOrder=999;
  if(a.line){a.line.material.depthTest=false;a.line.material.transparent=true;a.line.material.opacity=0.95;a.line.material.fog=false;}
  if(a.cone){a.cone.material.depthTest=false;a.cone.material.transparent=true;a.cone.material.opacity=0.95;a.cone.material.fog=false;}
}
tuneArrow(arT);tuneArrow(arW);

/* ---------- 烟雾粒子 ---------- */
var smoke=[],SN=220;
for(i=0;i<SN;i++){var sm=new THREE.SpriteMaterial({map:PTEX,transparent:true,opacity:0,depthWrite:false,fog:false});var ss=new THREE.Sprite(sm);ss.visible=false;scene.add(ss);smoke.push({s:ss,age:0,life:1,vx:0,vy:0,vz:0,grow:0,op:0});}
var sIdx=0;
function puff(x,y,z,vx,vy,vz,sc,life,op,hex){var p=smoke[sIdx];sIdx=(sIdx+1)%SN;p.age=0;p.life=life;p.vx=vx;p.vy=vy;p.vz=vz;p.grow=sc*0.9;p.op=op;p.s.visible=true;p.s.position.set(x,y,z);p.s.scale.set(sc,sc,1);p.s.material.color.setHex(hex||0xd8d8d8);}
function updateSmoke(dt){for(var j=0;j<SN;j++){var p=smoke[j];if(!p.s.visible)continue;p.age+=dt;if(p.age>=p.life){p.s.visible=false;p.s.material.opacity=0;continue;}p.s.position.x+=p.vx*dt;p.s.position.y+=p.vy*dt;p.s.position.z+=p.vz*dt;p.vy+=1.5*dt;var k=p.age/p.life;p.s.scale.x+=p.grow*dt;p.s.scale.y=p.s.scale.x;p.s.material.opacity=p.op*(1-k)*Math.min(1,p.age*8);}}

/* ---------- 物理与状态 ---------- */
var G0=9.8,RE=6.371e6,KARMAN=100000;
var S1={F:1.5e6,mdot:1400,fuel0:40000,dry:10000},S2={F:5.2e5,mdot:420,fuel0:18000,dry:4000},PAY=6000;
var fuel1,fuel2,alt,v,aNow,simT,phase,cd,sepT,throttle=1,warp=4,maxAlt,karman,apoFlag,debris=[],camOff=16;
function mass(){return PAY+S2.dry+fuel2+(s1On?S1.dry+fuel1:0);}
function reset(){
 for(var d=0;d<debris.length;d++)scene.remove(debris[d].g);debris=[];
 scene.remove(rocket);buildRocket();s1On=true;
 fuel1=S1.fuel0;fuel2=S2.fuel0;alt=0;v=0;aNow=0;simT=0;phase='idle';cd=0;sepT=0;maxAlt=0;karman=false;apoFlag=false;
 flame1.visible=flame2.visible=false;blob.material.opacity=.28;
 for(var j=0;j<SN;j++){smoke[j].s.visible=false;smoke[j].s.material.opacity=0;}
 btnGo.disabled=false;btnGo.textContent='发射';
 setNarr('idle');setTag();setChip(-1);
 camOff=16;
 if(typeof camT!=='undefined')camT.set(0,16,0);
 if(typeof radius!=='undefined')radius=150;
 if(typeof theta!=='undefined')theta=0.55;
 if(typeof phi!=='undefined')phi=1.12;
 if(typeof lastInput!=='undefined')lastInput=performance.now();
}
/* ---------- UI ---------- */
var $=function(id){return document.getElementById(id);};
var rAlt=$('rAlt'),rVel=$('rVel'),rAcc=$('rAcc'),rMas=$('rMas'),rThr=$('rThr'),rTwr=$('rTwr'),tag=$('tag'),hud=$('hud'),narr=$('narr'),pgB=$('pgB'),pgT=$('pgT'),sT=$('sT'),sMax=$('sMax'),sFuel=$('sFuel'),btnGo=$('bGo'),btnRst=$('bRst'),btnSpd=$('bSpd'),thrS=$('thr'),thrL=$('thrL');
var chips=[ $('c0'),$('c1'),$('c2'),$('c3'),$('c4'),$('c5') ];
var NARRS={
 idle:'火箭静静伫立在发射台，燃料已加注完毕。点击 <span class="hl">发射</span> 进入倒计时——记住：推重比必须 <span class="hl2">大于 1</span> 才能起飞。',
 count:'倒计时！点火指令已下达，发动机正在预热增压……盯紧火箭尾部，火焰即将喷涌而出。',
 pad:'<span class="ev">推力不足！</span>推力小于重力，火箭被牢牢按在发射台上。试着 <span class="hl">加大油门</span>，让推重比超过 1。',
 burn1:'轰鸣！燃气<span class="hl">向下高速喷出</span>，气体把火箭<span class="hl2">向上推起</span>——这就是牛顿第三定律。燃料不断燃烧，火箭越来越轻，加速度越来越大。',
 sep:'<span class="hl2">级间分离！</span>一级燃料耗尽，抛掉空壳减轻自重——多级火箭"轻装上阵"，二级发动机即将接力。',
 burn2:'二级发动机点火！推力虽小，但火箭质量更轻，继续加速冲向太空。注意观察受力分析中箭头的变化。',
 coast:'发动机关机，燃料用尽。火箭依靠<span class="hl">惯性</span>继续上升，重力不断给它"踩刹车"，速度越来越慢。',
 apo:'到达<span class="hl2">最高点</span>！此刻速度为零，随后火箭在重力作用下掉头下落。',
 end:''};
function setNarr(k){if(k==='end'){narr.innerHTML='火箭落回地面，任务结束：最高高度 <span class="hl">'+(maxAlt/1000).toFixed(1)+' km</span>'+(karman?'，<span class="hl2">成功跨越卡门线，进入太空！</span>':'，距离卡门线（100 km）还差一步——把油门拉满再试一次！');}else narr.innerHTML=NARRS[k];}
function setTag(txt,cls){if(txt){tag.textContent=txt;tag.className='tag '+cls;return;}
 switch(phase){case 'idle':tag.textContent='待命';tag.className='tag tag-info';break;
 case 'count':tag.textContent='倒计时';tag.className='tag tag-info';break;
 case 'pad':tag.textContent='推力不足';tag.className='tag tag-virt';break;
 case 'burn1':case 'sep':case 'burn2':tag.textContent=karman?'已跨越卡门线 · 进入太空':'动力上升中';tag.className='tag tag-real';break;
 case 'coast':tag.textContent=karman?'跨越卡门线 · 惯性滑行':'惯性滑行';tag.className=karman?'tag tag-real':'tag tag-info';break;
 case 'end':tag.textContent='任务结束';tag.className='tag tag-info';break;}}
function setChip(n){for(var j=0;j<6;j++)chips[j].classList.toggle('hi',j===n);}
var mode='view';
$('m1').addEventListener('click',function(){mode='view';this.classList.add('active');$('m2').classList.remove('active');arT.visible=arW.visible=false;});
$('m2').addEventListener('click',function(){mode='force';this.classList.add('active');$('m1').classList.remove('active');});
thrS.addEventListener('input',function(){throttle=this.value/100;thrL.textContent=this.value+'%';});
btnSpd.addEventListener('click',function(){warp=warp===1?4:(warp===4?8:1);this.textContent='速度 ×'+warp;});
btnGo.addEventListener('click',function(){if(phase!=='idle')return;phase='count';cd=3;btnGo.disabled=true;btnGo.textContent='发射中…';setNarr('count');setChip(0);setTag();});
btnRst.addEventListener('click',reset);

/* ---------- 相机控制 ---------- */
var theta=0.55,phi=1.12,radius=150,camT=new THREE.Vector3(0,16,0),lastInput=0,rightV=new THREE.Vector3();
var pts={},pn=0,pd=0;
cv.addEventListener('pointerdown',function(e){cv.setPointerCapture(e.pointerId);pts[e.pointerId]={x:e.clientX,y:e.clientY};pn++;pd=0;lastInput=performance.now();});
cv.addEventListener('pointermove',function(e){if(!pts[e.pointerId])return;var p=pts[e.pointerId];
 if(pn===2){var ids=Object.keys(pts);if(ids.length===2){var a=pts[ids[0]],b=pts[ids[1]];a.x=e.pointerId==ids[0]?e.clientX:a.x;a.y=e.pointerId==ids[0]?e.clientY:a.y;b.x=e.pointerId==ids[1]?e.clientX:b.x;b.y=e.pointerId==ids[1]?e.clientY:b.y;var d=Math.hypot(a.x-b.x,a.y-b.y);if(pd>0)radius=Math.max(40,Math.min(120000,radius*pd/d));pd=d;}}
 else{theta-=(e.clientX-p.x)*0.005;phi=Math.max(0.15,Math.min(1.48,phi-(e.clientY-p.y)*0.004));}
 p.x=e.clientX;p.y=e.clientY;lastInput=performance.now();});
function pup(e){if(pts[e.pointerId]){delete pts[e.pointerId];pn=Math.max(0,pn-1);pd=0;}}
cv.addEventListener('pointerup',pup);cv.addEventListener('pointercancel',pup);
cv.addEventListener('wheel',function(e){e.preventDefault();radius=Math.max(40,Math.min(120000,radius*Math.exp(e.deltaY*0.0012)));lastInput=performance.now();},{passive:false});
function arrowHead(l){return Math.max(0.005, Math.min(l*0.38, Math.max(5, radius*0.025)));}
function arrowWid(l){return Math.max(0.004, Math.min(l*0.18, Math.max(2.2, radius*0.011)));}

/* ---------- 分离 ---------- */
function doSeparation(){
 var baseY=alt+0.6;
 var topY=alt+23.2;
 var rz=rocket?rocket.rotation.z:0;
 rocket.remove(s2);
 var dg=new THREE.Group();dg.position.set(0,baseY,0);dg.add(s1);scene.add(dg);
 debris.push({g:dg,vy:v-25,vr:0.25+Math.random()*0.3});
 scene.remove(rocket);s1=null;
 var rg=new THREE.Group();rg.position.set(0,topY,0);rg.add(s2);s2.position.set(0,0,0);rg.rotation.z=rz;scene.add(rg);rocket=rg;
 s1On=false;
 camOff-=22.6;
 alt+=22.6;
 for(var j=0;j<18;j++)puff((Math.random()-.5)*6,topY+(Math.random()-.5)*4,(Math.random()-.5)*6,(Math.random()-.5)*18,(Math.random()-.5)*10,(Math.random()-.5)*18,3,1.6,.7,0xe8e8e8);
}

/* ---------- 物理步进 ---------- */
function step(dt){
 simT+=dt;
 var burning=(phase==='burn1'||phase==='burn2'||phase==='pad');
 var st=phase==='burn2'?S2:S1,F=0,md=0;
 if(burning&&throttle>0){F=throttle*st.F;md=throttle*st.mdot;}
 var m=mass(),g=G0*Math.pow(RE/(RE+alt),2);
 aNow=(F-m*g)/m;
 if(phase==='pad'){
   if(F>m*g){phase='burn1';setNarr('burn1');setChip(1);setTag();}
   else{v=0;alt=0;aNow=0;if(throttle<=0){setTag('油门为零','tag-virt');}else setTag();}
 }
 if(phase==='burn1'||phase==='burn2'||phase==='coast'||phase==='sep'){
   v+=aNow*dt;alt+=v*dt;if(alt<0)alt=0;
 }
 if(phase==='burn1'){fuel1-=md*dt;if(fuel1<=0){fuel1=0;phase='sep';sepT=1.2;setNarr('sep');setChip(2);setTag();doSeparation();}}
 else if(phase==='sep'){sepT-=dt;if(sepT<=0){phase='burn2';setNarr('burn2');setChip(3);setTag();}}
 else if(phase==='burn2'){fuel2-=md*dt;if(fuel2<=0){fuel2=0;phase='coast';setNarr('coast');setChip(4);setTag();}}
 else if(phase==='coast'){
   if(!apoFlag&&v<=0){apoFlag=true;setNarr('apo');setChip(5);setTag();}
   if(alt<=0){alt=0;v=0;phase='end';setNarr('end');setTag();for(var q=0;q<24;q++)puff((Math.random()-.5)*20,2,(Math.random()-.5)*20,(Math.random()-.5)*25,Math.random()*15,(Math.random()-.5)*25,4,2,.8,0xcfcfcf);}
 }
 if(alt>=KARMAN&&!karman){karman=true;setTag();}
 if(alt>maxAlt)maxAlt=alt;
}

/* ---------- 尺寸 ---------- */
let W=900,H=520;
function _rz3d(){var r=cv.parentElement.getBoundingClientRect();W=Math.max(280,r.width);H=Math.max(220,r.height);renderer.setPixelRatio(Math.min(2,window.devicePixelRatio||1));renderer.setSize(W,H,false);camera.aspect=W/H;camera.updateProjectionMatrix();}
_rz3d();
if(window.ResizeObserver)new ResizeObserver(_rz3d).observe(cv.parentElement);
window.addEventListener('resize',_rz3d);

/* ---------- 主循环 ---------- */
reset();
var clock=new THREE.Clock(),tG=0;
function loop(){
 requestAnimationFrame(loop);
 var dtr=Math.min(0.05,clock.getDelta());tG+=dtr;
 if(phase==='count'){cd-=dtr;if(cd<=0){phase='pad';setNarr('pad');setTag();}}
 else if(phase!=='idle'&&phase!=='end'){
   var acc=Math.min(0.25,dtr*warp);
   var hMax=1/120;
   while(acc>1e-6 && phase!=='idle' && phase!=='end'){
     var h=Math.min(hMax,acc);
     step(h);
     acc-=h;
   }
 }
 if(rocket)rocket.position.y=alt+0.6;
 /* 火焰 */
 var burning=(phase==='burn1'||(phase==='burn2'&&throttle>0)||phase==='pad');
 var th=throttle,fl=(0.7+0.3*Math.sin(tG*42)+0.15*Math.sin(tG*91))*Math.max(th,0.001);
 var fl2=(0.82+0.16*Math.sin(tG*27)+0.07*Math.sin(tG*61))*Math.max(th,0.001);
 var f1on=burning&&s1On&&th>0.02,f2on=phase==='burn2'&&th>0.02;
 flame1.visible=f1on;flame2.visible=f2on;
 if(f1on){flame1.scale.set(.8+.4*fl,th*(0.6+0.55*fl),.8+.4*fl);flame1.userData.li.intensity=1.7*th;flame1.userData.o.material.opacity=.42+.38*th;}
 if(f2on){flame2.scale.set(.8+.3*fl2,th*(0.6+0.45*fl2),.8+.3*fl2);flame2.userData.li.intensity=1.2*th;flame2.userData.o.material.opacity=.42+.38*th;}
 /* 烟雾 */
 if((f1on||f2on)&&alt<3000){
   var ny=rocket.position.y+(s1On?0.4:-0.8),n=alt<60?8:(alt<800?4:2);
   for(var q2=0;q2<n;q2++){
     if(alt<80){var an2=Math.random()*6.283,sp2=8+Math.random()*16;puff(Math.cos(an2)*4,1+Math.random()*3,Math.sin(an2)*4,Math.cos(an2)*sp2,2+Math.random()*5,Math.sin(an2)*sp2,5+Math.random()*4,2.5+Math.random()*1.5,.55,0xc8c8c8);}
     else puff(rocket.position.x+(Math.random()-.5)*2,ny,rocket.position.z+(Math.random()-.5)*2,(Math.random()-.5)*4,-(15+Math.random()*25),(Math.random()-.5)*4,2.5,1.2,.5,0xe0e0e0);
   }
 }
 updateSmoke(dtr*warp);
 /* 残骸 */
 for(var d2=debris.length-1;d2>=0;d2--){var db=debris[d2];db.vy-=G0*dtr*warp;db.g.position.y+=db.vy*dtr*warp;db.g.rotation.x+=db.vr*dtr*warp;db.g.rotation.z+=db.vr*0.6*dtr*warp;
   if(db.g.position.y<-2){for(var q3=0;q3<14;q3++)puff(db.g.position.x+(Math.random()-.5)*14,1,db.g.position.z+(Math.random()-.5)*14,(Math.random()-.5)*20,Math.random()*12,(Math.random()-.5)*20,4,2,.7,0xbfbfbf);scene.remove(db.g);debris.splice(d2,1);}}
 /* 天空 / 星星 / 光 */
 var t=Math.max(0,Math.min(1,alt/90000));t=t*t*(3-2*t);
 scene.background.copy(SKY1).lerp(SKY2,t);scene.fog.color.copy(scene.background);
 hemi.intensity=Math.max(0.22,0.78-0.48*t);starMat.opacity=Math.max(0,Math.min(1,(alt-15000)/50000))*0.9;
 stars.position.copy(camera.position);
 for(var c2=0;c2<clouds.length;c2++){clouds[c2].position.x+=dtr*8;clouds[c2].material.opacity=0.55*Math.max(0,1-alt/25000);}
 /* 影子 */
 blob.material.opacity=Math.max(0,0.28/(1+alt/60));blob.scale.set(1+alt*0.004,1+alt*0.004,1);
 if(alt>4000)blob.visible=false;else blob.visible=true;
 /* 火箭摆动 */
 if(rocket){
   if(phase!=='idle'&&phase!=='end'){
     if(s1On) rocket.rotation.z=Math.sin(tG*0.8)*0.004;
     else rocket.rotation.z*=Math.exp(-dtr*4);
   }else{
     rocket.rotation.z=0;
   }
 }
 /* 相机 */
 if(phase==='idle'&&performance.now()-lastInput>4000)theta+=dtr*0.15;
 var desiredOff=s1On?16:7;
 camOff += (desiredOff - camOff) * (1 - Math.exp(-dtr*6));
 var tgt=new THREE.Vector3(rocket.position.x,rocket.position.y+camOff,rocket.position.z);
 if(phase==='idle'){
   camT.lerp(tgt,1-Math.pow(0.0015,dtr));
 }else{
   camT.copy(tgt);
 }
 var nearWanted=Math.max(0.5,Math.min(20,radius*0.002));
 var farWanted=Math.max(600000,camT.y+radius+250000);
 if(Math.abs(camera.near-nearWanted)>0.01||Math.abs(camera.far-farWanted)>1){
   camera.near=nearWanted;
   camera.far=farWanted;
   camera.updateProjectionMatrix();
 }
 camera.position.set(camT.x+radius*Math.sin(phi)*Math.sin(theta),camT.y+radius*Math.cos(phi),camT.z+radius*Math.sin(phi)*Math.cos(theta));
 camera.lookAt(camT);
 camera.updateMatrixWorld();
 /* 高空标记 */
 if(rocket){
   marker.position.copy(rocket.position);
   marker.position.y += s1On ? 15 : 10;
   var ms=Math.max(12, Math.min(2800, radius*0.055 + 10 + alt*0.0008));
   marker.scale.set(ms,ms,1);
   marker.material.opacity = phase==='end' ? 0.10 : 0.22 + 0.06*Math.sin(tG*3.1);
 }
 /* 受力箭头 */
 if(mode==='force'&&rocket){
   var m2=mass(),g2=G0*Math.pow(RE/(RE+alt),2),st2=phase==='burn2'?S2:S1;
   var F2=((phase==='burn1'||phase==='burn2'||phase==='pad')&&throttle>0)?throttle*st2.F:0;
   var cy=rocket.position.y+(s1On?18:9);
   var ascale=Math.max(1,Math.min(80,radius/180));
   var maxL=Math.max(70,radius*0.32);
   var baseW=m2*g2/55000;
   var lW=Math.min(Math.max(0.01,baseW*ascale),maxL);
   var off=Math.max(7,radius*0.045);
   rightV.setFromMatrixColumn(camera.matrixWorld,0);
   arW.visible=true;
   arW.position.copy(rocket.position).addScaledVector(rightV,off);
   arW.position.y=cy;
   arW.setLength(lW,arrowHead(lW),arrowWid(lW));
   if(F2>0){
     var baseT=F2/55000;
     var lT=Math.min(Math.max(0.01,baseT*ascale),maxL);
     arT.visible=true;
     arT.position.copy(rocket.position).addScaledVector(rightV,-off);
     arT.position.y=cy;
     arT.setLength(lT,arrowHead(lT),arrowWid(lT));
   }else{
     arT.visible=false;
   }
 }else{arT.visible=arW.visible=false;}
 /* UI */
 var mNow=mass(),gNow=G0*Math.pow(RE/(RE+alt),2),stNow=phase==='burn2'?S2:S1,
     Fnow=(phase==='burn1'||phase==='burn2'||phase==='pad')?throttle*stNow.F:0,
     twr=Fnow/(mNow*gNow);
 rAlt.textContent=(alt/1000).toFixed(alt<10000?2:1)+' km';
 rVel.textContent=v.toFixed(0)+' m/s';
 rAcc.textContent=aNow.toFixed(1)+' m/s²';
 rMas.textContent=(mNow/1000).toFixed(1)+' t';
 rThr.textContent=(Fnow/1000).toFixed(0)+' kN';
 rTwr.textContent=twr.toFixed(2);
 rTwr.style.color=twr>1?'var(--pri)':'var(--danger)';
 pgB.style.width=Math.min(100,alt/KARMAN*100)+'%';
 pgT.textContent=(alt/1000).toFixed(1)+' / 100 km';
 var mm=Math.floor(simT/60),ss2=Math.floor(simT%60);sT.textContent=mm+':'+(ss2<10?'0':'')+ss2;
 sMax.textContent=(maxAlt/1000).toFixed(1)+' km';
 sFuel.textContent=Math.round((s1On?fuel1/S1.fuel0:fuel2/S2.fuel0)*100)+'%';
 /* HUD */
 if(phase==='count')hud.innerHTML='<b style="font-size:24px">'+Math.ceil(cd)+'</b>　点火程序启动…';
 else if(phase==='pad'&&throttle>0&&twr<=1)hud.innerHTML='<b class="r">推力不足！</b>推重比 <b class="r">'+twr.toFixed(2)+'</b> &lt; 1，请加大油门';
 else if(phase==='pad')hud.innerHTML='油门为零，推动滑块增加推力';
 else if(phase==='idle')hud.innerHTML='火箭待命中，点击右侧「发射」开始';
 else hud.innerHTML='高度 <b>'+(alt/1000).toFixed(1)+' km</b> · 速度 <b>'+v.toFixed(0)+' m/s</b> · 燃料 <b class="b">'+Math.round((s1On?fuel1/S1.fuel0:fuel2/S2.fuel0)*100)+'%</b>'+(karman?' · <b>已越过卡门线</b>':'');
 renderer.render(scene,camera);
}
loop();
})();
