(function (global) {
  'use strict';
  var M3D = global.M3D, mat4 = M3D.mat4;
  var E = M3D.EARTH, MO = M3D.MOON;
  var R_E = E.R, MU = E.mu, G0 = E.g0, H_ORB = E.alt, R_ORB = E.r;
  var V_ORB = Math.sqrt(MU / R_ORB);
  var DEG = Math.PI / 180;
  var EC = E.center, MC = MO.center, MR = MO.R, MLORB = MO.orbitR;

  var KM_PER_UNIT = E.kmPerUnit;
  var TIME_SCALE = E.timeScale;
  var MS_PER_UNIT = KM_PER_UNIT * 1000 / TIME_SCALE;

  // ---- 上升段质量 / 推力（沿用经仿真标定的参数，保证精确入轨）----
  //  三级半：芯一级 / 助推（液氧煤油，大推力）→ 芯二级（液氧煤油）→ 芯三级（液氢液氧，高比冲，入轨 + 地月转移）。
  //  燃料分配按「同推力-同时长」切分：二级烧完即分离、三级接着烧完入轨，因此整条上升弹道与两级版几乎一致。
  //  注意：本应用的推力 / 比冲为标定值——真空比冲按氢氧级高于煤油级设定（VE3 > VE2），
  //  但三级推力没有按真实 27 t（3 台 YF-75E）缩小，否则在时间压缩后的弹道里撑不住高度（真实工程实态见 README）。
  var PAY = 0.017, FAIR = 0.004, TOW = 0.007;
  var S3D = 0.005, S2D = 0.011, S1D = 0.026, BD = 0.006;
  var BF0 = 0.075, S1F0 = 0.3584, S2F0 = 0.103, S3F0 = 0.098;
  var F1 = 0.06412, FB = 0.01603;
  var F2 = 0.01672, F3 = 0.01672;
  var VE1 = 4.4922, VE2 = 5.5938, VE3 = 6.3000;
  var S3_TLI_K = 0.380;                 // 入轨后保留给地月转移入射（TLI）的芯三级燃料占比
  var GHOST_LIMIT = -0.015;

  var ALPHA_SCHED = [
    [0, 0], [12, 0], [30, 5], [60, 15], [100, 25],
    [156, 35], [210, 55], [320, 72], [400, 80], [580, 90]
  ];
  function openLoopAlpha(met) {
    var A = ALPHA_SCHED;
    if (met <= A[0][0]) return A[0][1] * DEG;
    if (met >= A[A.length - 1][0]) return A[A.length - 1][1] * DEG;
    for (var i = 0; i < A.length - 1; i++) {
      if (met >= A[i][0] && met <= A[i + 1][0]) {
        var u = (met - A[i][0]) / (A[i + 1][0] - A[i][0]);
        return (A[i][1] + (A[i + 1][1] - A[i][1]) * u) * DEG;
      }
    }
    return 0;
  }
  var KG = 0.85, KH = 0.06, VR_CAP = 1.44, W_TERM = 0.62;
  var A_RATE = 3.5 * DEG, AOA_MAX = 10 * DEG;

  var IGN_RAMP = 0.54, SEP_DELAY = 0.3;
  var MET_PITCH = 12, MET_MAXQ = 75, MET_TOWER = 120, MET_FAIRING = 210;

  // ---- 长按加速：按住越久、倍率越高 ----
  // 双箭登月全程很长（1× 实测约 391 s：两段上升各约 94 s，各脚本段合计约 203 s），
  // 固定 3× 仍嫌慢 —— 巡航段（地月转移 42 s、近月制动 12 s、动力下降 30 s）需要更高的巡航倍率。
  // 故按「按住时长」分段爬升，松手立即回到 1×；需要慢看时松手即可。
  // 顶挡 60× 与上升段子步保护相容：dt 在 app 层被钳到 ≤ 0.05 s，
  // 0.05 × 60 = 3 s，按 1/120 s 子步只需 360 步，仍在 update() 的 guard 之内。
  var WARP_TIERS = [3, 10, 25, 60];          // 各挡倍率
  var WARP_TIER_AT = [0, 1.0, 2.5, 4.5];     // 进入各挡所需的按住时长（秒）
  function warpForHold(t) {
    var i = WARP_TIERS.length - 1;
    while (i > 0 && t < WARP_TIER_AT[i]) i--;
    return WARP_TIERS[i];
  }

  var ALT_DENSE = 8 / KM_PER_UNIT, ALT_MID = 22 / KM_PER_UNIT, ALT_THIN = 80 / KM_PER_UNIT;
  var GAIN_A = 40, GAIN_TAU = 0.5;
  var TOWER_CLEAR = 28, GATE_SPAN = 18;
  // 停泊轨道「视觉半径」：与上升段共用同一套高度增益，使停泊轨道环与停泊中的箭体质心严格重合；
  // 遥测仍按真实轨道高度（R_ORB - R_E）显示，画面则用视觉半径。
  var GAIN_ORB = 1 + GAIN_A / (GAIN_TAU + (R_ORB - R_E));
  var R_ORB_VIS = R_E + (R_ORB - R_E) * GAIN_ORB;

  // ---- 转移 / 环月几何 ----
  var R_AP = MR * 2.0;
  var dirToEarth = (function () {
    var dx = EC[0] - MC[0], dy = EC[1] - MC[1], l = Math.sqrt(dx * dx + dy * dy) || 1;
    return [dx / l, dy / l];
  })();
  var PSI_EARTH = Math.atan2(dirToEarth[0], dirToEarth[1]);
  var APPROACH = [MC[0] + dirToEarth[0] * R_AP, MC[1] + dirToEarth[1] * R_AP];
  var THETA_A = Math.atan2(APPROACH[0] - EC[0], APPROACH[1] - EC[1]);
  var RHO_A = Math.hypot(APPROACH[0] - EC[0], APPROACH[1] - EC[1]);
  // LOI 扫掠角：近月制动是「绕月弧线压轨」（切向为主、径向为辅），不是原地反推；
  // 取足够大的扫掠角，机头才能顺着航迹、并与随后的环月段姿态连续（避免倒飞观感）
  var LOI_SWEEP = 1.00;
  // 触地时「活动体原点」（着陆器质心）的半径：着陆腿完全展开、着陆缩放收敛到 1.4 时，
  // 腿末端应恰好落在月面上。该值随着陆器几何 / 展开角 / 着陆缩放一起标定，改动任一项都要重新标定
  // （tests/headless_two_segment.js 里「腿末端离月面 ≤0.12」的断言会兜底）。
  var LAND_PSI_OFF = 1.35;                 // 着陆点相对「正对地球的月面点」的经度偏置（rad）
  //  偏置的作用是把地球从「近乎当顶」拉到「低空」：实测偏置 0 时地球仰角 ≈49°，
  //  而月面镜头要俯视着陆器（视场垂直半角仅 0.45 rad ≈26°），地球必然被挤出画面上缘。
  //  取 1.35 rad 后地球仰角 ≈13°，镜头压低即可把地球纳入天空（见 app.js 的月面机位）。
  var LAND_RM = MR + 1.60;
  var LEG_ROT_DEPLOY = 0.72;                       // 着陆腿撑开角（收拢角由 craft.js 的 legRotStow 给出，单一真源）

  // ---- 真实任务时间锚点（秒）----
  //  两段式：第一次发射（揽月着陆器）MET 0 → 5 天，着陆器就位环月轨道；
  //  第二次发射（梦舟飞船）MET 5 天 → 10 天，环月交会对接；随后船器分离、动力下降、软着陆。
  //  注意：入轨时刻不写死锚点。上升段实际入轨 MET 由仿真取得（state.metInsert），
  //  再在 parkOrbit 段平滑推进到 MET_TLI —— 否则遥测时钟会在入轨瞬间回退（曾回退约 21 s）。
  var SEG2_BASE = 432000;              // 第二次发射的绝对时间基准（第一次发射后约 5 天）
  var MET_TLI = 5400;                            // 地月转移点火（相对本段发射时刻，两段共用）
  var MET_LOI = 360000, MET_LORB = 361200;      // 近月制动 / 入环月（相对本段发射时刻）
  var MET2_RENDEZ = 428000, MET2_DOCK = 432000;  // 第二次发射：交会 / 对接（相对，= 9.9 / 10 天）
  var MET_LSEP = 866000, MET_LAND = 870000;      // 对接后：船器分离 / 月面软着陆（绝对时间）
  var DUR = { park: 6, tli: 7, transit: 42, loi: 12, lorb: 9, transition: 3, rendezvous: 11, dock: 7, descent: 30 };
  var LORB_RATE = 0.028;
  var PARK_RATE = 0.028;              // 驻留着陆器在第二次发射期间的环月角速度
  // 对接后着陆器质心位于飞船质心前方的间距（组合体箭体系；对接机构在飞船头部）。
  // 该值需保证两器「实体」贴合但不互相穿插：1.55（旧值、且方向反了）实测两器边缘只差
  // 0.13 世界单位（scale=10），肉眼可见穿模；1.2 实测留出约 3.6 世界单位（≈1.8 m）的贴合间隙。
  var DOCK_GAP = 1.2;
  var DOCK_PSI_TOL = 0.012;           // 交会对接触发阈值（飞船与着陆器环月角差，弧度）
  var ORB_VIS = 8;                  // 停泊轨道可视自转倍率：真实轨道角速度太慢，放大后一圈可见

  var PHASES = {
    ignition: '点火 · 三芯并联 21 台发动机启动，尾焰喷涌',
    liftoff: '起飞 · 长征十号垂直上升，飞离塔架',
    pitch: '程序转弯 · 按预定俯仰程序缓缓侧转',
    maxQ: '最大动压 · 气动压力达到飞行峰值',
    towerSep: '逃逸塔分离 · 抛离应急救生系统',
    boosterSep: '助推器分离 · 两枚 5 米助推器脱落',
    stage1Sep: '芯一级分离 · 一级关机，箭体脱落',
    stage2Ignition: '芯二级点火 · 液氧煤油二级继续加速',
    stage2Sep: '芯二级分离 · 二级关机分离，芯三级接管',
    stage3Ignition: '芯三级点火 · 氢氧上面级完成入轨加速',
    fairingSepLander: '整流罩分离 · 露出揽月着陆器',
    fairingSepShip: '整流罩分离 · 露出梦舟载人飞船',
    parkOrbitLander: '入轨 · 揽月着陆器进入近地停泊轨道',
    parkOrbitShip: '入轨 · 梦舟飞船进入近地停泊轨道',
    tli: '地月转移入射 · 芯三级二次点火（氢氧），奔赴月球',
    stage3Sep: '芯三级分离 · 上面级关机分离，载荷转入转移轨道',
    transit: '地月转移轨道 · 飞向月球',
    loi: '近月制动 · 反推减速，被月球引力捕获',
    lunarOrbit: '环月飞行 · 在环月轨道上运行',
    landerPark: '着陆器环月待命 · 揽月着陆器驻留环月轨道，等待飞船',
    transition: '数日后 · 第二次发射 · 梦舟载人飞船',
    rendezvous: '交会 · 梦舟飞船接近环月轨道上的着陆器',
    docking: '对接 · 环月轨道交会对接，航天员转入着陆器',
    landerSep: '着陆器与飞船分离 · 揽月着陆器脱离梦舟，转入落月飞行',
    descent: '动力下降 · 下降发动机反推制动',
    approach: '着陆末段 · 展开着陆腿，悬停避障',
    landing: '月面软着陆 · 揽月着陆器平稳触月',
    landed: '着陆成功 · 揽月着陆器安全落月'
  };

  function shortAngle(a) { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; }
  function smoothstep(u) { u = u < 0 ? 0 : (u > 1 ? 1 : u); return u * u * (3 - 2 * u); }
  function lerp(a, b, t) { return a + (b - a) * t; }

  function createMissionSystem(renderer, rocketModel, pad, hooks) {
    hooks = hooks || {};
    var parts = rocketModel.parts;
    // 活动栈质心不写死常量：入轨 / 船箭分离时用 centroidOf() 现场求值并做两级重定基
    // （origin 平移到新的活动体质心、相关部件 baseY 同步回退），模型改动后自动跟随。

    var baseY0 = parts.map(function (p) { return p.baseY; });
    var legRot0 = parts.map(function (p) { return p.localRotX; });
    // 着陆腿收拢角取自模型（craft.js 的 LEG_ROT_STOW）：它同时决定「收拢时脚尖半径」，是罩内
    // 包络的约束值之一，不能在两个文件里各写一份（自检含一致性断言）。
    var LEG_ROT_STOW = rocketModel.legRotStow != null ? rocketModel.legRotStow : 3.06;

    var state = {
      regime: 'ascent', phase: 'prelaunch', t: 0, phaseT: 0,
      r: R_E, theta: 0, vr: 0, vt: 0,
      alpha: 0, gamma: Math.PI / 2, tilt: Math.PI / 2, tiltVis: 0,
      x: 0, y: 0, alt: 0, altVis: 0, speed: 0, vCirc: V_ORB,
      mass: 1.02, accel: 0, met: 0, metInsert: MET_TLI,
      fuel1: S1F0, fuel2: S2F0, fuel3: S3F0, fuelBoost: BF0,
      boostersAttached: true, stage1Attached: true, towerAttached: false, fairingAttached: true,
      stage2Attached: true, stage3Attached: true,
      ignited: false, inserted: false, landed: false, warp: 1, holdT: 0, scale: 1, hold: false,
      shipAttached: true, focus: rocketModel.center, progress: 0, sepT: 0, _altMax: 0, camDist: 20,
      engLocalY: 0.18, engSize: 1, burning: false, legsDeploy: 0,
      distEarth: 0, distMoon: MO.dist * KM_PER_UNIT, moonAlt: 0,
      psi: PSI_EARTH, rm: R_AP, rm0: MLORB, psi0: PSI_EARTH,
      transitTheta0: 0, transitRho0: R_E, parkAng: null,
      moonBlend: 0, surfCamBlend: 0,
      // ---- 两段式（双箭发射）状态 ----
      segment: 1, metBase: 0, variant: 1, landerParked: false, parkPsi: PSI_EARTH, docked: false,
      rendezOffset: 0, dockA0: PSI_EARTH, rmSepDock: MLORB, camSnap: false, segFade: 0, segFadeT: 0
    };
    var fired = {}, acc = {};
    var panels = [], landerParts = [], legParts = [], shipParts = [];
    var stack2Parts = [], stack1Parts = [];       // 第一次发射：入轨活动栈 / 船箭分离后活动栈
    var stackS1Parts = [], stackS2Parts = [];     // 第二次发射：入轨活动栈 / 船箭分离后活动栈
    for (var pi = 0; pi < parts.length; pi++) {
      var g = parts[pi].detachGroup, nm = parts[pi].name;
      if (g === 'panel') panels.push(parts[pi]);
      if (g === 'lander') landerParts.push(parts[pi]);
      if (nm.indexOf('leg') === 0) legParts.push(parts[pi]);
      if (g === 'ship') shipParts.push(parts[pi]);
      // 第一次发射：入轨活动栈 = 芯二级 + 芯三级 + 着陆器；三级分离后 = 着陆器
      if (g === 'lander' || g === 'stage2' || g === 'stage3') stack1Parts.push(parts[pi]);
      if (g === 'lander') stack2Parts.push(parts[pi]);
      // 第二次发射：入轨活动栈 = 芯二级 + 芯三级 + 飞船 + 太阳翼；三级分离后 = 飞船 + 太阳翼
      if (g === 'ship' || g === 'panel' || g === 'stage2' || g === 'stage3') stackS1Parts.push(parts[pi]);
      if (g === 'ship' || g === 'panel') stackS2Parts.push(parts[pi]);
    }

    // 部件在箭体系中的当前质心（baseY + centerY 的均值）
    function centroidOf(list) {
      if (!list.length) return 0;
      var s = 0;
      for (var i = 0; i < list.length; i++) s += list[i].baseY + list[i].centerY;
      return s / list.length;
    }

    function captionFor(key) {
      if (key === 'parkOrbit') return state.segment === 2 ? PHASES.parkOrbitShip : PHASES.parkOrbitLander;
      if (key === 'fairingSep') return state.segment === 2 ? PHASES.fairingSepShip : PHASES.fairingSepLander;
      return PHASES[key];
    }
    function firePhase(key) {
      if (fired[key]) return;
      fired[key] = true;
      var text = captionFor(key);
      if (text && hooks.onPhase) hooks.onPhase(key, text);
    }
    function rezero(list, delta) { for (var i = 0; i < list.length; i++) list[i].baseY -= delta; }

    // ---- 尾焰网格 ----
    var flameCore = renderer.createMesh(M3D.geom.cylinder(0.30, 0.0001, 2.0, 16), [1.0, 0.55, 0.15], { group: 'fx' });
    flameCore.alpha = 0; flameCore.glow = 1; flameCore.visible = false;
    var flameOuter = renderer.createMesh(M3D.geom.cylinder(0.46, 0.0001, 1.45, 16), [1.0, 0.40, 0.06], { group: 'fx', blend: 'add', depthWrite: false });
    flameOuter.alpha = 0; flameOuter.glow = 1; flameOuter.visible = false;
    var glowDisc = renderer.createMesh(M3D.geom.disk(0.30, 16), [1.0, 0.88, 0.60], { group: 'fx', blend: 'add', depthWrite: false });
    glowDisc.alpha = 0; glowDisc.glow = 1; glowDisc.visible = false;
    var flameBoost = [];
    for (var fb = 0; fb < 2; fb++) {
      var fm = renderer.createMesh(M3D.geom.cylinder(0.22, 0.0001, 1.5, 12), [1.0, 0.5, 0.12], { group: 'fx' });
      fm.alpha = 0; fm.glow = 1; fm.visible = false; flameBoost.push(fm);
    }
    var machRingG = M3D.geom.torus(0.30, 0.045, 20, 7), machRings = [];
    for (var mr = 0; mr < 4; mr++) {
      var mm = renderer.createMesh(machRingG, [0.72, 0.84, 1.0], { group: 'fx', blend: 'add', depthWrite: false });
      mm.glow = 1; mm.visible = false; mm.alpha = 0; machRings.push(mm);
    }
    var nozParts = { s1: [], boost: [], s2: [], s3: [], lander: [], ship: [] };
    for (var np = 0; np < parts.length; np++) {
      var pn = parts[np].name;
      if (pn.indexOf('nozCore') === 0) nozParts.s1.push(parts[np]);          // 芯一级 7 台 YF-100K
      else if (pn.indexOf('boostNoz') === 0) nozParts.boost.push(parts[np]);  // 助推器各 7 台
      else if (pn.indexOf('nozS2') === 0) nozParts.s2.push(parts[np]);        // 芯二级 2 台 YF-100M
      else if (pn.indexOf('nozS3') === 0) nozParts.s3.push(parts[np]);        // 芯三级 3 台 YF-75E
      else if (pn === 'landerNozzle') nozParts.lander.push(parts[np]);
      else if (pn === 'svcModule') nozParts.ship.push(parts[np]);   // 梦舟服务舱主发动机（第二次发射深空段）
    }
    function engY(which) {
      var l = which === 's1' ? nozParts.s1
        : (which === 's2' ? nozParts.s2
          : (which === 's3' ? nozParts.s3
            : (which === 'ship' ? nozParts.ship : nozParts.lander)));
      return l.length ? l[0].baseY : 0;
    }

    // 说明：近地停泊轨道不再画环线（地球旁一圈蓝线观感多余，箭体自身已由遥测标明高度）

    var moonRing = renderer.createMesh(M3D.geom.torus(MLORB, 5, 200, 6), [0.62, 0.74, 1.0], { group: 'fx', blend: 'add', depthWrite: false });
    moonRing.glow = 1;
    mat4.identity(moonRing.modelMatrix);
    mat4.translate(moonRing.modelMatrix, moonRing.modelMatrix, MC);
    mat4.rotateX(moonRing.modelMatrix, moonRing.modelMatrix, Math.PI / 2);
    moonRing.alpha = 0; moonRing.visible = false;

    // ---- 坐标变换 ----
    var _lw = [0, 0, 0];
    function localToWorld(lx, ly, lz, out) {
      var c = Math.cos(state.tiltVis), s = Math.sin(state.tiltVis);
      out = out || _lw;
      out[0] = lx * c + ly * s + state.x;
      out[1] = -lx * s + ly * c + state.y;
      out[2] = lz;
      return out;
    }
    function localDirToWorld(dx, dy, dz, out) {
      var c = Math.cos(state.tiltVis), s = Math.sin(state.tiltVis);
      out = out || _lw;
      out[0] = dx * c + dy * s; out[1] = -dx * s + dy * c; out[2] = dz;
      return out;
    }
    function bodyToWorld(lx, ly, lz, out) {
      var s = state.scale;
      return localToWorld(lx * s, ly * s, lz * s, out);
    }

    function syncWorldAscent() {
      var h = Math.max(0, state.r - R_E);
      var gain = 1 + GAIN_A / (GAIN_TAU + h);
      var hv = h * gain;
      if (hv < state._altMax) hv = state._altMax; else state._altMax = hv;
      var rho = R_E + hv;
      state.x = EC[0] + rho * Math.sin(state.theta);
      state.y = EC[1] + rho * Math.cos(state.theta);
      state.altVis = hv;
      state.tilt = state.theta + state.alpha;
      var g8 = (state.altVis - TOWER_CLEAR) / GATE_SPAN;
      g8 = g8 < 0 ? 0 : (g8 > 1 ? 1 : g8 * g8 * (3 - 2 * g8));
      state.tiltVis = state.tilt * g8;
      state.alt = state.r - R_E;
      state.speed = Math.sqrt(state.vr * state.vr + state.vt * state.vt);
      state.met = state.metBase + state.t * TIME_SCALE;
      state.distEarth = state.r * KM_PER_UNIT;
      state.distMoon = Math.hypot(state.x - MC[0], state.y - MC[1]) * KM_PER_UNIT;
      if (state.segment === 2) state.progress = 0.50 + Math.min(0.20, (state.t / 95) * 0.20);
      else state.progress = Math.min(0.30, (state.t / 95) * 0.30);
    }

    function currentMass() {
      var m = PAY;
      if (state.stage3Attached) m += S3D + state.fuel3;
      if (state.stage2Attached) m += S2D + state.fuel2;
      if (state.stage1Attached) m += S1D + state.fuel1;
      if (state.boostersAttached) m += 4 * (BD + state.fuelBoost);
      if (state.towerAttached) m += TOW;
      if (state.fairingAttached) m += FAIR;
      return m;
    }
    function currentThrust() {
      if (state.phase === 'ignition') return (F1 + 4 * FB) * Math.min(state.t / IGN_RAMP, 1);
      if (state.phase === 'burn1') return F1 + (state.boostersAttached ? 4 * FB : 0);
      if (state.phase === 'burn2') return state.fuel2 > GHOST_LIMIT ? F2 : 0;
      if (state.phase === 'burn3') return state.fuel3 > GHOST_LIMIT ? F3 : 0;
      return 0;
    }
    function isBurningPhys() {
      if (state.phase === 'ignition' || state.phase === 'burn1') return true;
      if (state.phase === 'burn2') return state.fuel2 > GHOST_LIMIT;
      if (state.phase === 'burn3') return state.fuel3 > GHOST_LIMIT;
      return false;
    }

    function detach(group) {
      var w = [0, 0, 0];
      for (var i = 0; i < parts.length; i++) {
        var p = parts[i];
        if (p.detachGroup !== group || p.detached) continue;
        p.detached = true; p.detachT = state.t;
        p.detachBaseY = state.y; p.detachX = state.x; p.detachPitch = state.tiltVis; p.detachScale = state.scale;
        p.detachOff = [0, 0, 0]; p.detachRot = [0, 0, 0];
        if (group === 'booster') {
          var len = Math.sqrt(p.ox * p.ox + p.oz * p.oz) || 1;
          p.detachV = localDirToWorld((p.ox / len) * 1.5, -0.9, (p.oz / len) * 1.5, [0, 0, 0]).slice();
          p.detachSpin = [(Math.random() - 0.5) * 1.6, (Math.random() - 0.5) * 1.2];
        } else if (group === 'tower') {
          p.detachV = localDirToWorld(0.5, 3.4, 0.2, [0, 0, 0]).slice();
          p.detachSpin = [(Math.random() - 0.5) * 1.2, (Math.random() - 0.5) * 1.2];
        } else if (group === 'fairing') {
          var fsd = p.side || 1;
          p.detachV = localDirToWorld(fsd * 1.35, 1.7, 0.4, [0, 0, 0]).slice();
          p.detachSpin = [(Math.random() - 0.5) * 0.9, fsd * (1.1 + Math.random() * 0.5)];
        } else if (group === 'stage1') {
          p.detachV = localDirToWorld((Math.random() - 0.5) * 0.32, -2.2, (Math.random() - 0.5) * 0.32, [0, 0, 0]).slice();
          p.detachSpin = [(Math.random() - 0.5) * 0.7, (Math.random() - 0.5) * 0.7];
        } else if (group === 'stage2') {
          p.detachV = localDirToWorld((Math.random() - 0.5) * 0.2, -1.6, (Math.random() - 0.5) * 0.2, [0, 0, 0]).slice();
          p.detachSpin = [(Math.random() - 0.5) * 0.4, (Math.random() - 0.5) * 0.4];
        } else if (group === 'stage3') {
          p.detachV = localDirToWorld((Math.random() - 0.5) * 0.18, -1.3, (Math.random() - 0.5) * 0.18, [0, 0, 0]).slice();
          p.detachSpin = [(Math.random() - 0.5) * 0.34, (Math.random() - 0.5) * 0.34];
        }
      }
      var n = group === 'tower' ? 22 : (group === 'stage1' ? 26 : 20);
      if (group === 'booster') {
        for (var b = 0; b < 2; b++) {
          var ba = b * Math.PI + Math.PI / 2;
          localToWorld(Math.cos(ba) * rocketModel.boosterDist, 1.9, Math.sin(ba) * rocketModel.boosterDist, w);
          flashAt(w[0], w[1], w[2], 16);
        }
      } else {
        // 分级分离的闪光位置（箭体系 Y）：塔架在最上，整流罩次之，其后是三级 / 二级 / 一级发动机
        var ly = group === 'tower' ? 11.9
          : (group === 'stage1' ? 6.2
            : (group === 'fairing' ? 10.0
              : (group === 'stage2' ? engY('s2') : (group === 'stage3' ? engY('s3') : 1.6))));
        bodyToWorld(0, ly, 0, w);
        flashAt(w[0], w[1], w[2], n, 1);
      }
    }

    function separateLander() {
      var w = [0, 0, 0];
      // 着陆器质心相对当前原点（对接后的组合体，focus=0 位于飞船质心附近）；
      // 用实时质心而非固定常量，兼容「双箭对接」后着陆器位于飞船前方的构型。
      var landerLocal = centroidOf(landerParts);
      bodyToWorld(0, landerLocal, 0, w);
      var lx = w[0], ly = w[1];
      // 梦舟整体（返回舱 + 服务舱 + 太阳翼）作为「一个刚体」沿飞行方向缓缓漂离：
      // 所有部件必须共用同一速度且零自旋 —— 若逐块给随机速度/自旋，各舱段会各飞各的、各自翻滚，
      // 看上去就是「飞船解体」。飞船按方案要驻留环月轨道等待返回，因此也不做淡出消失。
      var fwdX = Math.sin(state.tiltVis), fwdY = Math.cos(state.tiltVis);
      var shipV = [fwdX * 0.5, fwdY * 0.5, 0];     // 世界单位 / 场景秒
      for (var i = 0; i < shipParts.length; i++) {
        var p = shipParts[i];
        p.detached = true; p.detachT = state.t;
        p.detachBaseY = state.y; p.detachX = state.x; p.detachPitch = state.tiltVis; p.detachScale = state.scale;
        p.detachOff = [0, 0, 0]; p.detachRot = [0, 0, 0];
        p.detachV = shipV.slice(); p.detachSpin = [0, 0, 0];
        p.detachFade = false;                      // 保持可见，驻留环月轨道
      }
      for (var j = 0; j < panels.length; j++) {
        var q = panels[j];
        q.detached = true; q.detachT = state.t;
        q.detachBaseY = state.y; q.detachX = state.x; q.detachPitch = state.tiltVis; q.detachScale = state.scale;
        q.detachOff = [0, 0, 0]; q.detachRot = [0, 0, 0];
        q.detachV = shipV.slice(); q.detachSpin = [0, 0, 0];
        q.detachFade = false;
      }
      flashAt(lx, ly, 0, 26, 1.1);
      // 着陆器成为活动体：重心归零、原点移到着陆器质心
      rezero(landerParts, landerLocal);
      state.x = lx; state.y = ly; state.focus = 0;
      state.shipAttached = false;
      // 由着陆器质心反推月心极坐标，作为动力下降起点（保证连续无跳变）
      state.rm0 = Math.hypot(lx - MC[0], ly - MC[1]);
      state.psi0 = Math.atan2(lx - MC[0], ly - MC[1]);
      for (var k = 0; k < legParts.length; k++) legParts[k].mesh.visible = true;
    }

    // ---- 第一次发射结束：着陆器「驻留」环月轨道 ----
    //  着陆器转为独立渲染体（parked），第二次发射期间持续绕月，等待飞船交会。
    function parkLander() {
      state.parkPsi = state.psi;
      state.landerParked = true;
      for (var i = 0; i < landerParts.length; i++) {
        var p = landerParts[i];
        p.parked = true; p.detached = true; p.detachT = state.t;
        p.detachOff = [0, 0, 0]; p.detachV = [0, 0, 0];
        p.detachRot = [0, 0, 0]; p.detachSpin = [0, 0, 0]; p.detachScale = state.scale;
      }
    }

    // ---- 每帧直接写入驻留着陆器的模型矩阵（复刻 updatePartTransforms 数学）----
    function positionParkedLander() {
      if (!state.landerParked) return;
      var psi = state.parkPsi;
      var ox = MC[0] + MLORB * Math.sin(psi);
      var oy = MC[1] + MLORB * Math.cos(psi);
      var tilt = progradeTilt(psi);
      var s = state.scale;
      var alpha = state.moonBlend;             // 随月球一同淡入淡出
      var vis = alpha > 0.01;
      for (var i = 0; i < landerParts.length; i++) {
        var p = landerParts[i];
        var m = p.tmp;
        mat4.identity(m);
        mat4.translate(m, m, [ox, oy, 0]);
        if (s !== 1) mat4.scale(m, m, [s, s, s]);
        mat4.rotateZ(m, m, -tilt);
        mat4.translate(m, m, [p.ox, p.baseY + p.centerY, p.oz]);
        if (p.localRotY) mat4.rotateY(m, m, p.localRotY);
        if (p.localRotX) mat4.rotateX(m, m, p.localRotX);
        mat4.translate(m, m, [0, -p.centerY, 0]);
        var mm = p.mesh.modelMatrix;
        for (var k = 0; k < 16; k++) mm[k] = m[k];
        // 着陆腿驻留轨道时收起隐藏（与飞行段一致），其余部件随月球淡入
        var isLeg = p.name.indexOf('leg') === 0;
        p.mesh.alpha = isLeg ? 0 : alpha;
        p.mesh.visible = isLeg ? false : vis;
      }
    }

    // ---- 段间过渡：把箭体复原为「第二次发射（载人飞船）」构型 ----
    function resetForSegment2() {
      // 箭体切到载人构型；着陆器正在环月驻留，由 positionParkedLander 独立渲染，故跳过
      applyConfig(2, true);
      // 上升段物理状态复位（同一枚长征十号，物理参数不变）
      state.segment = 2; state.metBase = SEG2_BASE;
      state.regime = 'ascent'; state.phase = 'ignition'; state.phaseT = 0; state.t = 0;
      state.r = R_E; state.theta = 0; state.vr = 0; state.vt = 0;
      state.alpha = 0; state.gamma = Math.PI / 2; state.tilt = Math.PI / 2; state.tiltVis = 0;
      state.x = 0; state.y = 0; state.alt = 0; state.altVis = 0; state._altMax = 0;
      state.fuel1 = S1F0; state.fuel2 = S2F0; state.fuel3 = S3F0; state.fuelBoost = BF0;
      state.boostersAttached = true; state.stage1Attached = true; state.stage2Attached = true; state.stage3Attached = true;
      state.towerAttached = true; state.fairingAttached = true;   // 载人构型同样是「逃逸塔 + 整流罩」
      state.inserted = false; state.scale = 1; state.focus = rocketModel.center;
      state.shipAttached = true; state.docked = false; state.sepT = 0;
      state.engLocalY = 0.18; state.engSize = 1; state.burning = false; state.legsDeploy = 0;
      state.parkAng = null; state.moonBlend = 0; state.surfCamBlend = 0;
      state.metInsert = MET_TLI; state.rmSepDock = MLORB;
      state.rm = R_AP; state.psi = PSI_EARTH;
      state.distEarth = 0; state.distMoon = MO.dist * KM_PER_UNIT; state.moonAlt = 0;
      state.met = SEG2_BASE; state.progress = 0.50; state.camSnap = true;
      state.segFade = 1; state.segFadeT = 1.0;      // 黑场保持，随后淡入到第二次发射的箭体
      // 发射台 / 地球复位
      pad.armSwing = 0; M3D.setArmSwing(pad, 0);
      pad.earthSpin = 0; M3D.spinEarth(pad, 0, 0);
      if (pad.ember) pad.ember.glow = 0;
      for (var li = 0; li < legParts.length; li++) legParts[li].localRotX = legRot0[parts.indexOf(legParts[li])];
      // 清除已触发标记，第二次发射重新播报；驻留着陆器仍绕月
      fired = {};
      firePhase('ignition');
    }

    // ---- 交会对接：解除着陆器驻留，接合到飞船「前方」构成环月组合体 ----
    //  对接机构位于飞船头部（箭体 +Y，即环月前进方向），故着陆器应落在飞船前方，
    //  与交会段「飞船在着陆器后方追近」的终态一致（否则两器相对位形反向，必然穿模）。
    function dockLander() {
      var w = [0, 0, 0];
      var curC = centroidOf(landerParts);      // 驻留时着陆器质心（≈ 0）
      var targetC = DOCK_GAP;                  // 置于飞船（focus≈0）前方
      rezero(landerParts, curC - targetC);
      for (var i = 0; i < landerParts.length; i++) {
        var p = landerParts[i];
        p.parked = false; p.detached = false; p.detachT = state.t;
        p.detachOff = [0, 0, 0]; p.detachV = [0, 0, 0];
        p.detachRot = [0, 0, 0]; p.detachSpin = [0, 0, 0];
        p.detachScale = 1; p.mesh.alpha = 1;
      }
      state.landerParked = false; state.docked = true; state.shipAttached = true; state.focus = 0;
      // 记录组合体原点自身的极坐标：环月段「绕月心整体旋转」，而不是把原点硬拉回圆轨道
      // （交会终点飞船原点就在圆轨道上，此处保持自洽、零瞬移）。
      state.dockA0 = Math.atan2(state.x - MC[0], state.y - MC[1]);
      state.rmSepDock = state.rm;
      bodyToWorld(0, targetC, 0, w);
      flashAt(w[0], w[1], 0, 24, 1.0);
    }

    function flashAt(x, y, z, n, szK) {
      var k = szK || 1;
      for (var i = 0; i < n; i++) {
        var a = Math.random() * Math.PI * 2, rr = Math.random() * 0.5, sp = (2 + Math.random() * 3) * k;
        renderer.particles.spawn(
          x + Math.cos(a) * rr * k, y + (Math.random() - 0.4) * 0.5 * k, z + Math.sin(a) * rr * k,
          Math.cos(a) * sp, (Math.random() - 0.2) * sp, Math.sin(a) * sp,
          1.0, 0.92, 0.6, 0.22 + Math.random() * 0.2, 1.2 * k);
      }
    }

    // ---- 粒子 ----
    function spawnFlames(dt) {
      if (!state.burning) return;
      var ramp = state.phase === 'ignition' ? Math.min(state.t / IGN_RAMP, 1) : 1;
      var noz = bodyToWorld(0, state.engLocalY, 0, [0, 0, 0]);
      var down = localDirToWorld(0, -1, 0, [0, 0, 0]);
      var ascent = state.regime === 'ascent';
      var thin = ascent ? (state.alt > ALT_THIN) : true;
      var sizeK = state.engSize * state.scale;
      var coreRate = (ascent ? (state.stage1Attached ? 58 : 34) : 30) * (thin ? 0.6 : 1);
      acc.core = (acc.core || 0) + coreRate * dt * ramp;
      while (acc.core >= 1) {
        acc.core -= 1;
        var a = Math.random() * Math.PI * 2, rr = Math.random() * 0.16 * (thin ? 2.0 : 1);
        var off = localDirToWorld(Math.cos(a) * rr, 0, Math.sin(a) * rr, [0, 0, 0]);
        var sp = (6 + Math.random() * 5) * ramp * sizeK;
        renderer.particles.spawn(
          noz[0] + off[0] * sizeK, noz[1] + off[1] * sizeK, noz[2] + off[2] * sizeK,
          off[0] * 4 + down[0] * sp + (Math.random() - 0.5) * 1.4,
          down[1] * sp + (Math.random() - 0.5) * 0.5,
          off[2] * 4 + down[2] * sp + (Math.random() - 0.5) * 1.4,
          1.0, 0.36 + Math.random() * 0.35, 0.05 + Math.random() * 0.12, 0.4 + Math.random() * 0.35, (thin ? 1.6 : 1.0) * sizeK);
      }
      if (ascent && state.boostersAttached && state.stage1Attached) {
        acc.boost = (acc.boost || 0) + 40 * dt * ramp;
        while (acc.boost >= 1) {
          acc.boost -= 1;
          var bi = (Math.random() * 2) | 0, ba2 = bi * Math.PI + Math.PI / 2;
          var bw = localToWorld(Math.cos(ba2) * rocketModel.boosterDist, 0.14, Math.sin(ba2) * rocketModel.boosterDist, [0, 0, 0]);
          var a3 = Math.random() * Math.PI * 2, r3 = Math.random() * 0.12;
          var off3 = localDirToWorld(Math.cos(a3) * r3, 0, Math.sin(a3) * r3, [0, 0, 0]);
          var bs = (5 + Math.random() * 4) * ramp;
          renderer.particles.spawn(
            bw[0] + off3[0], bw[1] + off3[1], bw[2] + off3[2],
            off3[0] * 3 + down[0] * bs + (Math.random() - 0.5) * 0.9,
            down[1] * bs + (Math.random() - 0.5) * 0.4,
            off3[2] * 3 + down[2] * bs + (Math.random() - 0.5) * 0.9,
            1.0, 0.32 + Math.random() * 0.3, 0.04 + Math.random() * 0.1, 0.4 + Math.random() * 0.3, 1.0);
        }
      }
      if (ascent && state.alt < ALT_THIN) {
        var dense = state.alt < ALT_DENSE, thinAir = state.alt > ALT_MID;
        acc.smoke = (acc.smoke || 0) + (dense ? 60 : (thinAir ? 24 : 42)) * dt;
        while (acc.smoke >= 1) {
          acc.smoke -= 1;
          var sa = Math.random() * Math.PI * 2, sr = 0.15 + Math.random() * 0.55;
          var sw = localToWorld(Math.cos(sa) * sr, state.engLocalY - 0.6, Math.sin(sa) * sr, [0, 0, 0]);
          var sv = (dense ? 1.1 : 0.7) + Math.random() * (dense ? 1.9 : 1.3);
          var st = 0.55 + Math.random() * 0.22;
          renderer.particles.spawnSmoke(sw[0], sw[1], sw[2],
            down[0] * sv + (Math.random() - 0.5) * 2.2, down[1] * sv + (Math.random() - 0.5) * 0.7, down[2] * sv + (Math.random() - 0.5) * 2.2,
            st, st, st * 1.03,
            (dense ? 3.0 : 2.2) + Math.random() * (dense ? 2.8 : 2.4),
            (dense ? 1.1 : 0.8) + Math.random() * (dense ? 1.1 : 0.9),
            (dense ? 1.4 : 1.1) + Math.random() * 1.1, thinAir ? 0.7 : 1.3);
        }
      }
    }

    function spawnPadSmoke(dt) {
      var k = state.t < IGN_RAMP ? 0.6 : Math.max(0, 1 - (state.t - IGN_RAMP) / 5.0);
      if (k <= 0.02 && state.altVis >= 6) return;
      var rate = 95 * Math.max(k, 0.18) + (state.altVis < 6 ? 26 : 0);
      acc.pad = (acc.pad || 0) + rate * dt;
      while (acc.pad >= 1) {
        acc.pad -= 1;
        var a = Math.random() * Math.PI * 2, r = 0.35 + Math.random() * 4.4;
        var ca = Math.cos(a), sa2 = Math.sin(a);
        var outV = 1.2 + Math.random() * 3.4, swirl = (Math.random() - 0.5) * 3.2, upV = 1.2 + Math.random() * 3.6;
        var tint = 0.46 + Math.random() * 0.22, warm = Math.random() < 0.22;
        renderer.particles.spawnSmoke(ca * r, 0.15 + Math.random() * 0.7, sa2 * r,
          ca * outV - sa2 * swirl, upV, sa2 * outV + ca * swirl,
          warm ? 0.82 : tint, warm ? 0.55 : tint, warm ? 0.36 : tint * 1.05,
          3.2 + Math.random() * 3.2, 1.6 + Math.random() * 2.0, 1.2 + Math.random() * 1.2, 1.5, 0.06);
      }
    }

    function spawnLunarDust(dt, intensity) {
      var noz = bodyToWorld(0, state.engLocalY - 0.2, 0, [0, 0, 0]);
      var up = localDirToWorld(0, 1, 0, [0, 0, 0]);
      acc.dust = (acc.dust || 0) + 110 * intensity * dt;
      while (acc.dust >= 1) {
        acc.dust -= 1;
        var a = Math.random() * Math.PI * 2;
        var t1x = -up[1], t1y = up[0], tl = Math.hypot(t1x, t1y) || 1; t1x /= tl; t1y /= tl;
        var sp = (2 + Math.random() * 6) * (0.5 + intensity);
        var dx = t1x * Math.cos(a), dy = t1y * Math.cos(a), dz = Math.sin(a) * 0.7;
        renderer.particles.spawnSmoke(
          noz[0] + dx * 0.3, noz[1] + dy * 0.3, noz[2],
          dx * sp - up[0] * sp * 0.2, dy * sp - up[1] * sp * 0.2, dz * sp * 0.5,
          0.56, 0.54, 0.51, 2.4 + Math.random() * 2.2, 0.8 + Math.random() * 1.5, 1.5 + Math.random() * 1.6, 1.3, 0.0);
      }
    }

    function spawnTrail(dt) {
      acc.trail = (acc.trail || 0) + 30 * dt;
      var sz = Math.max(1.5, Math.min(14, state.camDist * 0.0022));
      var hw = bodyToWorld(0, state.focus, 0, [0, 0, 0]);
      renderer.particles.spawn(hw[0], hw[1], hw[2], 0, 0, 0, 0.45, 0.75, 1.0, Math.max(dt * 2.4, 0.05), state.scale * 2.2, 0);
      while (acc.trail >= 1) {
        acc.trail -= 1;
        var w = bodyToWorld((Math.random() - 0.5) * 0.12, state.focus + (Math.random() - 0.5) * 0.12, (Math.random() - 0.5) * 0.12, [0, 0, 0]);
        renderer.particles.spawn(w[0], w[1], w[2], 0, 0, 0, 0.30, 0.72, 1.0, 3.2, sz * (0.8 + Math.random() * 0.4), 0, -0.45);
      }
    }

    function syncFlames() {
      var thrust = state.burning;
      var flick = 1 + Math.sin(state.t * 42) * 0.16 + Math.sin(state.t * 23 + 1.7) * 0.1;
      var sizeK = state.engSize * state.scale;
      var nozW = bodyToWorld(0, state.engLocalY, 0, [0, 0, 0]);
      var widen = 1 + (state.regime === 'ascent' ? Math.min(state.alt / ALT_THIN, 1) : 1) * 1.3;
      var m = flameCore.modelMatrix;
      mat4.identity(m);
      mat4.translate(m, m, [nozW[0], nozW[1], nozW[2]]);
      mat4.rotateZ(m, m, -state.tiltVis);
      mat4.scale(m, m, [sizeK * widen, flick * sizeK, sizeK * widen]);
      mat4.translate(m, m, [0, -2.0, 0]);
      flameCore.visible = thrust; flameCore.alpha = thrust ? 0.8 : 0;

      var mo = flameOuter.modelMatrix;
      mat4.identity(mo);
      mat4.translate(mo, mo, [nozW[0], nozW[1], nozW[2]]);
      mat4.rotateZ(mo, mo, -state.tiltVis);
      mat4.scale(mo, mo, [sizeK * widen * 1.35, flick * sizeK * 0.78, sizeK * widen * 1.35]);
      mat4.translate(mo, mo, [0, -1.45, 0]);
      flameOuter.visible = thrust; flameOuter.alpha = thrust ? 0.30 : 0;

      var machOn = thrust && state.regime === 'ascent' && state.alt * KM_PER_UNIT > 4 && state.alt * KM_PER_UNIT < 90;
      var machK = Math.max(0, Math.min(1, (state.alt * KM_PER_UNIT - 4) / 10));
      for (var mi = 0; mi < machRings.length; mi++) {
        var hM = 0.45 + mi * 0.38, rFac = 0.75 - mi * 0.13;
        var mmr = machRings[mi].modelMatrix;
        mat4.identity(mmr);
        mat4.translate(mmr, mmr, [nozW[0], nozW[1], nozW[2]]);
        mat4.rotateZ(mmr, mmr, -state.tiltVis);
        mat4.scale(mmr, mmr, [sizeK * widen * rFac, flick * sizeK, sizeK * widen * rFac]);
        mat4.translate(mmr, mmr, [0, -hM, 0]);
        machRings[mi].visible = machOn;
        machRings[mi].alpha = machOn ? 0.5 * machK * (1 - mi * 0.14) * (0.7 + 0.3 * flick) : 0;
      }

      var md = glowDisc.modelMatrix;
      mat4.identity(md);
      mat4.translate(md, md, [nozW[0], nozW[1], nozW[2]]);
      mat4.scale(md, md, [sizeK, sizeK, sizeK]);
      mat4.rotateZ(md, md, -state.tiltVis);
      mat4.rotateX(md, md, Math.PI);
      glowDisc.visible = thrust; glowDisc.alpha = thrust ? 0.85 : 0;

      var heat = thrust ? (0.30 + 0.08 * Math.sin(state.t * 36)) : 0;
      var s1On = state.regime === 'ascent' && state.stage1Attached && state.phase !== 'burn2';
      for (var hi = 0; hi < nozParts.s1.length; hi++) nozParts.s1[hi].mesh.glow = s1On ? heat : 0;
      for (hi = 0; hi < nozParts.boost.length; hi++) nozParts.boost[hi].mesh.glow = (s1On && state.boostersAttached) ? heat : 0;
      var s2On = state.phase === 'burn2' && state.stage2Attached;
      for (hi = 0; hi < nozParts.s2.length; hi++) nozParts.s2[hi].mesh.glow = s2On ? heat * 1.2 : 0;
      // 芯三级：入轨加速（burn3）与地月转移入射（tli）两次点火
      var s3On = (state.phase === 'burn3' || (state.phase === 'tli' && state.burning)) && state.stage3Attached;
      for (hi = 0; hi < nozParts.s3.length; hi++) nozParts.s3[hi].mesh.glow = s3On ? heat * 1.2 : 0;
      // 第二次发射：深空段由梦舟服务舱主发动机工作（近月制动 / 交会），喷管同步发红
      var shipOn = state.segment === 2 && state.burning &&
        (state.phase === 'loi' || state.phase === 'rendezvous');
      for (hi = 0; hi < nozParts.ship.length; hi++) nozParts.ship[hi].mesh.glow = shipOn ? heat * 1.1 : 0;
      // 着陆器喷管：第一次发射自己做近月制动，以及本段动力下降 / 着陆末段
      var ldOn = state.phase === 'descent' || state.phase === 'approach' ||
        (state.segment === 1 && state.phase === 'loi');
      for (hi = 0; hi < nozParts.lander.length; hi++) nozParts.lander[hi].mesh.glow = ldOn ? heat * 1.1 : 0;

      var boostOn = thrust && state.regime === 'ascent' && state.boostersAttached && state.stage1Attached;
      for (var i = 0; i < 2; i++) {
        var ba = i * Math.PI + Math.PI / 2;
        var w = localToWorld(Math.cos(ba) * rocketModel.boosterDist, 0.1, Math.sin(ba) * rocketModel.boosterDist, [0, 0, 0]);
        var bm = flameBoost[i].modelMatrix;
        mat4.identity(bm);
        mat4.translate(bm, bm, [w[0], w[1], w[2]]);
        mat4.rotateZ(bm, bm, -state.tiltVis);
        mat4.scale(bm, bm, [widen, flick, widen]);
        mat4.translate(bm, bm, [0, -1.5, 0]);
        flameBoost[i].visible = boostOn; flameBoost[i].alpha = boostOn ? 0.8 : 0;
      }
    }

    // ============ 上升段物理 ============
    function stepAscent(dt) {
      state.t += dt;
      var metL = state.t * TIME_SCALE;      // 本段发射的任务时刻（用于上升段事件触发，两段共用同一套阈值）
      var m = state.mass = currentMass();
      var F = currentThrust();
      var A = F / m;
      var g = MU / (state.r * state.r);
      var h = state.r - R_E;
      var v = Math.sqrt(state.vr * state.vr + state.vt * state.vt) || 1e-6;
      var gamma = Math.atan2(state.vr, state.vt);

      var aCmd = 0;
      if (state.phase !== 'ignition' && metL >= MET_PITCH) {
        aCmd = openLoopAlpha(metL);
        var vCircNow = Math.sqrt(MU / state.r);
        var w = Math.max(0, Math.min(1, (v / vCircNow - W_TERM) / (1 - W_TERM)));
        var vrWant = Math.max(-VR_CAP, Math.min(VR_CAP, KH * (H_ORB - h)));
        var gRef = Math.atan2(vrWant, Math.max(state.vt, 0.02));
        aCmd += Math.max(-AOA_MAX, Math.min(AOA_MAX, w * KG * (gamma - gRef)));
        aCmd = Math.max(0, Math.min(100 * DEG, aCmd));
      }
      var dA = aCmd - state.alpha, lim = A_RATE * dt;
      state.alpha += Math.max(-lim, Math.min(lim, dA));

      if (state.phase === 'ignition') {
        if (state.t >= IGN_RAMP && F > m * g) { state.phase = 'burn1'; firePhase('liftoff'); }
        else { state.vr = 0; state.vt = 0; state.accel = 0; return; }
      }

      var burning = isBurningPhys();
      var ar = (burning ? A * Math.cos(state.alpha) : 0) - g + state.vt * state.vt / state.r;
      var at = (burning ? A * Math.sin(state.alpha) : 0) - state.vr * state.vt / state.r;
      state.accel = burning ? A : 0;
      state.vr += ar * dt; state.vt += at * dt;
      state.r += state.vr * dt; state.theta += (state.vt / state.r) * dt;
      if (state.r < R_E) { state.r = R_E; state.vr = Math.max(0, state.vr); }
      state.gamma = Math.atan2(state.vr, state.vt);

      if (state.phase === 'burn1') {
        state.fuel1 -= F1 / VE1 * dt;
        if (state.boostersAttached) {
          state.fuelBoost -= FB / VE1 * dt;
          if (state.fuelBoost <= 0) { state.fuelBoost = 0; state.boostersAttached = false; detach('booster'); firePhase('boosterSep'); }
        }
        if (state.fuel1 <= 0) {
          state.fuel1 = 0; state.stage1Attached = false;
          detach('stage1'); firePhase('stage1Sep');
          state.phase = 'sep'; state.sepT = 0;
        }
      } else if (state.phase === 'sep') {
        state.sepT += dt;
        if (state.sepT >= SEP_DELAY) { state.phase = 'burn2'; firePhase('stage2Ignition'); }
      } else if (state.phase === 'burn2') {
        if (state.fuel2 > GHOST_LIMIT) {
          state.fuel2 = Math.max(GHOST_LIMIT, state.fuel2 - F2 / VE2 * dt);
          if (state.fuel2 <= 0) {
            // 芯二级推进剂耗尽：二级关机分离，芯三级接管（氧氢上面级推力低、时间长）
            state.fuel2 = 0; state.stage2Attached = false;
            detach('stage2'); firePhase('stage2Sep');
            state.phase = 'sep2'; state.sepT = 0;
          }
        }
      } else if (state.phase === 'sep2') {
        state.sepT += dt;
        if (state.sepT >= SEP_DELAY) { state.phase = 'burn3'; firePhase('stage3Ignition'); }
      } else if (state.phase === 'burn3') {
        if (state.fuel3 > GHOST_LIMIT) state.fuel3 = Math.max(GHOST_LIMIT, state.fuel3 - F3 / VE3 * dt);
      }

      if (!fired.pitch && metL >= MET_PITCH) firePhase('pitch');
      if (!fired.maxQ && metL >= MET_MAXQ && h > ALT_DENSE) firePhase('maxQ');
      if (state.towerAttached && metL >= MET_TOWER) { state.towerAttached = false; detach('tower'); firePhase('towerSep'); }
      if (state.fairingAttached && metL >= MET_FAIRING) { state.fairingAttached = false; detach('fairing'); firePhase('fairingSep'); }

      // 入轨由芯三级（或二级尚未分离时的二级）完成：速度达到环绕速度即判定入轨
      if (state.phase === 'burn2' || state.phase === 'burn3') {
        var vCirc = Math.sqrt(MU / state.r);
        if (state.vt >= vCirc * 0.999 && Math.abs(state.vr) < 0.15) {
          state.inserted = true;
          if (state.segment === 2) {
            // 第二次发射：展开太阳翼（活动栈 = 二级 + 三级 + 飞船 + 太阳翼）
            for (var k = 0; k < panels.length; k++) panels[k].mesh.visible = true;
          }
          // 重心归零到本段入轨活动栈的实时质心（第一次＝二级+三级+着陆器／第二次＝二级+三级+飞船+太阳翼）。
          // 这里刻意不补偿 state.x/y：入轨后原点即活动体质心，而 parkOrbit 正是把「原点」放在
          // 圆轨道上，两者自洽；部件只会沿切向平移 C1（入轨时 scale=1、镜头在数千单位外，视觉不可见）。
          var insStack = state.segment === 2 ? stackS1Parts : stack1Parts;
          rezero(insStack, centroidOf(insStack));
          state.focus = 0;
          // 记录实际入轨 MET（相对本段），供 parkOrbit 从此值平滑推进到 MET_TLI，避免时钟回退
          state.metInsert = metL;
          state.regime = 'space'; state.phase = 'parkOrbit'; state.phaseT = 0;
          state.parkAng = state.theta;
          // 入轨后把芯三级剩余燃料留作地月转移入射（TLI）：氢氧级二次点火
          state.fuel3 = S3F0 * S3_TLI_K;
          firePhase('parkOrbit');
        }
      }
    }

    // ============ 脚本段 ============
    function setPose(px, py, tiltTarget, rate) {
      state.x = px; state.y = py;
      // 姿态收敛必须与时间倍率同步：倍率越高航迹前进越快（最高 60×），
      // 若机头仍按原速率追，就会明显滞后于航迹（看起来"姿态/方向不对"）。
      state.tilt += shortAngle(tiltTarget - state.tilt) * Math.min(1, rate * state.warp);
      state.tiltVis = state.tilt;
    }
    function progradeTilt(psi) { return Math.atan2(Math.cos(psi), -Math.sin(psi)); }

    function stepScripted(dt) {
      var ph = state.phase, u, pos, psi, rm, tiltT;
      var seg2 = state.segment === 2;
      state.phaseT += dt * state.warp;
      // 与倍率同步的「平滑步长」：脚本段里的缩放 / 着陆腿展开等收敛量必须用它。
      // 若仍用原始 dt，高倍率下相位的真实时长被压缩（60× 时 30 s 的动力下降只剩 0.5 s），
      // 一阶平滑根本来不及收敛 —— 表现为着陆时器体被放大数倍、着陆腿只展开一半。
      var sw = dt * state.warp;

      // 第二次发射期间，驻留着陆器持续绕月（与飞船同向），供交会段收敛
      if (seg2 && state.landerParked &&
          (ph === 'transit' || ph === 'loi' || ph === 'lunarOrbit' || ph === 'rendezvous')) {
        state.parkPsi += PARK_RATE * dt * state.warp;
      }

      if (ph === 'parkOrbit') {
        var wOrb = Math.sqrt(MU / (R_ORB * R_ORB * R_ORB));
        state.parkAng += wOrb * dt * state.warp * ORB_VIS;
        pos = [EC[0] + R_ORB_VIS * Math.sin(state.parkAng), EC[1] + R_ORB_VIS * Math.cos(state.parkAng)];
        setPose(pos[0], pos[1], progradeTilt(state.parkAng), dt * 2);
        state.theta = state.parkAng;
        state.alt = R_ORB - R_E; state.altVis = R_ORB_VIS - R_E;
        state.speed = V_ORB * MS_PER_UNIT;
        state.met = state.metBase + lerp(state.metInsert, MET_TLI, Math.min(1, state.phaseT / DUR.park));
        state.distEarth = R_ORB * KM_PER_UNIT;
        state.distMoon = Math.hypot(pos[0] - MC[0], pos[1] - MC[1]) * KM_PER_UNIT;
        state.scale += (20 - state.scale) * Math.min(1, sw * 0.8);
        // 停泊轨道上活动体仍是「芯二级 + 芯三级 + 载荷」，喷管基准取最下面的芯二级
        state.engLocalY = engY('s2'); state.engSize = 0.6; state.burning = false;
        state.progress = seg2 ? lerp(0.70, 0.72, Math.min(1, state.phaseT / DUR.park))
                              : lerp(0.30, 0.34, Math.min(1, state.phaseT / DUR.park));
        if (state.phaseT >= DUR.park) { state.phase = 'tli'; state.phaseT = 0; state.burning = true; firePhase('tli'); }
        return;
      }

      if (ph === 'tli') {
        u = Math.min(1, state.phaseT / DUR.tli);
        var wO = Math.sqrt(MU / (R_ORB * R_ORB * R_ORB));
        // 真实地月转移：先在近地点沿「切向」完成加速（点火段，高度基本不变），
        // 随后关机沿椭圆轨道惯性滑行，远地点逐步外推 —— 而不是全程边绕圈边螺旋抬升。
        // u < 0.35 为点火段，其后为滑行段。
        var burnK = Math.min(1, u / 0.35);
        var coastK = Math.max(0, (u - 0.35) / 0.65);
        // 角速度：点火段略快、滑行段随远离地球变慢（原实现是越飞越快，观感相反）
        state.parkAng += wO * dt * state.warp * ORB_VIS * (0.9 + burnK * 0.5) * (1 - coastK * 0.15);
        // 半径：加速段几乎不动（近地点保持），滑行段仅轻微外扩 ——
        // 真正的「拉向月球」交给随后的地月转移段完成，避免看起来像垂直抬升。
        var rhoT = R_ORB_VIS * (1 + 0.02 * burnK + 0.10 * Math.pow(coastK, 1.2));
        pos = [EC[0] + rhoT * Math.sin(state.parkAng), EC[1] + rhoT * Math.cos(state.parkAng)];
        setPose(pos[0], pos[1], progradeTilt(state.parkAng), dt * 3);
        state.theta = state.parkAng;
        // 速度：7.70 → 10.20 km/s，终点与地月转移段起点（10200 m/s）严格衔接
        state.speed = V_ORB * MS_PER_UNIT * (1 + 0.325 * burnK);
        state.met = state.metBase + lerp(MET_TLI, MET_TLI + 900, u);
        // 遥测高度随实际抬升同步增长（此前整段冻结在停泊轨道高度）
        state.alt = (rhoT - R_E) / GAIN_ORB; state.altVis = rhoT - R_E;
        state.distEarth = Math.hypot(pos[0] - EC[0], pos[1] - EC[1]) * KM_PER_UNIT;
        state.distMoon = Math.hypot(pos[0] - MC[0], pos[1] - MC[1]) * KM_PER_UNIT;
        state.scale += (20 - state.scale) * Math.min(1, sw * 0.8);
        // 地月转移入射由芯三级完成（氢氧级二次点火）
        state.engLocalY = engY('s3'); state.engSize = 0.75; state.burning = burnK < 1;
        state.progress = seg2 ? lerp(0.72, 0.74, u) : lerp(0.34, 0.38, u);
        if (u >= 1) {
          // 芯三级关机分离，重心归零到本段单独飞行的活动体（第一次=着陆器，第二次=飞船），捕获转移起点
          detach('stage3');
          state.stage3Attached = false;
          var activeStack2 = seg2 ? stackS2Parts : stack2Parts;
          // d2 = 活动体质心相对当前原点（入轨时已把整栈质心归零，故即其实时质心）
          var d2 = centroidOf(activeStack2), w2 = [0, 0, 0];
          bodyToWorld(0, d2, 0, w2);
          rezero(activeStack2, d2);
          state.x = w2[0]; state.y = w2[1];
          state.transitTheta0 = Math.atan2(state.x - EC[0], state.y - EC[1]);
          state.transitRho0 = Math.hypot(state.x - EC[0], state.y - EC[1]);
          state.phase = 'transit'; state.phaseT = 0; state.burning = false;
          firePhase('stage3Sep'); firePhase('transit');
        }
        return;
      }

      if (ph === 'transit') {
        u = Math.min(1, state.phaseT / DUR.transit);
        var e = smoothstep(u);
        var th = state.transitTheta0 + shortAngle(THETA_A - state.transitTheta0) * u;
        var rho = state.transitRho0 + (RHO_A - state.transitRho0) * e;
        var px = EC[0] + rho * Math.sin(th), py = EC[1] + rho * Math.cos(th);
        var u2 = Math.min(1, u + 0.004);
        var th2 = state.transitTheta0 + shortAngle(THETA_A - state.transitTheta0) * u2;
        var rho2 = state.transitRho0 + (RHO_A - state.transitRho0) * smoothstep(u2);
        var qx = EC[0] + rho2 * Math.sin(th2), qy = EC[1] + rho2 * Math.cos(th2);
        var tiltT = Math.atan2(qx - px, qy - py);
        // 末段提前把机头摆向环月切向：否则进近航迹朝月球、LOI 首帧航迹突变为绕月切向，
        // 姿态会在近月制动开始时明显滞后（看起来"姿态和运动方向不对"）。
        if (u > 0.82) {
          var kA = smoothstep((u - 0.82) / 0.18);
          var tangA = progradeTilt(PSI_EARTH + LOI_SWEEP * 0.02);
          tiltT += shortAngle(tangA - tiltT) * kA;
        }
        setPose(px, py, tiltT, dt * 2);
        state.scale += (28 - state.scale) * Math.min(1, sw * 0.6);
        state.distEarth = Math.hypot(px - EC[0], py - EC[1]) * KM_PER_UNIT;
        state.distMoon = Math.hypot(px - MC[0], py - MC[1]) * KM_PER_UNIT;
        state.speed = lerp(10200, 950, e);
        state.met = state.metBase + lerp(MET_TLI + 900, MET_LOI, u);
        state.engLocalY = seg2 ? engY('ship') : engY('lander'); state.engSize = 0.75; state.burning = false;
        state.moonBlend = Math.max(state.moonBlend, smoothstep((u - 0.02) / 0.4));
        state.progress = seg2 ? lerp(0.74, 0.80, u) : lerp(0.38, 0.46, u);
        if (u >= 1) { state.phase = 'loi'; state.phaseT = 0; state.rm = R_AP; state.psi = PSI_EARTH; state.burning = true; firePhase('loi'); }
        return;
      }

      if (ph === 'loi') {
        u = Math.min(1, state.phaseT / DUR.loi);
        var eL = smoothstep(u);
        rm = lerp(R_AP, MLORB, eL);
        psi = PSI_EARTH + LOI_SWEEP * u;
        state.rm = rm; state.psi = psi;
        pos = [MC[0] + rm * Math.sin(psi), MC[1] + rm * Math.cos(psi)];
        // 姿态沿实际航迹（有限差分）：机头始终顺着飞行方向，
        // 与随后的环月段一致，不再出现「机头横在航迹上 + 回转 180°」的错觉
        var uL2 = Math.min(1, u + 0.01);
        var rm2 = lerp(R_AP, MLORB, smoothstep(uL2)), psi2 = PSI_EARTH + LOI_SWEEP * uL2;
        setPose(pos[0], pos[1], Math.atan2(MC[0] + rm2 * Math.sin(psi2) - pos[0], MC[1] + rm2 * Math.cos(psi2) - pos[1]), dt * 2.5);
        state.scale += (11 - state.scale) * Math.min(1, sw * 0.7);
        state.engLocalY = seg2 ? engY('ship') : engY('lander'); state.engSize = 0.85; state.burning = true;
        state.moonAlt = (rm - MR) * KM_PER_UNIT;
        state.distMoon = rm * KM_PER_UNIT;
        state.distEarth = Math.hypot(pos[0] - EC[0], pos[1] - EC[1]) * KM_PER_UNIT;
        state.speed = lerp(950, 1630, eL);
        state.met = state.metBase + lerp(MET_LOI, MET_LORB, u);
        state.moonBlend = 1;
        state.progress = seg2 ? lerp(0.80, 0.83, u) : lerp(0.46, 0.49, u);
        if (u >= 1) { state.phase = 'lunarOrbit'; state.phaseT = 0; state.burning = false; firePhase('lunarOrbit'); }
        return;
      }

      if (ph === 'lunarOrbit') {
        u = Math.min(1, state.phaseT / DUR.lorb);
        psi = (PSI_EARTH + LOI_SWEEP) + LORB_RATE * state.phaseT;
        state.psi = psi; state.rm = MLORB;
        pos = [MC[0] + MLORB * Math.sin(psi), MC[1] + MLORB * Math.cos(psi)];
        setPose(pos[0], pos[1], progradeTilt(psi), dt * 2);
        state.scale += (10 - state.scale) * Math.min(1, sw * 0.7);
        state.engLocalY = seg2 ? engY('ship') : engY('lander'); state.engSize = 0.85; state.burning = false;
        state.moonAlt = (MLORB - MR) * KM_PER_UNIT;
        state.distMoon = MLORB * KM_PER_UNIT;
        state.distEarth = Math.hypot(pos[0] - EC[0], pos[1] - EC[1]) * KM_PER_UNIT;
        state.speed = 1630;
        state.moonBlend = 1;
        // 环月飞行段 MET 持续推进到本段终点：第一次→SEG2_BASE（驻留），第二次→MET2_RENDEZ（交会），
        // 与后续 transition / rendezvous 的起点严格衔接，避免遥测时钟长时间冻结或末帧跳变。
        state.met = state.metBase + lerp(MET_LORB, seg2 ? MET2_RENDEZ : SEG2_BASE, u);
        state.progress = seg2 ? lerp(0.83, 0.86, u) : lerp(0.49, 0.50, u);
        if (u >= 1) {
          if (seg2) {
            // 第二次发射：进入交会段，飞船向驻留着陆器靠拢
            state.rendezOffset = shortAngle(state.psi - state.parkPsi);
            state.phase = 'rendezvous'; state.phaseT = 0;
            state.met = state.metBase + MET2_RENDEZ;
            firePhase('rendezvous');
          } else {
            // 第一次发射：着陆器就位环月轨道，转入段间过渡
            state.met = SEG2_BASE;
            parkLander();
            state.phase = 'transition'; state.phaseT = 0; state.burning = false;
            firePhase('landerPark'); firePhase('transition');
          }
        }
        return;
      }

      if (ph === 'transition') {
        // 段间过渡：镜头停留在月球，展示驻留着陆器；画面渐隐至黑场，末段切到第二次发射
        u = Math.min(1, state.phaseT / DUR.transition);
        state.segFade = u < 0.4 ? smoothstep(u / 0.4) : 1;
        state.parkPsi += PARK_RATE * dt * state.warp * 0.4;
        psi = state.parkPsi;
        state.psi = psi; state.rm = MLORB;
        pos = [MC[0] + MLORB * Math.sin(psi), MC[1] + MLORB * Math.cos(psi)];
        setPose(pos[0], pos[1], progradeTilt(psi), dt * 2);
        state.moonAlt = (MLORB - MR) * KM_PER_UNIT;
        state.distMoon = MLORB * KM_PER_UNIT;
        state.distEarth = Math.hypot(pos[0] - EC[0], pos[1] - EC[1]) * KM_PER_UNIT;
        state.met = SEG2_BASE;
        state.moonBlend = 1; state.burning = false; state.speed = 1630;
        state.progress = 0.50;
        if (u >= 1) { resetForSegment2(); }
        return;
      }

      if (ph === 'rendezvous') {
        u = Math.min(1, state.phaseT / DUR.rendezvous);
        var eR = smoothstep(u);
        // 交会：飞船在环月轨道上从「后方」追近驻留的着陆器（真实交会即后方接近）。
        // 终态角差 = 对接间距换算成的环月角 gapA，飞船永远落在着陆器后方 —— 因此接近轨迹
        // 不会穿过着陆器。此前终态把飞船定位在着陆器「前方」（+DOCK_GAP），飞船从后方追近时
        // 必然扫过着陆器本体，表现为严重穿模（实测两器最近仅 0.40 世界单位）。
        var gapA = DOCK_GAP * state.scale / MLORB;
        var termA = state.parkPsi - gapA;
        psi = termA + (state.rendezOffset + gapA) * (1 - eR);
        var doDock = u >= 1 || Math.abs(shortAngle(psi - termA)) < DOCK_PSI_TOL;
        // 触发对接的当帧把位置与姿态一起推到精确终态：对接要求姿态对齐，
        // 对齐后 dockLander() 对每一块部件都无位移（着陆器质心原位重定基），零瞬移。
        if (doDock) {
          eR = 1; psi = termA;
          state.tilt = state.tiltVis = progradeTilt(termA);
        }
        pos = [MC[0] + MLORB * Math.sin(psi), MC[1] + MLORB * Math.cos(psi)];
        setPose(pos[0], pos[1], progradeTilt(psi), dt * 4);
        state.psi = psi; state.rm = Math.hypot(pos[0] - MC[0], pos[1] - MC[1]);
        state.scale += (10 - state.scale) * Math.min(1, sw * 0.7);
        state.engLocalY = engY('ship'); state.engSize = 0.5; state.burning = u < 0.92;
        state.moonAlt = (state.rm - MR) * KM_PER_UNIT;
        state.distMoon = state.rm * KM_PER_UNIT;
        state.distEarth = Math.hypot(pos[0] - EC[0], pos[1] - EC[1]) * KM_PER_UNIT;
        state.speed = lerp(1630, 1580, eR);
        state.met = state.metBase + lerp(MET2_RENDEZ, MET2_DOCK, u);
        state.moonBlend = 1;
        state.progress = lerp(0.86, 0.89, u);
        if (doDock) {
          dockLander();
          state.phase = 'docked'; state.phaseT = 0; state.burning = false;
          firePhase('docking');
        }
        return;
      }

      if (ph === 'docked') {
        // 对接后组合体短暂环月飞行，随后船器分离、动力下降
        u = Math.min(1, state.phaseT / DUR.dock);
        psi = state.dockA0 + LORB_RATE * state.phaseT;
        state.psi = psi; state.rm = state.rmSepDock;
        pos = [MC[0] + state.rmSepDock * Math.sin(psi), MC[1] + state.rmSepDock * Math.cos(psi)];
        setPose(pos[0], pos[1], progradeTilt(psi), dt * 2);
        state.scale += (10 - state.scale) * Math.min(1, sw * 0.7);
        state.engLocalY = engY('lander'); state.engSize = 0.6; state.burning = false;
        state.moonAlt = (state.rmSepDock - MR) * KM_PER_UNIT;
        state.distMoon = state.rmSepDock * KM_PER_UNIT;
        state.distEarth = Math.hypot(pos[0] - EC[0], pos[1] - EC[1]) * KM_PER_UNIT;
        state.speed = 1630;
        state.met = lerp(SEG2_BASE + MET2_DOCK, MET_LSEP, u);
        state.moonBlend = 1;
        state.progress = lerp(0.89, 0.91, u);
        if (u >= 1) {
          separateLander();
          state.phase = 'descent'; state.phaseT = 0; state.burning = true;
          firePhase('landerSep'); firePhase('descent');
        }
        return;
      }

      if (ph === 'descent' || ph === 'approach') {
        u = Math.min(1, state.phaseT / DUR.descent);
        var eD = smoothstep(u);
        rm = lerp(state.rm0, LAND_RM, eD);
        // 着陆点经度锚定在「近地点 ± LAND_PSI_OFF」，并取离分离点更近的一侧 ——
        // 这样着陆点上空的地球仰角固定（≈13°），下降段又不会为了对经度而横飞过远。
        var dA = shortAngle(PSI_EARTH + LAND_PSI_OFF - state.psi0);
        var dB = shortAngle(PSI_EARTH - LAND_PSI_OFF - state.psi0);
        var dPsiLand = Math.abs(dA) <= Math.abs(dB) ? dA : dB;
        psi = state.psi0 + dPsiLand * eD;
        state.rm = rm; state.psi = psi;
        pos = [MC[0] + rm * Math.sin(psi), MC[1] + rm * Math.cos(psi)];
        var proD = progradeTilt(psi), vert = psi;
        var kVert = smoothstep((u - 0.12) / 0.42);
        setPose(pos[0], pos[1], proD + shortAngle(vert - proD) * kVert, dt * 2.5);
        var scaleTarget = lerp(10, 1.4, smoothstep((u - 0.30) / 0.62));
        state.scale += (scaleTarget - state.scale) * Math.min(1, sw * 0.9);
        state.engLocalY = engY('lander'); state.engSize = 0.75;
        state.moonAlt = Math.max(0, lerp((state.rm0 - MR), 0, eD) * KM_PER_UNIT);
        state.distMoon = rm * KM_PER_UNIT;
        state.distEarth = Math.hypot(pos[0] - EC[0], pos[1] - EC[1]) * KM_PER_UNIT;
        state.speed = lerp(1630, 0, Math.pow(eD, 0.7));
        state.met = lerp(MET_LSEP, MET_LAND, u);
        // 展开着陆腿：u 0.5 → 0.78 由收拢（2.9）转到撑开（0.72）。收敛用 sw，
        // 否则 60× 加速下这一段真实时长不足 0.2 s，落地时腿只展开一半（悬空 + 姿势不对）。
        var deployTarget = smoothstep((u - 0.5) / 0.28);
        state.legsDeploy += (deployTarget - state.legsDeploy) * Math.min(1, sw * 2.5);
        for (var li = 0; li < legParts.length; li++) legParts[li].localRotX = lerp(LEG_ROT_STOW, LEG_ROT_DEPLOY, state.legsDeploy);
        // 着陆末段是真实相位：u>0.6 起 phase 由 descent 切换为 approach（同一段脚本，phaseT 不重置）
        if (u > 0.6 && state.phase === 'descent') { state.phase = 'approach'; firePhase('approach'); }
        state.burning = u < 0.995;
        state.progress = lerp(0.91, 0.995, u);
        if (u > 0.85) spawnLunarDust(dt, (u - 0.85) / 0.15);
        if (u >= 1) {
          state.phase = 'landed'; state.landed = true; state.burning = false; state.phaseT = 0;
          // 触地帧把「缩放 / 着陆腿」直接钳到终值：这是着陆姿态的收尾帧，
          // 无论此前是否在加速、松手早晚，落点姿态都必须与 1× 完全一致。
          state.scale = scaleTarget;          // = 1.4（触地时的着陆倍数）
          state.legsDeploy = 1;
          for (li = 0; li < legParts.length; li++) legParts[li].localRotX = LEG_ROT_DEPLOY;
          state.rm = LAND_RM; state.psi = state.psi0 + dPsiLand;
          state.x = MC[0] + LAND_RM * Math.sin(state.psi);
          state.y = MC[1] + LAND_RM * Math.cos(state.psi);
          state.tilt = state.psi; state.tiltVis = state.psi;
          state.moonAlt = 0; state.speed = 0; state.surfCamBlend = 1;
          state.progress = 1;
          firePhase('landing'); firePhase('landed');
          if (hooks.onTouchdown) hooks.onTouchdown();
        }
        return;
      }

      if (ph === 'landed') {
        state.burning = false;
        state.met = MET_LAND + state.phaseT * 6;
        state.speed = 0; state.moonAlt = 0; state.distMoon = MR * KM_PER_UNIT;
        state.surfCamBlend = 1;
        return;
      }
    }

    function update(dt, cam) {
      // 未点火（倒计时 / 待命）：也要同步一次世界坐标与遥测，
      // 否则外部读到的是上一轮飞行残留的 altVis，会把停在地面的火箭当作「已飞远」。
      if (!state.ignited) { syncWorldAscent(); syncFlames(); return; }
      // 时间倍率：仅由「长按加速」驱动；脚本段 DUR 为墙钟场景秒，正常速下按真实节奏推进。
      // 按住时长累加 → 按 WARP_TIERS 分段爬升；松手立刻归零、倍率回到 1×。
      state.holdT = state.hold ? state.holdT + dt : 0;
      var warp = state.hold ? warpForHold(state.holdT) : 1;
      state.warp = warp;

      if (state.regime === 'ascent') {
        var remaining = dt * warp, hMax = 1 / 120, guard = 0;
        while (remaining > 1e-6 && guard++ < 400) { var hs = Math.min(hMax, remaining); stepAscent(hs); remaining -= hs; }
        syncWorldAscent();
        // 尾焰 / 粒子基准随当前工作级变化：一级段→芯一级，二级段→芯二级，三级段→芯三级
        var upStage = (state.phase === 'ignition' || state.phase === 'burn1' || state.phase === 'sep') ? 's1'
          : (state.phase === 'burn2' ? 's2' : 's3');
        state.engLocalY = engY(upStage);
        state.engSize = upStage === 's1' ? 1.0 : 0.7;
        state.burning = isBurningPhys();
      } else {
        state.t += dt * warp;
        stepScripted(dt);
      }

      state.camDist = cam ? cam.distance : 20;
      // 段间黑场淡入（第二次发射）：按真实时间平滑揭开，避免受加速倍率影响观感
      if (state.segFadeT > 0) {
        state.segFadeT = Math.max(0, state.segFadeT - dt);
        state.segFade = state.segFadeT / 1.0;
      }
      spawnFlames(dt);
      if (state.regime === 'ascent' && (state.t < 7.5 || state.altVis < 6)) spawnPadSmoke(dt);
      if (state.phase === 'transit' || state.phase === 'lunarOrbit' || state.phase === 'rendezvous') spawnTrail(dt);

      // 驻留着陆器（第一次发射就位后）每帧独立定位，第二次发射全程可见其绕月等待
      if (state.landerParked) positionParkedLander();

      // 着陆腿可见性：未点火（展示/拆解）与下降段之后可见，上升段隐藏（收于整流罩内）
      var legsOn = !state.ignited || state.phase === 'descent' || state.phase === 'approach' || state.phase === 'landed';
      for (var li = 0; li < legParts.length; li++) legParts[li].mesh.visible = legsOn;

      moonRing.visible = (state.phase === 'lunarOrbit' || state.phase === 'loi' || state.phase === 'rendezvous' || state.phase === 'docked');
      moonRing.alpha = moonRing.visible ? 0.5 : 0;

      if (pad.ember && state.regime === 'ascent') {
        var glow = state.t < IGN_RAMP ? state.t / IGN_RAMP : Math.max(0, 1 - (state.t - IGN_RAMP) / 2.5);
        pad.ember.glow = glow * 0.9;
      }
      syncFlames();
    }

    function directCamera(cam, dt) {
      if (!state.ignited) return;
      var nose = [Math.sin(state.tiltVis), Math.cos(state.tiltVis)];
      var craftX = state.x + nose[0] * state.focus * state.scale;
      var craftY = state.y + nose[1] * state.focus * state.scale;
      var gTX, gTY, gDist, gPitch, gYaw = cam.yaw;
      // 镜头的「收敛类」平滑（跟随目标 / 距离 / 俯仰 / 偏航对齐）必须与倍率同步：
      // 高倍率下相位真实时长被压缩，用原始 dt 收敛不动 —— 60× 时动力下降只剩 0.5 s，
      // 相机距离会停在 7443（应为 14），整个着陆过程等于看不见。
      // 注意：上升段 / 停泊段的镜头「缓慢自转」（dt×0.035 / 0.02）是观赏性漂移，仍按真实时间。
      var cw = dt * state.warp;

      if (state.regime === 'ascent') {
        gTX = craftX; gTY = craftY;
        gDist = Math.max(22, Math.min(130, 22 + Math.max(state.alt, state.altVis) * 0.6));
        gYaw = cam.yaw + dt * 0.035; gPitch = 0.05;
        cam.shake = (state.t > IGN_RAMP && state.t < 12) ? 0.05 : (state.t < 20 ? 0.028 : 0);
        state.surfCamBlend = 0;
      } else if (state.phase === 'parkOrbit' || state.phase === 'tli') {
        gTX = craftX; gTY = craftY;
        gDist = cam.fitEarth || 5200; gYaw = cam.yaw + dt * 0.02; gPitch = 0.06;
        cam.shake = state.phase === 'tli' ? 0.012 : 0;
        state.surfCamBlend = 0;
      } else if (state.phase === 'transit') {
        gTX = (EC[0] + MC[0]) * 0.5; gTY = (EC[1] + MC[1]) * 0.5;
        gDist = cam.fitSystem || MO.dist * 0.82;
        gYaw = cam.yaw + (0 - cam.yaw) * Math.min(1, cw * 0.6);
        gPitch = cam.pitch + (0.02 - cam.pitch) * Math.min(1, cw * 0.6);
        cam.shake = 0; state.surfCamBlend = 0;
      } else if (state.phase === 'loi' || state.phase === 'lunarOrbit' ||
                 state.phase === 'transition' || state.phase === 'rendezvous' || state.phase === 'docked') {
        // 环月段跟拍：目标锁在飞行器上，并交给「径向取景」（surfCamBlend）把相机漂到
        // 飞行器的径向外侧 —— 否则飞行器绕到月球背面时会被月体整个挡住、彻底看不见。
        gTX = craftX; gTY = craftY;
        gDist = 240;
        gYaw = cam.yaw + (0.18 - cam.yaw) * Math.min(1, cw * 0.6);
        gPitch = cam.pitch + (0.10 - cam.pitch) * Math.min(1, cw * 0.6);
        cam.shake = 0; state.surfCamBlend = 1;
      } else {
        // 着陆段：镜头自始至终锁定着陆器本体。
        // （此前把目标点从「月心」插值到着陆器，而月心到器体约一个月球半径，
        //   中段等于把镜头对准月体内部，器体长时间偏出画面 / 被月体挡住。）
        // 「由远推近」改为只靠距离收敛实现；月面镜头因子保持 1，与环月段连续，
        // 避免相机 up 从月面法线掉回世界 +Y 再折回造成的画面翻转。
        var u = Math.min(1, state.phaseT / DUR.descent);
        var close = state.phase === 'landed' ? 1 : smoothstep(u / 0.75);
        gTX = state.x; gTY = state.y;
        gDist = lerp(240, 14, close);          // 起点沿用环月跟拍距离，避免瞬间拉远
        var surfYaw = state.psi + Math.PI * 0.30;
        gYaw = cam.yaw + (surfYaw - cam.yaw) * Math.min(1, cw * (0.5 + close));
        gPitch = cam.pitch + (0.14 - cam.pitch) * Math.min(1, cw * 0.8);
        cam.shake = state.burning && close > 0.6 ? 0.02 * close : 0;
        state.surfCamBlend = 1;
      }

      if (state.camSnap) {
        // 段间切换：直接把镜头瞬移到新箭体（配合 app 层黑场过渡，避免可见的横扫）
        cam.targetX = gTX; cam.targetY = gTY; cam.targetZ = 0;
        cam.distance = gDist; cam.yaw = gYaw; cam.pitch = gPitch;
        state.camSnap = false;
        return;
      }
      // 跟拍增益：上升段跟随紧凑；地月转移段的目标是「地月中点」（近乎静止）故可慢；
      // 环月 / 交会 / 着陆段必须跟紧器体 —— 器体在环月轨道上的角速度很高，
      // 旧的统一平滑（dt×1.7）滞后可达 200+ 单位，会把器体甩出画面（交会段实测偏出 2 倍半屏高）。
      // 段首 1.2 s 仍用慢跟随，避免段切换瞬间镜头瞬移。
      var lk;
      if (state.regime === 'ascent') lk = Math.min(1, cw * 5);
      else if (state.phase === 'transit') lk = Math.min(1, cw * 1.7);
      else if (state.phaseT < 1.2) lk = Math.min(1, cw * 1.7);
      else lk = 1;
      cam.targetX += (gTX - cam.targetX) * lk;
      cam.targetY += (gTY - cam.targetY) * lk;
      cam.targetZ += (0 - cam.targetZ) * lk;
      cam.distance += (gDist - cam.distance) * Math.min(1, cw * 1.4);
      cam.yaw = gYaw;
      cam.pitch += (gPitch - cam.pitch) * Math.min(1, cw * 1.4);
    }

    // ---- 构型配置：把全部件切到「第一次发射」或「第二次发射」构型 ----
    //  seg=1：助推×2 + 芯一级 + 芯二级 + 芯三级 + 整流罩（罩内为揽月着陆器）；无飞船 / 逃逸塔 / 太阳翼
    //  seg=2：助推×2 + 芯一级 + 芯二级 + 芯三级 + 整流罩（罩内为梦舟飞船）+ 逃逸塔（坐在罩顶）；
    //         无着陆器；太阳翼发射时收拢，入轨后才展开
    //  keepLander=true 时跳过着陆器部件（段间过渡时着陆器正在环月驻留，不能复位）。
    //  展示 / 拆解 / 登月三条路径共用本函数 —— 「两枚火箭」的构型只此一处真源。
    function applyConfig(seg, keepLander) {
      for (var i = 0; i < parts.length; i++) {
        var p = parts[i], g = p.detachGroup;
        if (keepLander && g === 'lander') continue;
        p.baseY = baseY0[i];
        p.localRotX = legRot0[i];
        p.detached = false; p.parked = false;
        p.detachOff = [0, 0, 0]; p.detachV = [0, 0, 0];
        p.detachRot = [0, 0, 0]; p.detachSpin = [0, 0, 0];
        p.detachScale = 1; p.mesh.alpha = 1; p.detachFade = true;
        if (seg === 2) {
          // 载人构型：整流罩在（罩内梦舟）、逃逸塔在罩顶；无着陆器；太阳翼收拢
          p.mesh.visible = g !== 'lander' && g !== 'panel';
        } else {
          // 无人构型：罩内揽月着陆器；无飞船 / 逃逸塔 / 太阳翼
          p.mesh.visible = !(g === 'ship' || g === 'tower' || g === 'panel');
        }
      }
      state.segment = seg;
      state.metBase = seg === 2 ? SEG2_BASE : 0;
      state.variant = seg;
    }

    // 第一次发射（着陆器）构型（点火前 / 展示 / 拆解共用）
    function setupSegment1Launch() {
      applyConfig(1, false);
      state.towerAttached = false;      // 第一次发射无逃逸塔
      state.fairingAttached = true;     // 第一次发射有整流罩（护着陆器）
    }

    function reset() {
      state.regime = 'ascent'; state.phase = 'prelaunch'; state.t = 0; state.phaseT = 0;
      state.r = R_E; state.theta = 0; state.vr = 0; state.vt = 0;
      state.alpha = 0; state.gamma = Math.PI / 2; state.tilt = 0; state.tiltVis = 0;
      // 世界坐标必须一起复位：展示 / 拆解直接按 (state.x, state.y) 摆放箭体，
      // 若沿用上一次飞行末端的轨道 / 月面坐标，切回来就会把箭体放到几千单位外（相机里看不到）。
      state.x = 0; state.y = 0;
      state.fuel1 = S1F0; state.fuel2 = S2F0; state.fuel3 = S3F0; state.fuelBoost = BF0;
      state.boostersAttached = true; state.stage1Attached = true;
      state.towerAttached = true; state.fairingAttached = true;
      state.stage2Attached = true; state.stage3Attached = true;
      state.ignited = false; state.inserted = false; state.landed = false;
      state.hold = false; state.holdT = 0; state.warp = 1; state.scale = 1; state.progress = 0; state.sepT = 0;
      state.accel = 0; state.met = 0; state.metInsert = MET_TLI; state._altMax = 0;
      // 可视化高度 / 速度必须一起清零：app 层用 altVis 决定发射台的淡入淡出，
      // 若沿用上一次飞行末端的值（约 1100 单位），重新观看时整个倒计时都看不到发射台。
      state.alt = 0; state.altVis = 0; state.speed = 0;
      state.shipAttached = true; state.focus = rocketModel.center;
      state.engLocalY = 0.18; state.engSize = 1; state.burning = false; state.legsDeploy = 0;
      state.parkAng = null; state.moonBlend = 0; state.surfCamBlend = 0;
      state.rm = R_AP; state.psi = PSI_EARTH; state.rm0 = MLORB; state.psi0 = PSI_EARTH; state.rmSepDock = MLORB;
      state.distEarth = 0; state.distMoon = MO.dist * KM_PER_UNIT; state.moonAlt = 0;
      // 两段式状态复位（segment / metBase 由随后 applyConfig 按当前构型写入）
      state.landerParked = false; state.parkPsi = PSI_EARTH;
      state.docked = false; state.rendezOffset = 0; state.dockA0 = PSI_EARTH; state.camSnap = false;
      state.segFade = 0; state.segFadeT = 0;
      pad.armSwing = 0; M3D.setArmSwing(pad, 0);
      pad.earthSpin = 0; M3D.spinEarth(pad, 0, 0);
      fired = {}; acc = {};
      if (pad.ember) pad.ember.glow = 0;
      // 几何 / 可见性 / 分离状态统一交给 applyConfig，复位为发射前初始状态（构型①）。
      // 展示模式想停在哪一枚，由 app 层在 reset 后调用 setVariant() 决定，避免 reset 语义漂移。
      applyConfig(1, false);
      moonRing.visible = false; moonRing.alpha = 0;
      renderer.particles.reset();
      syncFlames();
    }

    reset();

    return {
      state: state, V_ORB: V_ORB, KM_PER_UNIT: KM_PER_UNIT, MS_PER_UNIT: MS_PER_UNIT, TIME_SCALE: TIME_SCALE,
      DOCK_GAP: DOCK_GAP, warpTiers: WARP_TIERS,
      LAND_RM: LAND_RM, LEG_ROT_STOW: LEG_ROT_STOW, LEG_ROT_DEPLOY: LEG_ROT_DEPLOY,
      ignite: function () {
        setupSegment1Launch();
        state.ignited = true; state.phase = 'ignition'; state.regime = 'ascent'; firePhase('ignition');
      },
      prepareLaunch: setupSegment1Launch,
      // 展示 / 拆解：切换两枚火箭构型（1 = 第一次发射·揽月着陆器，2 = 第二次发射·梦舟飞船）
      setVariant: function (seg) { applyConfig(seg === 2 ? 2 : 1, false); },
      setHoldWarp: function (on) { state.hold = !!on; },
      update: update, directCamera: directCamera, syncFlames: syncFlames, reset: reset,
      updateDetachedParts: function (dt) {
        var earthPhase = state.regime === 'ascent' || state.phase === 'parkOrbit' || state.phase === 'tli' || state.phase === 'transit';
        if (earthPhase) {
          var A = (isBurningPhys() || state.phase === 'tli') ? currentThrust() / state.mass : 0;
          var c = Math.cos(state.tiltVis), s = Math.sin(state.tiltVis);
          var ax = s * A, ay = c * A, az = 0;
          if (state.inserted) { var gMag = MU / (state.r * state.r); ax -= Math.sin(state.theta) * gMag; ay -= Math.cos(state.theta) * gMag; }
          M3D.updateDetached(parts, dt, MU, EC[0], EC[1], EC[2], ax, ay, az);
        } else {
          M3D.updateDetached(parts, dt, 0, MC[0], MC[1], MC[2], 0, 0, 0);
        }
      }
    };
  }

  M3D.createMissionSystem = createMissionSystem;
})(typeof window !== 'undefined' ? window : this);
