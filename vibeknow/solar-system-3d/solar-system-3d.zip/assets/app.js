(function(){
  var cv=document.getElementById('stage');
  var gl=null;try{gl=cv.getContext('webgl2')||cv.getContext('webgl')}catch(e){}
  if(!gl||typeof THREE==='undefined'){document.getElementById('fallback').classList.add('show');document.getElementById('loader').classList.add('hide');return;}

  var W=innerWidth,H=innerHeight,DPR=Math.min(devicePixelRatio||1,1.5);
  var renderer=new THREE.WebGLRenderer({canvas:cv,antialias:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(DPR);renderer.setSize(W,H,false);
  renderer.outputEncoding=THREE.sRGBEncoding;
  renderer.toneMapping=THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure=1.08;

  var scene=new THREE.Scene();
  var camera=new THREE.PerspectiveCamera(52,W/H,0.1,5000);

  // 尺寸（艺术化比例）
  var SUN_R=7,EARTH_R=1.6,MOON_R=0.45;
  var EARTH_ORBIT=26,MOON_ORBIT=4.2;

  // 八大行星配置（地球由下方原代码创建，此处仅作数据与焦点信息）
  var PLANETS=[
    {key:'mercury',name:'水星',R:0.55,orbit:13,tilt:0.03,rev:0.667,spin:0.027,color:'#a8a29e',tex:'mercury.jpg',
     desc:'离太阳最近的行星，表面布满陨石坑，几乎没有大气。白天炙烤、夜晚冰寒。',meta:['公转 88 天','自转 59 天','无大气']},
    {key:'venus',name:'金星',R:1.15,orbit:18,tilt:2.6,rev:0.258,spin:-0.0066,color:'#e8c98a',tex:'venus.jpg',
     desc:'被浓密二氧化碳云层包裹，温室效应使表面温度高达 462°C，自转方向与公转相反。',meta:['公转 225 天','自转 243 天(逆向)','表面 462°C']},
    {key:'earth',name:'地球',R:1.6,orbit:26,tilt:23.5,rev:0.16,spin:1.6,color:'#4a90e2',tex:'earth.jpg',
     desc:'我们的家园。唯一已知拥有液态水与生命的行星，自转形成昼夜，公转决定四季。',meta:['自转 24 小时','公转 365 天','倾角 23.5°']},
    {key:'mars',name:'火星',R:0.95,orbit:34,tilt:25.2,rev:0.085,spin:1.56,color:'#d96845',tex:'mars.jpg',
     desc:'红色行星，拥有太阳系最高峰奥林帕斯山，两极有冰冠，曾可能存在液态水。',meta:['公转 687 天','自转 24.6 小时','两颗卫星']},
    {key:'jupiter',name:'木星',R:4.5,orbit:52,tilt:3.1,rev:0.0135,spin:3.88,color:'#d4a574',tex:'jupiter.jpg',
     desc:'太阳系最大行星，气态巨行星，大红斑是持续数百年的巨型风暴。',meta:['公转 11.86 年','自转 9.9 小时','95 颗卫星']},
    {key:'saturn',name:'土星',R:3.8,orbit:72,tilt:26.7,rev:0.00543,spin:3.59,color:'#e3c98a',tex:'saturn.jpg',ring:'saturnring.jpg',
     desc:'以壮丽光环著称，环由冰粒与岩石碎片组成，密度极低却延展数十万公里。',meta:['公转 29.46 年','自转 10.7 小时','环厚 ≈ 10 m']},
    {key:'uranus',name:'天王星',R:2.6,orbit:92,tilt:97.8,rev:0.0019,spin:2.23,color:'#9dd9e0',tex:'uranus.jpg',ring:'uranusring.jpg',
     desc:'冰巨星，自转轴几乎平躺于轨道面，呈青蓝色，大气富含甲烷，也有暗淡的环。',meta:['公转 84 年','自转 17.2 小时','侧躺自转']},
    {key:'neptune',name:'海王星',R:2.5,orbit:112,tilt:28.3,rev:0.00097,spin:2.39,color:'#4a7fd6',tex:'neptune.jpg',
     desc:'最远的行星，深蓝色冰巨星，风速可达 2100 km/h，是太阳系风暴之王。',meta:['公转 165 年','自转 16.1 小时','风速 2100 km/h']},
    {key:'pluto',name:'冥王星',R:0.4,orbit:138,tilt:122.5,rev:0.000645,spin:0.25,color:'#c2a08a',tex:'pluto.jpg',
     desc:'矮行星，曾被视为第九大行星。表面有著名的心形冰原平原，自转轴几乎侧躺。',meta:['公转 248 年','自转 6.39 天','2006 降为矮行星']}
  ];

  // ===== 背景星空天球（程序化银河贴图）=====
  function starfieldTex(){
    var w=2048,h=1024,c=document.createElement('canvas');c.width=w;c.height=h;var x=c.getContext('2d');
    var bg=x.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#04050c');bg.addColorStop(.5,'#080a1a');bg.addColorStop(1,'#04050c');
    x.fillStyle=bg;x.fillRect(0,0,w,h);
    x.save();x.translate(w/2,h/2);x.rotate(-0.5);x.translate(-w/2,-h/2);
    for(var i=0;i<24;i++){var px=Math.random()*w,py=h/2+(Math.random()-0.5)*h*0.3,r=90+Math.random()*200;
      var gg=x.createRadialGradient(px,py,0,px,py,r),hue=Math.random(),c1=hue<.4?'rgba(150,120,220,':(hue<.7?'rgba(90,130,210,':'rgba(200,120,150,');
      gg.addColorStop(0,c1+(0.05+Math.random()*.06)+')');gg.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=gg;x.fillRect(0,0,w,h);}
    for(var i=0;i<4400;i++){var px=Math.random()*w,py=h/2+(Math.random()-0.5)*h*0.32;
      var d=Math.abs(py-h/2)/(h*0.16),b=(1-d*d)*(.3+Math.random()*.6);if(b<=0)continue;
      x.fillStyle='rgba(255,255,255,'+b+')';x.fillRect(px,py,1,1);}
    x.restore();
    for(var i=0;i<4200;i++){var px=Math.random()*w,py=Math.random()*h,b=.15+Math.random()*.5;
      x.fillStyle='rgba(255,255,255,'+b+')';x.fillRect(px,py,1,1);}
    for(var i=0;i<220;i++){var px=Math.random()*w,py=Math.random()*h,b=.82+Math.random()*.18;
      x.fillStyle='rgba(255,255,255,'+b+')';x.fillRect(px,py,1,1);}
    var t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;return t;
  }
  var sky=new THREE.Mesh(new THREE.SphereGeometry(3500,48,32),new THREE.MeshBasicMaterial({map:starfieldTex(),side:THREE.BackSide,depthWrite:false}));
  scene.add(sky);

  // ===== 光照 =====
  scene.add(new THREE.AmbientLight(0x223044,0.5));
  var sunLight=new THREE.PointLight(0xfff2d0,2.6,0,1.3);scene.add(sunLight);

  // ===== 工具纹理 =====
  function radialTex(c0,c1,c2){
    var c=document.createElement('canvas');c.width=c.height=128;var x=c.getContext('2d'),g=x.createRadialGradient(64,64,0,64,64,64);
    g.addColorStop(0,c0);g.addColorStop(.4,c1);g.addColorStop(1,c2);x.fillStyle=g;x.fillRect(0,0,128,128);
    return new THREE.CanvasTexture(c);
  }
  function sunTex(){
    var c=document.createElement('canvas');c.width=c.height=512;var x=c.getContext('2d');
    x.fillStyle='#ff7a14';x.fillRect(0,0,512,512);
    for(var i=0;i<5200;i++){var px=Math.random()*512,py=Math.random()*512,r=1.5+Math.random()*7;
      x.fillStyle='rgba(255,'+(170+Math.random()*80|0)+','+(30+Math.random()*90|0)+','+(Math.random()*.45)+')';
      x.beginPath();x.arc(px,py,r,0,6.283);x.fill();}
    for(var j=0;j<90;j++){var px=Math.random()*512,py=Math.random()*512,r=8+Math.random()*36;
      var g=x.createRadialGradient(px,py,0,px,py,r);g.addColorStop(0,'rgba(255,245,205,.85)');g.addColorStop(1,'rgba(255,245,205,0)');
      x.fillStyle=g;x.beginPath();x.arc(px,py,r,0,6.283);x.fill();}
    return new THREE.CanvasTexture(c);
  }
  function plainTex(col){var c=document.createElement('canvas');c.width=c.height=4;c.getContext('2d').fillStyle=col;c.getContext('2d').fillRect(0,0,4,4);return new THREE.CanvasTexture(c);}

  // ===== 纹理加载器（容错）=====
  var loader=new THREE.TextureLoader();loader.setCrossOrigin('anonymous');
  var maxA=renderer.capabilities.getMaxAnisotropy();
  function load(u,ok){loader.load(u,ok,undefined,function(){});}

  // ===== 太阳 =====
  var sun=new THREE.Mesh(new THREE.SphereGeometry(SUN_R,48,48),new THREE.MeshBasicMaterial({map:sunTex()}));
  scene.add(sun);
  var glowA=new THREE.Sprite(new THREE.SpriteMaterial({map:radialTex('rgba(255,225,150,.95)','rgba(255,150,40,.4)','rgba(255,120,20,0)'),blending:THREE.AdditiveBlending,transparent:true,depthWrite:false}));
  glowA.scale.set(SUN_R*3.8,SUN_R*3.8,1);scene.add(glowA);
  var glowB=new THREE.Sprite(new THREE.SpriteMaterial({map:radialTex('rgba(255,180,80,.5)','rgba(255,120,30,.16)','rgba(255,100,20,0)'),blending:THREE.AdditiveBlending,transparent:true,depthWrite:false}));
  glowB.scale.set(SUN_R*5.5,SUN_R*5.5,1);scene.add(glowB);
  var glowC=new THREE.Sprite(new THREE.SpriteMaterial({map:radialTex('rgba(255,140,40,.22)','rgba(255,90,20,.08)','rgba(255,80,10,0)'),blending:THREE.AdditiveBlending,transparent:true,depthWrite:false}));
  glowC.scale.set(SUN_R*8,SUN_R*8,1);scene.add(glowC);

  // ===== 地球 =====
  var earthOrbit=new THREE.Group();scene.add(earthOrbit);
  var earthTilt=new THREE.Group();earthTilt.rotation.z=23.5*Math.PI/180;earthOrbit.add(earthTilt);
  var earthMat=new THREE.MeshStandardMaterial({map:plainTex('#2a5a9a'),roughness:.82,metalness:.06});
  var earth=new THREE.Mesh(new THREE.SphereGeometry(EARTH_R,40,40),earthMat);earthTilt.add(earth);
  var cloudMat=new THREE.MeshStandardMaterial({map:plainTex('#ffffff'),transparent:true,alphaMap:plainTex('#ffffff'),opacity:.55,roughness:1,depthWrite:false});
  var clouds=new THREE.Mesh(new THREE.SphereGeometry(EARTH_R*1.012,40,40),cloudMat);earthTilt.add(clouds);
  // 大气辉光
  var atmo=new THREE.Mesh(new THREE.SphereGeometry(EARTH_R*1.06,40,40),new THREE.MeshBasicMaterial({color:0x3a86d8,side:THREE.BackSide,transparent:true,opacity:.28,blending:THREE.AdditiveBlending,depthWrite:false}));
  earthTilt.add(atmo);

  // ===== 月球 =====
  var moonOrbit=new THREE.Group();earthOrbit.add(moonOrbit);
  var moonMat=new THREE.MeshStandardMaterial({map:plainTex('#b8b8b8'),roughness:.95});
  var moon=new THREE.Mesh(new THREE.SphereGeometry(MOON_R,28,28),moonMat);moonOrbit.add(moon);
  var moonGlow=new THREE.Sprite(new THREE.SpriteMaterial({map:radialTex('rgba(220,220,230,.18)','rgba(180,180,200,.06)','rgba(180,180,200,0)'),blending:THREE.AdditiveBlending,transparent:true,depthWrite:false}));
  moonGlow.scale.set(MOON_R*5,MOON_R*5,1);moon.add(moonGlow);

  // ===== 轨道线 =====
  function orbitLine(r,col){var n=160,pts=[];for(var i=0;i<=n;i++){var a=i/n*6.2832;pts.push(new THREE.Vector3(Math.cos(a)*r,0,Math.sin(a)*r));}
    return new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:col,transparent:true,opacity:.28}));}

  // ===== 其余七大行星 + 土星环 + 天王星环 =====
  var planetMap={},state={},pickList=[sun];
  sun.userData.key='sun';
  var _v3=new THREE.Vector3();
  PLANETS.forEach(function(p){
    if(p.key==='earth')return; // 地球已由原代码创建
    var og=new THREE.Group();scene.add(og);
    var tg=new THREE.Group();tg.rotation.z=p.tilt*Math.PI/180;og.add(tg);
    var mat=new THREE.MeshStandardMaterial({map:plainTex(p.color),roughness:.85,metalness:.04});
    var mesh=new THREE.Mesh(new THREE.SphereGeometry(p.R,40,40),mat);mesh.userData.key=p.key;tg.add(mesh);
    load('./assets/'+p.tex,function(t){t.encoding=THREE.sRGBEncoding;t.anisotropy=maxA;mat.map=t;mat.needsUpdate=true;});
    var ol=orbitLine(p.orbit,parseInt(p.color.slice(1),16));scene.add(ol);
    // 行星环（土星 / 天王星）
    if(p.ring){
      var inner=p.key==='saturn'?p.R*1.4:p.R*1.5,outer=p.key==='saturn'?p.R*2.35:p.R*1.95;
      var rg=new THREE.RingGeometry(inner,outer,96,1);
      var pos=rg.attributes.position,uv=rg.attributes.uv;
      for(var i=0;i<pos.count;i++){_v3.fromBufferAttribute(pos,i);var r=_v3.length();uv.setXY(i,(r-inner)/(outer-inner),0.5);}
      uv.needsUpdate=true;
      var ringMat=new THREE.MeshBasicMaterial({map:plainTex(p.key==='saturn'?'#d8c08a':'#9dd9e0'),side:THREE.DoubleSide,transparent:true,opacity:p.key==='saturn'?.92:.32,depthWrite:false});
      var ring=new THREE.Mesh(rg,ringMat);ring.rotation.x=Math.PI/2;tg.add(ring);
      load('./assets/'+p.ring,function(t){t.encoding=THREE.sRGBEncoding;t.anisotropy=maxA;ringMat.map=t;ringMat.needsUpdate=true;});
      p.ringMesh=ring;
    }
    p.orbitGroup=og;p.tiltGroup=tg;p.mesh=mesh;p.mat=mat;p.orbitLine=ol;
    planetMap[p.key]=p;pickList.push(mesh);
    state[p.key]={ang:Math.random()*6.2832,spin:Math.random()*6.2832};
  });
  earth.userData.key='earth';moon.userData.key='moon';
  pickList.push(earth);pickList.push(moon);

  var earthOrbitLine=orbitLine(EARTH_ORBIT,0x4a7fb5);scene.add(earthOrbitLine);
  var moonOrbitLine=orbitLine(MOON_ORBIT,0x8a8a8a);earthOrbit.add(moonOrbitLine);

  // ===== 地球/月球纹理加载 =====
  load('./assets/earth.jpg',function(t){t.encoding=THREE.sRGBEncoding;t.anisotropy=maxA;earthMat.map=t;earthMat.needsUpdate=true;});
  load('./assets/clouds.png',function(t){t.anisotropy=maxA;cloudMat.map=t;cloudMat.alphaMap=t;cloudMat.needsUpdate=true;});
  load('./assets/moon.jpg',function(t){t.encoding=THREE.sRGBEncoding;t.anisotropy=maxA;moonMat.map=t;moonMat.needsUpdate=true;});

  // ===== 星空 =====
  var stars=(function(){
    var n=4200,geo=new THREE.BufferGeometry(),pos=new Float32Array(n*3),col=new Float32Array(n*3);
    for(var i=0;i<n;i++){var u=Math.random()*2-1,v=Math.random()*6.2832,s=Math.sqrt(1-u*u),R=1100+Math.random()*700;
      pos[i*3]=R*s*Math.cos(v);pos[i*3+1]=R*u;pos[i*3+2]=R*s*Math.sin(v);
      var b=.25+Math.random()*.75,t=Math.random();
      if(t<.15){col[i*3]=b*.7;col[i*3+1]=b*.8;col[i*3+2]=b;}
      else if(t<.25){col[i*3]=b;col[i*3+1]=b*.85;col[i*3+2]=b*.7;}
      else{col[i*3]=b;col[i*3+1]=b;col[i*3+2]=b;}}
    geo.setAttribute('position',new THREE.BufferAttribute(pos,3));
    geo.setAttribute('color',new THREE.BufferAttribute(col,3));
    var m=new THREE.PointsMaterial({size:0.55,sizeAttenuation:true,vertexColors:true,transparent:true,opacity:.9,depthWrite:false});
    var p=new THREE.Points(geo,m);scene.add(p);return p;
  })();

  // ===== 相机控制 =====
  function overviewRadius(){var vFov=camera.fov*Math.PI/180;var hFov=2*Math.atan(Math.tan(vFov/2)*camera.aspect);return Math.max(80,152/Math.tan(hFov/2));}
  var theta=0.9,phi=1.32,radius=overviewRadius();
  var target=new THREE.Vector3(0,0,0),targetGoal=new THREE.Vector3(0,0,0);
  var radiusGoal=radius,R_MIN=12,R_MAX=480;
  var userZoomed=false;
  function camPos(){var sp=Math.sin(phi);
    camera.position.set(target.x+radius*sp*Math.sin(theta),target.y+radius*Math.cos(phi),target.z+radius*sp*Math.cos(theta));
    camera.lookAt(target);}

  // 跟踪
  var focus=null;
  function focusDist(R,minD){var vFov=camera.fov*Math.PI/180;var hFov=2*Math.atan(Math.tan(vFov/2)*camera.aspect);return Math.max(minD,4.2*R/Math.tan(hFov/2));}
  function targetRadiusFor(f){
    if(!f)return overviewRadius();
    if(f==='sun')return focusDist(SUN_R,54);
    if(f==='moon')return focusDist(MOON_R,15);
    if(f==='earth')return focusDist(EARTH_R,22);
    var p=planetMap[f];if(!p)return overviewRadius();
    var minD=Math.max(18,p.R*5.5);
    return focusDist(p.R,minD);
  }
  var focusTargets={sun:sun,earth:earth,moon:moon};
  for(var k in planetMap)focusTargets[k]=planetMap[k].mesh;
  var info={
    sun:{name:'太阳',color:'#ffb84d',desc:'太阳系的中心恒星，一颗 G 型主序星。它几乎占据太阳系全部质量，通过核聚变向外辐射光与热。',meta:['表面 ≈ 5500°C','质量占比 99.8%','光球自转 ≈ 25 天']},
    moon:{name:'月球',color:'#cfcfcf',desc:'地球唯一的天然卫星。它被潮汐锁定，始终以同一面朝向地球，引力主宰着海洋潮汐。',meta:['潮汐锁定','距地 38.4 万 km','公转 ≈ 27.3 天']}
  };
  PLANETS.forEach(function(p){info[p.key]={name:p.name,color:p.color,desc:p.desc,meta:p.meta};});

  function setFocus(f){
    focus=f;
    userZoomed=false;
    radiusGoal=targetRadiusFor(f);
    if(f){var card=document.getElementById('card');card.classList.add('show');
      var d=info[f];document.getElementById('cName').textContent=d.name;
      document.getElementById('cDot').style.background=d.color;
      document.getElementById('cDesc').textContent=d.desc;
      document.getElementById('cMeta').innerHTML=d.meta.map(function(m){return '<span>'+m+'</span>';}).join('');}
    else{document.getElementById('card').classList.remove('show');target.set(0,0,0);}
    var btns=document.querySelectorAll('#dock button');
    for(var i=0;i<btns.length;i++){var on=btns[i].getAttribute('data-f')===(f||'');
      btns[i].classList.toggle('on',on);
      if(on){try{btns[i].scrollIntoView({behavior:'smooth',inline:'center',block:'nearest'});}catch(_){btns[i].scrollIntoView(true);}}}
  }

  // 拖动 + 点击
  /* 手势：单指旋转 / 双指缩放，两者互斥。
   * 触屏上 pointer* 与 touch* 是并行发出的两套事件，而旧版只用一个裸 dragging 布尔、
   * 不区分是哪根手指 —— 双指按下时两根手指各发各的 pointermove、都去改 theta/phi，
   * 且 lx/ly 被两指轮流覆盖（算出来的是跨手指的巨大位移），画面就在两指之间来回跳。
   * 现在每根手指单独记坐标与本次按下的起点，只有「屏上仅一根手指」时旋转。 */
  var pointers={},dragId=null,pinch=0,multi=false;
  function pCount(){var n=0,k;for(k in pointers)if(pointers[k])n++;return n;}
  function armDrag(id){dragId=id;lx=pointers[id].x;ly=pointers[id].y;}
  function stopDrag(){dragId=null;}
  function tdist(t){return Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY);}
  cv.addEventListener('pointerdown',function(e){
    pointers[e.pointerId]={x:e.clientX,y:e.clientY,downX:e.clientX,downY:e.clientY,downT:performance.now(),moved:false};
    if(pCount()>1){multi=true;stopDrag();return;}      // 第二指落下：旋转让位给缩放
    armDrag(e.pointerId);
    cv.setPointerCapture(e.pointerId);
  });
  function onPointerEnd(e){
    var p=pointers[e.pointerId];
    delete pointers[e.pointerId];
    if(dragId===e.pointerId)stopDrag();
    try{cv.releasePointerCapture(e.pointerId)}catch(_){}
    var n=pCount();
    if(n===0){
      /* 轻点拾取：只认「单指、短暂、几乎没动」的那一次；双指手势一律不算点击 */
      if(p&&!multi&&!p.moved&&performance.now()-p.downT<350&&Math.hypot(e.clientX-p.downX,e.clientY-p.downY)<10){handleClick(e.clientX,e.clientY);}
      multi=false;stopDrag();return;
    }
    if(n===1){for(var id in pointers)if(pointers[id]){armDrag(Number(id));break;}}   // 缩放抬起一指：剩下那根接回旋转
  }
  cv.addEventListener('pointerup',onPointerEnd);
  cv.addEventListener('pointercancel',onPointerEnd);
  cv.addEventListener('pointermove',function(e){
    var p=pointers[e.pointerId];if(!p)return;
    p.x=e.clientX;p.y=e.clientY;
    if(Math.hypot(e.clientX-p.downX,e.clientY-p.downY)>6)p.moved=true;
    if(e.pointerId!==dragId)return;
    if(pCount()>1){stopDrag();return;}                 // 兜底：漏掉 pointerdown 时也不旋转
    var dx=e.clientX-lx,dy=e.clientY-ly;lx=e.clientX;ly=e.clientY;
    theta-=dx*0.005;phi-=dy*0.005;phi=Math.max(0.08,Math.min(Math.PI-0.08,phi));
  });
  cv.addEventListener('wheel',function(e){e.preventDefault();radius*=1+Math.sign(e.deltaY)*0.08;radius=Math.max(R_MIN,Math.min(R_MAX,radius));userZoomed=true;},{passive:false});
  cv.addEventListener('touchstart',function(e){if(e.touches.length===2){stopDrag();pinch=tdist(e.touches);}},{passive:true});
  cv.addEventListener('touchend',function(e){if(e.touches.length<2)pinch=0;},{passive:true});   // 清基线：下次双指重新按下按当下指距起算
  cv.addEventListener('touchcancel',function(){pinch=0;},{passive:true});
  /* 两指几乎重合时 d→0，pinch/d 会炸成天文数字把镜头甩飞；12px 以内只更新基线不缩放 */
  cv.addEventListener('touchmove',function(e){if(e.touches.length!==2)return;e.preventDefault();var d=tdist(e.touches);if(pinch>12&&d>12){radius*=pinch/d;radius=Math.max(R_MIN,Math.min(R_MAX,radius));userZoomed=true;}pinch=d;},{passive:false});

  // 点击拾取
  var ray=new THREE.Raycaster(),ndc=new THREE.Vector2();
  function handleClick(cx,cy){
    ndc.x=(cx/W)*2-1;ndc.y=-(cy/H)*2+1;
    ray.setFromCamera(ndc,camera);
    var hits=ray.intersectObjects(pickList,false);
    if(hits.length){var k=hits[0].object.userData.key;setFocus(focus===k?null:k);}
    else{if(focus)setFocus(null);}
  }

  // dock 按钮
  var dDragged=false;
  document.querySelectorAll('#dock button').forEach(function(b){
    b.addEventListener('click',function(){
      if(dDragged){dDragged=false;return;} // 鼠标拖拽滚动后不触发选中
      var f=b.getAttribute('data-f');setFocus(focus===f?null:(f||null));
    });
  });
  // dock 滚动：触摸端用原生横滑（CSS touch-action:pan-x），桌面端滚轮横滚 + 鼠标拖拽
  var dockEl=document.getElementById('dock');
  dockEl.addEventListener('wheel',function(e){
    if(Math.abs(e.deltaX)>Math.abs(e.deltaY))return; // 触控板横滚交给原生
    e.preventDefault();
    dockEl.scrollLeft+=e.deltaY;
  },{passive:false});
  // 桌面端鼠标拖拽滚动（触摸端原生滚动，无需处理）
  var pDown=false,pX=0;
  dockEl.addEventListener('pointerdown',function(e){
    if(e.pointerType!=='mouse')return;
    pDown=true;pX=e.clientX;dDragged=false;
  });
  dockEl.addEventListener('pointermove',function(e){
    if(!pDown)return;
    var dx=e.clientX-pX;
    if(Math.abs(dx)>4){dDragged=true;dockEl.setPointerCapture(e.pointerId);}
    if(dDragged){dockEl.scrollLeft-=dx;pX=e.clientX;}
  });
  function pEnd(){pDown=false;}
  dockEl.addEventListener('pointerup',pEnd);
  dockEl.addEventListener('pointercancel',pEnd);
  // dock 溢出时启用两端渐隐
  function dockFade(){dockEl.classList.toggle('scrollable',dockEl.scrollWidth>dockEl.clientWidth+1);}
  dockEl.addEventListener('scroll',function(){dockEl.classList.add('scrollable');});
  addEventListener('resize',dockFade);dockFade();
  setTimeout(dockFade,400);

  // 设置
  var playing=true,showOrbit=true,showLabel=true,showStars=true,speedMul=1;
  function bind(id,fn){var el=document.getElementById(id);el.addEventListener('click',function(){el.classList.toggle('on');fn(el.classList.contains('on'));});}
  bind('swPlay',function(v){playing=v;});
  bind('swOrbit',function(v){showOrbit=v;earthOrbitLine.visible=v;moonOrbitLine.visible=v;for(var kk in planetMap)planetMap[kk].orbitLine.visible=v;});
  bind('swLabel',function(v){showLabel=v;});
  bind('swStars',function(v){showStars=v;stars.visible=v;sky.visible=v;});
  var spEl=document.getElementById('speed'),vSp=document.getElementById('vSpeed');
  spEl.addEventListener('input',function(){speedMul=spEl.value/100;vSp.textContent=speedMul.toFixed(1)+'×';});
  document.getElementById('bReset').addEventListener('click',function(){theta=0.9;phi=1.32;setFocus(null);radius=radiusGoal;});
  document.getElementById('bTop').addEventListener('click',function(){theta=0.9;phi=0.02;if(focus)setFocus(null);else{radiusGoal=overviewRadius();userZoomed=false;}radius=radiusGoal;});
  var sheet=document.getElementById('sheet'),scrim=document.getElementById('scrim');
  function openSheet(v){sheet.classList.toggle('show',v);scrim.classList.toggle('show',v);}
  document.getElementById('gear').addEventListener('click',function(){openSheet(true);});
  document.getElementById('sClose').addEventListener('click',function(){openSheet(false);});
  scrim.addEventListener('click',function(){openSheet(false);});

  // 标签（动态创建所有天体）
  var tags={};
  function mkTag(name){var el=document.createElement('div');el.className='tag';el.textContent=name;document.body.appendChild(el);return el;}
  tags.sun=mkTag('太阳');tags.earth=mkTag('地球');tags.moon=mkTag('月球');
  for(var tk in planetMap)tags[tk]=mkTag(planetMap[tk].name);
  var _v=new THREE.Vector3();
  function project(obj,el){_v.setFromMatrixPosition(obj.matrixWorld);_v.project(camera);
    var x=(_v.x*0.5+0.5)*W,y=(-_v.y*0.5+0.5)*H;
    if(_v.z<1){el.style.left=x+'px';el.style.top=y+'px';el.style.opacity=showLabel?'1':'0';}else el.style.opacity='0';}

  // 动画
  var clock=new THREE.Clock();
  var running=true,perfAccum=0,perfCount=0,dprStep=DPR;
  var eAng=0.6,mAng=0,eSpin=0;
  var EARTH_REV=0.16,MOON_REV=2.15,EARTH_SPIN=1.6,SUN_SPIN=0.05;
  function animate(){
    if(!running)return;
    requestAnimationFrame(animate);
    var dt=clock.getDelta();
    if(playing){var s=dt*speedMul;
      eAng+=s*EARTH_REV;mAng+=s*MOON_REV;eSpin+=s*EARTH_SPIN;
      earthOrbit.position.set(Math.cos(eAng)*EARTH_ORBIT,0,-Math.sin(eAng)*EARTH_ORBIT);
      moonOrbit.position.set(Math.cos(mAng)*MOON_ORBIT,0,-Math.sin(mAng)*MOON_ORBIT);
      earth.rotation.y=eSpin;clouds.rotation.y=eSpin*1.12;moon.rotation.y=Math.PI+mAng;sun.rotation.y+=s*SUN_SPIN;
      for(var pk in planetMap){var p=planetMap[pk],st=state[pk];st.ang+=s*p.rev;st.spin+=s*p.spin;
        p.orbitGroup.position.set(Math.cos(st.ang)*p.orbit,0,-Math.sin(st.ang)*p.orbit);
        p.mesh.rotation.y=st.spin;}
      stars.rotation.y+=s*0.003;sky.rotation.y+=s*0.001;}
    // 跟踪插值
    if(focus){targetGoal.setFromMatrixPosition(focusTargets[focus].matrixWorld);}
    else{targetGoal.set(0,0,0);}
    target.lerp(targetGoal,0.15);
    if(!userZoomed)radius+=(radiusGoal-radius)*0.08;
    camPos();
    renderer.render(scene,camera);
    project(sun,tags.sun);project(earth,tags.earth);project(moon,tags.moon);
    for(var pk2 in planetMap)project(planetMap[pk2].mesh,tags[pk2]);
    perfAccum+=dt;perfCount++;
    if(perfCount>=30){var avg=perfAccum/perfCount;perfAccum=0;perfCount=0;if(avg>0.04&&dprStep>1){dprStep=Math.max(1,dprStep-0.25);renderer.setPixelRatio(dprStep);renderer.setSize(W,H,false);}}
  }

  addEventListener('resize',function(){W=innerWidth;H=innerHeight;camera.aspect=W/H;camera.updateProjectionMatrix();renderer.setSize(W,H,false);if(!userZoomed){radiusGoal=targetRadiusFor(focus);}});

  addEventListener('visibilitychange',function(){if(document.hidden){running=false;}else if(!running){running=true;clock.getDelta();animate();}});
  cv.addEventListener('webglcontextlost',function(e){e.preventDefault();running=false;document.getElementById('loader').classList.add('hide');document.getElementById('fallback').classList.add('show');},false);
  animate();
  setTimeout(function(){document.getElementById('loader').classList.add('hide');},600);
  setTimeout(function(){var t=document.getElementById('tip');t.classList.add('show');setTimeout(function(){t.classList.remove('show');},3200);},1400);
})();
