(function(){
  var cv=document.getElementById('stage');
  var gl=null;try{gl=cv.getContext('webgl2')||cv.getContext('webgl')}catch(e){}
  if(!gl||typeof THREE==='undefined'){document.getElementById('fallback').classList.add('show');document.getElementById('loader').classList.add('hide');return;}

  var W=innerWidth,H=innerHeight,DPR=Math.min(devicePixelRatio||1,1.5);
  var renderer=new THREE.WebGLRenderer({canvas:cv,antialias:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(DPR);renderer.setSize(W,H,false);
  renderer.outputEncoding=THREE.sRGBEncoding;
  renderer.toneMapping=THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure=1.08;

  var scene=new THREE.Scene();
  var camera=new THREE.PerspectiveCamera(52,W/H,0.1,5000);

  var R=1.6,SUN_R=7,ORBIT=26;

  // ===== 背景星空天球（程序化银河贴图）=====
  function starfieldTex(){
    var w=2048,h=1024,c=document.createElement('canvas');c.width=w;c.height=h;var x=c.getContext('2d');
    var bg=x.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#04050c');bg.addColorStop(.5,'#080a1a');bg.addColorStop(1,'#04050c');
    x.fillStyle=bg;x.fillRect(0,0,w,h);
    x.save();x.translate(w/2,h/2);x.rotate(-0.5);x.translate(-w/2,-h/2);
    for(var i=0;i<24;i++){var px=Math.random()*w,py=h/2+(Math.random()-0.5)*h*0.3,r=90+Math.random()*200;
      var gg=x.createRadialGradient(px,py,0,px,py,r),hue=Math.random(),c1=hue<.4?'rgba(150,120,220,':(hue<.7?'rgba(90,130,210,':'rgba(200,120,150,');
      gg.addColorStop(0,c1+(0.05+Math.random()*.06)+')');gg.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=gg;x.fillRect(0,0,w,h);}
    for(var i=0;i<4400;i++){var px=Math.random()*w,py=h/2+(Math.random()-0.5)*h*0.32;
      var d=Math.abs(py-h/2)/(h*0.16),b=(1-d*d)*(.3+Math.random()*.6);if(b<=0)continue;
      x.fillStyle='rgba(255,255,255,'+b+')';x.fillRect(px,py,1,1);}
    x.restore();
    for(var i=0;i<4200;i++){var px=Math.random()*w,py=Math.random()*h,b=.15+Math.random()*.5;
      x.fillStyle='rgba(255,255,255,'+b+')';x.fillRect(px,py,1,1);}
    for(var i=0;i<220;i++){var px=Math.random()*w,py=Math.random()*h,b=.82+Math.random()*.18;
      x.fillStyle='rgba(255,255,255,'+b+')';x.fillRect(px,py,1,1);}
    var t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;return t;
  }
  var sky=new THREE.Mesh(new THREE.SphereGeometry(3500,48,32),new THREE.MeshBasicMaterial({map:starfieldTex(),side:THREE.BackSide,depthWrite:false}));
  scene.add(sky);

  // ===== 光照 =====
  var ambient=new THREE.AmbientLight(0x223044,0.5);scene.add(ambient);
  var sunLight=new THREE.PointLight(0xfff2d0,2.4,0,1.3);sunLight.position.set(38,12,22);scene.add(sunLight);

  // ===== 工具纹理 =====
  function radialTex(c0,c1,c2){
    var c=document.createElement('canvas');c.width=c.height=128;var x=c.getContext('2d'),g=x.createRadialGradient(64,64,0,64,64,64);
    g.addColorStop(0,c0);g.addColorStop(.4,c1);g.addColorStop(1,c2);x.fillStyle=g;x.fillRect(0,0,128,128);
    return new THREE.CanvasTexture(c);
  }
  function sunTex(){
    var c=document.createElement('canvas');c.width=c.height=512;var x=c.getContext('2d');
    x.fillStyle='#ff7a14';x.fillRect(0,0,512,512);
    for(var i=0;i<5200;i++){var px=Math.random()*512,py=Math.random()*512,r=1.5+Math.random()*7;
      x.fillStyle='rgba(255,'+(170+Math.random()*80|0)+','+(30+Math.random()*90|0)+','+(Math.random()*.45)+')';
      x.beginPath();x.arc(px,py,r,0,6.283);x.fill();}
    for(var j=0;j<90;j++){var px=Math.random()*512,py=Math.random()*512,r=8+Math.random()*36;
      var g=x.createRadialGradient(px,py,0,px,py,r);g.addColorStop(0,'rgba(255,245,205,.85)');g.addColorStop(1,'rgba(255,245,205,0)');
      x.fillStyle=g;x.beginPath();x.arc(px,py,r,0,6.283);x.fill();}
    return new THREE.CanvasTexture(c);
  }
  function plainTex(col){var c=document.createElement('canvas');c.width=c.height=4;c.getContext('2d').fillStyle=col;c.getContext('2d').fillRect(0,0,4,4);return new THREE.CanvasTexture(c);}

  // 经纬度 → 球面坐标（与 three.js SphereGeometry 贴图 UV 对齐）
  function ll2v(lat,lon,r){
    var th=(90-lat)*Math.PI/180,p=(lon+180)/360*Math.PI*2;
    return new THREE.Vector3(-r*Math.cos(p)*Math.sin(th),r*Math.cos(th),r*Math.sin(p)*Math.sin(th));
  }

  // ===== 主地球（星球 / 昼夜 / 经纬模式共用）=====
  var mainTilt=new THREE.Group();mainTilt.rotation.z=23.5*Math.PI/180;scene.add(mainTilt);
  var mainSpin=new THREE.Group();mainTilt.add(mainSpin);
  var earthMat=new THREE.MeshStandardMaterial({map:plainTex('#2a5a9a'),roughness:.82,metalness:.06});
  var earthMesh=new THREE.Mesh(new THREE.SphereGeometry(R,48,32),earthMat);mainSpin.add(earthMesh);
  var cloudMat=new THREE.MeshStandardMaterial({map:plainTex('#ffffff'),transparent:true,alphaMap:plainTex('#ffffff'),opacity:.55,roughness:1,depthWrite:false});
  var clouds=new THREE.Mesh(new THREE.SphereGeometry(R*1.012,48,32),cloudMat);mainTilt.add(clouds);
  var atmo=new THREE.Mesh(new THREE.SphereGeometry(R*1.06,48,32),new THREE.MeshBasicMaterial({color:0x3a86d8,side:THREE.BackSide,transparent:true,opacity:.28,blending:THREE.AdditiveBlending,depthWrite:false}));
  mainTilt.add(atmo);

  // ===== 经纬网 =====
  var gridGroup=new THREE.Group();mainSpin.add(gridGroup);
  function latRing(lat,r,color,op){
    var pts=[];for(var i=0;i<=160;i++){pts.push(ll2v(lat,i/160*360-180,r));}
    return new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:color,transparent:true,opacity:op}));
  }
  function meridian(lon,r,color,op){
    var pts=[],p=(lon+180)/360*Math.PI*2;
    for(var i=0;i<=160;i++){var th=i/160*Math.PI*2;pts.push(new THREE.Vector3(-r*Math.cos(p)*Math.sin(th),r*Math.cos(th),r*Math.sin(p)*Math.sin(th)));}
    return new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:color,transparent:true,opacity:op}));
  }
  (function buildGrid(){
    var gR=R*1.004,lats=[-75,-60,-45,-30,-15,15,30,45,60,75],i;
    for(i=0;i<lats.length;i++)gridGroup.add(latRing(lats[i],gR,0x9fc4e8,.22));
    for(i=0;i<12;i++)gridGroup.add(meridian(i*15,gR,0x9fc4e8,.18));
    gridGroup.add(latRing(0,gR,0xff8080,.85));
    gridGroup.add(latRing(23.5,gR,0xffd166,.75));gridGroup.add(latRing(-23.5,gR,0xffd166,.75));
    gridGroup.add(latRing(66.5,gR,0x8ad0ff,.8));gridGroup.add(latRing(-66.5,gR,0x8ad0ff,.8));
    gridGroup.add(meridian(0,gR,0x86e3a0,.85));
  })();
  gridGroup.visible=false;

  // （昼夜模式北京标记已移除）

  // ===== 地球内部结构（剖切模型）=====
  var layersGroup=new THREE.Group();layersGroup.visible=false;scene.add(layersGroup);
  var PHI0=0.6981,PHIL=4.8869; // 挖掉以 -X 为中心的 80° 楔形
  function wedgeGeo(r,fixUv){
    var g=new THREE.SphereGeometry(r,48,32,PHI0,PHIL);
    if(fixUv){var uv=g.attributes.uv;for(var i=0;i<uv.count;i++)uv.setX(i,(PHI0+uv.getX(i)*PHIL)/(Math.PI*2));}
    return g;
  }
  var crustMat=new THREE.MeshStandardMaterial({map:plainTex('#2a5a9a'),roughness:.85});
  var mantleMat=new THREE.MeshStandardMaterial({color:0xb5472e,roughness:.9,emissive:0x2a0d06});
  var outerMat=new THREE.MeshStandardMaterial({color:0xff8a3c,roughness:.6,emissive:0x8a3200,emissiveIntensity:.8});
  var innerMat=new THREE.MeshStandardMaterial({color:0xffd98a,roughness:.5,emissive:0xcc7a1e,emissiveIntensity:.9});
  layersGroup.add(new THREE.Mesh(wedgeGeo(R,true),crustMat));
  layersGroup.add(new THREE.Mesh(wedgeGeo(R*0.97),mantleMat));
  layersGroup.add(new THREE.Mesh(wedgeGeo(R*0.55),outerMat));
  layersGroup.add(new THREE.Mesh(new THREE.SphereGeometry(R*0.19,32,24),innerMat));
  // 剖面贴图：同心环
  function sectionTex(){
    var c=document.createElement('canvas');c.width=c.height=512;var x=c.getContext('2d');
    function band(r,col){x.fillStyle=col;x.beginPath();x.arc(256,256,r,0,6.283);x.fill();}
    band(256,'#476b8f');band(248,'#b5472e');band(141,'#ff8a3c');band(49,'#ffd98a');
    x.strokeStyle='rgba(0,0,0,.35)';x.lineWidth=2;
    [248,141,49].forEach(function(r){x.beginPath();x.arc(256,256,r,0,6.283);x.stroke();});
    return new THREE.CanvasTexture(c);
  }
  var secMat=new THREE.MeshStandardMaterial({map:sectionTex(),side:THREE.DoubleSide,roughness:.75});
  function cutFace(dx,dz){
    var m=new THREE.Mesh(new THREE.CircleGeometry(R,72,0,Math.PI),secMat);
    var xA=new THREE.Vector3(0,1,0),yA=new THREE.Vector3(dx,0,dz).normalize(),zA=new THREE.Vector3().crossVectors(xA,yA);
    m.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(xA,yA,zA));
    return m;
  }
  var c40=Math.cos(PHI0),s40=Math.sin(PHI0);
  layersGroup.add(cutFace(-c40,s40));
  layersGroup.add(cutFace(-c40,-s40));
  // 标签锚点落在面向相机的剖切面上，按角度扇形展开（原始实现把四层锚点放在同一条射线上，
  // 该射线几乎正对默认相机，投影后四个标签会挤到同一像素上）
  var CUT_D=new THREE.Vector3(-c40,0,-s40),CUT_U=new THREE.Vector3(0,1,0);
  function layerAnchor(r,angDeg){
    var a=angDeg*Math.PI/180,o=new THREE.Object3D();
    o.position.copy(CUT_D).multiplyScalar(r*Math.cos(a)).addScaledVector(CUT_U,r*Math.sin(a));
    layersGroup.add(o);return o;
  }

  // ===== 四季（太阳 + 公转地球）=====
  var seasonsGroup=new THREE.Group();seasonsGroup.visible=false;scene.add(seasonsGroup);
  var sun=new THREE.Mesh(new THREE.SphereGeometry(SUN_R,48,48),new THREE.MeshBasicMaterial({map:sunTex()}));
  seasonsGroup.add(sun);
  var glowA=new THREE.Sprite(new THREE.SpriteMaterial({map:radialTex('rgba(255,225,150,.95)','rgba(255,150,40,.4)','rgba(255,120,20,0)'),blending:THREE.AdditiveBlending,transparent:true,depthWrite:false}));
  glowA.scale.set(SUN_R*3.8,SUN_R*3.8,1);seasonsGroup.add(glowA);
  var glowB=new THREE.Sprite(new THREE.SpriteMaterial({map:radialTex('rgba(255,180,80,.5)','rgba(255,120,30,.16)','rgba(255,100,20,0)'),blending:THREE.AdditiveBlending,transparent:true,depthWrite:false}));
  glowB.scale.set(SUN_R*5.5,SUN_R*5.5,1);seasonsGroup.add(glowB);
  function orbitLine(r,col){
    var pts=[];for(var i=0;i<=160;i++){var a=i/160*6.2832;pts.push(new THREE.Vector3(Math.cos(a)*r,0,Math.sin(a)*r));}
    return new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:col,transparent:true,opacity:.28}));
  }
  var seasonOrbitLine=orbitLine(ORBIT,0x4a7fb5);seasonsGroup.add(seasonOrbitLine);
  // 公转组只平移不旋转 → 地轴指向在空间中保持不变
  var orbitGroup=new THREE.Group();seasonsGroup.add(orbitGroup);
  var tiltG=new THREE.Group();tiltG.rotation.z=23.5*Math.PI/180;orbitGroup.add(tiltG);
  var seasonSpin=new THREE.Group();tiltG.add(seasonSpin);
  var sEarth=new THREE.Mesh(new THREE.SphereGeometry(R,40,28),earthMat);seasonSpin.add(sEarth);
  var sgR=R*1.005;
  tiltG.add(latRing(0,sgR,0xffffff,.3));
  tiltG.add(latRing(23.5,sgR,0xffd166,.7));tiltG.add(latRing(-23.5,sgR,0xffd166,.7));
  tiltG.add(latRing(66.5,sgR,0x8ad0ff,.8));tiltG.add(latRing(-66.5,sgR,0x8ad0ff,.8));
  // 太阳直射点
  var zhi=new THREE.Group();
  var zhiDot=new THREE.Mesh(new THREE.SphereGeometry(0.055,12,12),new THREE.MeshBasicMaterial({color:0xffee88}));
  zhi.add(zhiDot);
  var zhiGlow=new THREE.Sprite(new THREE.SpriteMaterial({map:radialTex('rgba(255,240,150,.95)','rgba(255,200,60,.35)','rgba(255,180,40,0)'),blending:THREE.AdditiveBlending,transparent:true,depthWrite:false}));
  zhiGlow.scale.set(.6,.6,1);zhi.add(zhiGlow);
  orbitGroup.add(zhi);
  function seasonAnchor(x,z){var o=new THREE.Object3D();o.position.set(x,0,z);seasonsGroup.add(o);return o;}

  // （昼夜晨昏线锚点已移除）

  // ===== 地月系统（月相）=====
  // 月球自己不发光，我们看到的月光是它反射的太阳光。月球绕地球公转时，
  // 被照亮的一面相对地球不断改变朝向我们，于是有了月相。
  var MOON_R=0.6,MOON_ORBIT=4.0,SYNODIC=29.53;
  // 轨道角 a → 空间位置；a=π 时月球落在地球与太阳之间
  function moonPosOn(a,r){return new THREE.Vector3(Math.cos(a)*r,0,-Math.sin(a)*r);}
  var moonGroup=new THREE.Group();moonGroup.visible=false;scene.add(moonGroup);
  // 平行阳光：用方向光，晨昏线才是准确的大圆（这正是月相形状的关键）
  var moonLight=new THREE.DirectionalLight(0xfff2d0,2.9);
  moonLight.position.set(-42,0,0);moonGroup.add(moonLight);moonGroup.add(moonLight.target);
  // 地球（与主场景共用贴图与材质）
  var mTilt=new THREE.Group();mTilt.rotation.z=23.5*Math.PI/180;moonGroup.add(mTilt);
  var mSpin=new THREE.Group();mTilt.add(mSpin);
  mSpin.add(new THREE.Mesh(new THREE.SphereGeometry(R,40,32),earthMat));
  var mClouds=new THREE.Mesh(new THREE.SphereGeometry(R*1.012,40,32),cloudMat);mTilt.add(mClouds);
  mTilt.add(new THREE.Mesh(new THREE.SphereGeometry(R*1.06,40,32),atmo.material));
  // 月球
  var moonOrbit=new THREE.Group();moonGroup.add(moonOrbit);
  var moonMat=new THREE.MeshStandardMaterial({map:plainTex('#c6c6c6'),roughness:.95,metalness:0});
  var moon=new THREE.Mesh(new THREE.SphereGeometry(MOON_R,32,32),moonMat);moonOrbit.add(moon);
  var moonGlow=new THREE.Sprite(new THREE.SpriteMaterial({map:radialTex('rgba(216,224,240,.16)','rgba(160,175,205,.05)','rgba(160,175,205,0)'),blending:THREE.AdditiveBlending,transparent:true,depthWrite:false}));
  moonGlow.scale.set(MOON_R*5.6,MOON_R*5.6,1);moon.add(moonGlow);
  // 月球轨道
  var moonOrbitLine=orbitLine(MOON_ORBIT,0x6f8096);moonGroup.add(moonOrbitLine);
  // 八个相位定位点：a=π 时月球位于地球与太阳之间 → 新月
  var phaseDotMat=new THREE.MeshBasicMaterial({color:0x9fb6d6,transparent:true,opacity:.85});
  for(var pi8=0;pi8<8;pi8++){
    var pa=Math.PI+pi8*Math.PI/4,pp=moonPosOn(pa,MOON_ORBIT);
    var dot=new THREE.Mesh(new THREE.SphereGeometry(0.07,10,10),phaseDotMat);
    dot.position.copy(pp);moonGroup.add(dot);
  }
  var earthAnchor=new THREE.Object3D();earthAnchor.position.set(0,R*1.3,0);moonGroup.add(earthAnchor);

  // ===== 星空点 =====
  var stars=(function(){
    var n=4200,geo=new THREE.BufferGeometry(),pos=new Float32Array(n*3),col=new Float32Array(n*3);
    for(var i=0;i<n;i++){var u=Math.random()*2-1,v=Math.random()*6.2832,s=Math.sqrt(1-u*u),Rr=1100+Math.random()*700;
      pos[i*3]=Rr*s*Math.cos(v);pos[i*3+1]=Rr*u;pos[i*3+2]=Rr*s*Math.sin(v);
      var b=.25+Math.random()*.75,t=Math.random();
      if(t<.15){col[i*3]=b*.7;col[i*3+1]=b*.8;col[i*3+2]=b;}
      else if(t<.25){col[i*3]=b;col[i*3+1]=b*.85;col[i*3+2]=b*.7;}
      else{col[i*3]=b;col[i*3+1]=b;col[i*3+2]=b;}}
    geo.setAttribute('position',new THREE.BufferAttribute(pos,3));
    geo.setAttribute('color',new THREE.BufferAttribute(col,3));
    var m=new THREE.PointsMaterial({size:0.55,sizeAttenuation:true,vertexColors:true,transparent:true,opacity:.9,depthWrite:false});
    var p=new THREE.Points(geo,m);scene.add(p);return p;
  })();

  // ===== 纹理加载（容错）=====
  var loader=new THREE.TextureLoader();loader.setCrossOrigin('anonymous');
  var maxA=renderer.capabilities.getMaxAnisotropy();
  function load(u,ok){loader.load(u,ok,undefined,function(){});}
  load('./assets/earth.jpg',function(t){t.encoding=THREE.sRGBEncoding;t.anisotropy=maxA;earthMat.map=t;earthMat.needsUpdate=true;
    var t2=t.clone();t2.needsUpdate=true;crustMat.map=t2;crustMat.needsUpdate=true;});
  load('./assets/clouds.png',function(t){t.anisotropy=maxA;cloudMat.map=t;cloudMat.alphaMap=t;cloudMat.needsUpdate=true;});
  load('./assets/moon.jpg',function(t){t.encoding=THREE.sRGBEncoding;t.anisotropy=maxA;moonMat.map=t;moonMat.needsUpdate=true;});

  // ===== 相机 =====
  function fitR(minD){var vFov=camera.fov*Math.PI/180;var hFov=2*Math.atan(Math.tan(vFov/2)*camera.aspect);return Math.max(minD,2.4*R/Math.tan(hFov/2));}
  function seasonR(){var vFov=camera.fov*Math.PI/180;var hFov=2*Math.atan(Math.tan(vFov/2)*camera.aspect);return Math.max(56,(ORBIT+7)/Math.tan(hFov/2));}
  // 横竖两个方向都要容得下 extent（宽屏下竖向视野更窄，只按横向算会把轨道切掉）
  function fitBox(extent,minD){var vFov=camera.fov*Math.PI/180;var hFov=2*Math.atan(Math.tan(vFov/2)*camera.aspect);
    return Math.max(minD,extent/Math.tan(hFov/2),extent/Math.tan(vFov/2));}
  // 内部视图取景：剖切面上挤着四层标签，按通用间距地球缩得太小、标签会糊成一团。
  // 让地球直径约占视口较短边的 60%，横竖两个方向同时收敛（宽屏下竖向才是瓶颈）。
  function layerR(){
    var vFov=camera.fov*Math.PI/180,tanV=Math.tan(vFov/2),tanH=tanV*camera.aspect;
    return Math.max(4.6,R/(0.60*Math.min(tanH,tanV)));
  }
  var PRESETS={
    overview:function(){return[0.9,1.22,fitR(6)];},
    seasons:function(){return[0.9,0.62,seasonR()];},
    // 俯视地月系统：镜头垂直于地日连线，阳光自屏幕左侧平行射入、轨道面近似正圆，
    // 正对教科书上那张月相图
    moon:function(){return[0,0.46,fitBox(5.6,12)];},
    layers:function(){return[-1.5708,1.22,layerR()];},
    grid:function(){return[0.6,1.15,fitR(6)];}
  };
  var theta=0.9,phi=1.22,radius=fitR(6);
  var thetaG=theta,phiG=phi,radiusG=radius,userZoomed=false;
  var R_MIN=2.8,R_MAX=230;
  // 底部卡片让位：用视口偏移把地球整体上移，避免被知识卡片遮挡
  var cardK=0,cardKT=0;
  function cardShift(){return Math.max(56,Math.min(100,H*0.11));}
  function setCardMode(min){cardKT=min?cardShift()*0.35:cardShift();}
  function camPos(){var sp=Math.sin(phi);
    camera.position.set(radius*sp*Math.sin(theta),radius*Math.cos(phi),radius*sp*Math.cos(theta));
    camera.lookAt(0,0,0);
    cardK+=(cardKT-cardK)*0.12;
    if(cardK>0.5)camera.setViewOffset(W,H,0,cardK,W,H);else camera.clearViewOffset();
  }

  /* 手势：单指旋转 / 双指缩放，两者互斥。
   * 触屏上 pointer* 与 touch* 是并行发出的两套事件，而旧版只用一个裸 dragging 布尔、
   * 不区分是哪根手指 —— 双指按下时两根手指各发各的 pointermove、都去改 thetaG/phiG，
   * 且 lx/ly 被两指轮流覆盖（算出来的是跨手指的巨大位移），画面就在两指之间来回跳。
   * 现在每根手指单独记坐标，只有「屏上仅一根手指」时旋转。 */
  var pointers={},dragId=null,pinch=0;
  function pCount(){var n=0,k;for(k in pointers)if(pointers[k])n++;return n;}
  function armDrag(id){dragId=id;lx=pointers[id].x;ly=pointers[id].y;}
  function stopDrag(){dragId=null;}
  function tdist(t){return Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY);}
  cv.addEventListener('pointerdown',function(e){
    pointers[e.pointerId]={x:e.clientX,y:e.clientY};
    if(pCount()>1){stopDrag();return;}                 // 第二指落下：旋转让位给缩放
    armDrag(e.pointerId);
    cv.setPointerCapture(e.pointerId);
  });
  function onPointerEnd(e){
    delete pointers[e.pointerId];
    if(dragId===e.pointerId)stopDrag();
    try{cv.releasePointerCapture(e.pointerId)}catch(_){}
    var n=pCount();
    if(n===0){stopDrag();return;}
    if(n===1){for(var id in pointers)if(pointers[id]){armDrag(Number(id));break;}}   // 缩放抬起一指：剩下那根接回旋转
  }
  cv.addEventListener('pointerup',onPointerEnd);
  cv.addEventListener('pointercancel',onPointerEnd);
  cv.addEventListener('pointermove',function(e){
    var p=pointers[e.pointerId];if(!p)return;
    p.x=e.clientX;p.y=e.clientY;
    if(e.pointerId!==dragId)return;
    if(pCount()>1){stopDrag();return;}                 // 兜底：漏掉 pointerdown 时也不旋转
    var dx=e.clientX-lx,dy=e.clientY-ly;lx=e.clientX;ly=e.clientY;
    thetaG-=dx*0.005;phiG-=dy*0.005;phiG=Math.max(0.08,Math.min(Math.PI-0.08,phiG));
  });
  cv.addEventListener('wheel',function(e){e.preventDefault();radiusG*=1+Math.sign(e.deltaY)*0.08;radiusG=Math.max(R_MIN,Math.min(R_MAX,radiusG));userZoomed=true;},{passive:false});
  cv.addEventListener('touchstart',function(e){if(e.touches.length===2){stopDrag();pinch=tdist(e.touches);}},{passive:true});
  cv.addEventListener('touchend',function(e){if(e.touches.length<2)pinch=0;},{passive:true});   // 清基线：下次双指重新按下按当下指距起算
  cv.addEventListener('touchcancel',function(){pinch=0;},{passive:true});
  /* 两指几乎重合时 d→0，pinch/d 会炸成天文数字把镜头甩飞；12px 以内只更新基线不缩放 */
  cv.addEventListener('touchmove',function(e){if(e.touches.length!==2)return;e.preventDefault();var d=tdist(e.touches);if(pinch>12&&d>12){radiusG*=pinch/d;radiusG=Math.max(R_MIN,Math.min(R_MAX,radiusG));userZoomed=true;}pinch=d;},{passive:false});

  // ===== 科普内容 =====
  var MODES={
    overview:{name:'蓝色星球',color:'#4a90e2',
      desc:'地球是目前已知唯一存在生命的行星。表面约 71% 被海洋覆盖，大气层与适宜的温度让液态水得以留存，也孕育了丰富的生命。',
      meta:['半径 6371 km','年龄 ≈46 亿年','海洋覆盖 71%','日地距离 1.5 亿 km']},
    seasons:{name:'四季成因',color:'#7ec850',
      desc:'地轴倾斜约 23.5°，且公转过程中地轴指向保持不变，使太阳直射点在南北回归线之间周年移动，于是有了四季更替。',
      meta:['地轴倾角 23.5°','公转周期 365.25 天','夏至 直射北回归线','冬至 直射南回归线']},
    moon:{name:'地月系统',color:'#cfd8e6',
      desc:'月球自己不发光，月光是它反射的太阳光。月球绕地球公转时，被太阳照亮的一半相对地球不断改变朝向，我们便看到月面由缺变圆、又由圆变缺——这就是月相。',
      meta:['朔望月 29.53 天','公转 27.3 天','地月距离 38.4 万 km','月球直径 3476 km']},
    layers:{name:'地球内部',color:'#ff7a3c',
      desc:'把地球切开看一看：薄薄的地壳之下是近 2900 km 厚的地幔，再往下是液态的外核与固态的内核。越往深处，温度和压力越高。',
      meta:['地壳 平均约 17 km','地幔 至 2900 km','外核 液态铁镍','内核 ≈5500°C 固态']},
    grid:{name:'经纬网格',color:'#5cc8ff',
      desc:'人们在地球表面编织经纬网来确定位置：赤道是 0° 纬线，本初子午线是 0° 经线。回归线与极圈标记着太阳直射和极昼极夜的边界。',
      meta:['赤道 0° 纬线','回归线 南北纬 23.5°','极圈 南北纬 66.5°','本初子午线 0° 经线']}
  };

  // ===== 标签 =====
  var tags=[];
  function addTag(obj,text,mode,nrm,ctr){
    var el=document.createElement('div');el.className='tag';el.textContent=text;el.style.opacity='0';
    document.body.appendChild(el);
    tags.push({obj:obj,el:el,mode:mode,nrm:nrm||null,ctr:ctr||null});
  }
  (function(){
    var defs=[['赤道',0,-30],['北回归线',23.5,55],['南回归线',-23.5,120],['北极圈',66.5,-70],['南极圈',-66.5,-120],['本初子午线',52,0]];
    defs.forEach(function(d){var o=new THREE.Object3D();o.position.copy(ll2v(d[1],d[2],R*1.03));gridGroup.add(o);addTag(o,d[0],'grid','self');});
  })();
  (function(){
    // 四个锚点都落在面向相机的剖切面上，且各自位于对应层内。
    // 按「由外到内」的顺序定义，屏幕上下顺序与之保持一致；剖切面是平面，
    // 可见性用面法线判断（径向方向在平面边缘会误判）。
    var faceN=new THREE.Vector3(-s40,0,c40);
    addTag(layerAnchor(R*1.00,95),'地壳 · 0–17 km','layers',faceN);
    addTag(layerAnchor(R*0.78,55),'地幔 · 17–2900 km','layers',faceN);
    addTag(layerAnchor(R*0.38,10),'外核 · 2900–5150 km','layers',faceN);
    addTag(layerAnchor(R*0.19,-35),'内核 · 5150–6371 km','layers',faceN);
  })();
  addTag(seasonAnchor(0,-ORBIT),'春分 · 3月21日前后','seasons');
  addTag(seasonAnchor(ORBIT,0),'夏至 · 6月21日前后','seasons');
  addTag(seasonAnchor(0,ORBIT),'秋分 · 9月23日前后','seasons');
  addTag(seasonAnchor(-ORBIT,0),'冬至 · 12月22日前后','seasons');
  addTag(zhi,'太阳直射点','seasons','self',orbitGroup);
  (function(){
    addTag(earthAnchor,'地球','moon');
  })();

  // ===== 模式切换 =====
  var cur='overview';
  var playing=true,showLabel=true,showStars=true,showClouds=true,showOrbit=true,speedMul=1;
  function setMode(m){
    cur=m;userZoomed=false;
    var p=PRESETS[m]();thetaG=p[0];phiG=p[1];radiusG=p[2];
    mainTilt.visible=(m==='overview'||m==='grid');
    layersGroup.visible=(m==='layers');
    seasonsGroup.visible=(m==='seasons');
    moonGroup.visible=(m==='moon');
    gridGroup.visible=(m==='grid');
    clouds.visible=showClouds&&(m==='overview');
    mClouds.visible=showClouds&&(m==='moon');
    seasonOrbitLine.visible=showOrbit;moonOrbitLine.visible=showOrbit;
    mainTilt.rotation.z=23.5*Math.PI/180;
    sunLight.visible=(m!=='moon');
    if(m==='seasons'){ambient.intensity=0.35;sunLight.intensity=2.6;sunLight.position.set(0,0,0);}
    // 地月模式压暗环境光 → 月球未被照亮的一半黑下来，月相形状才立得住
    else if(m==='moon'){ambient.intensity=0.26;}
    else if(m==='layers'){ambient.intensity=0.75;sunLight.intensity=2.0;sunLight.position.set(-26,14,6);}
    else{ambient.intensity=0.5;sunLight.intensity=2.4;sunLight.position.set(38,12,22);}
    document.getElementById('phase').classList.toggle('show',m==='moon');
    if(m==='moon')updatePhase();
    var d=MODES[m],card=document.getElementById('card');
    card.classList.add('show');
    document.getElementById('cName').textContent=d.name;
    document.getElementById('cDot').style.background=d.color;
    document.getElementById('cDesc').textContent=d.desc;
    document.getElementById('cMeta').innerHTML=d.meta.map(function(t){return '<span>'+t+'</span>';}).join('');
    var btns=document.querySelectorAll('#dock button');
    for(var i=0;i<btns.length;i++)btns[i].classList.toggle('on',btns[i].getAttribute('data-m')===m);
  }
  document.querySelectorAll('#dock button').forEach(function(b){
    b.addEventListener('click',function(){setMode(b.getAttribute('data-m'));});
  });
  // 窄屏放不下时两端渐隐，提示这里可以横向滑动
  var dockEl=document.getElementById('dock');
  function dockFade(){dockEl.classList.toggle('scrollable',dockEl.scrollWidth>dockEl.clientWidth+1);}
  dockEl.addEventListener('scroll',dockFade);
  addEventListener('resize',dockFade);
  dockFade();setTimeout(dockFade,400);

  // ===== 设置 =====
  function bind(id,fn){var el=document.getElementById(id);el.addEventListener('click',function(){el.classList.toggle('on');fn(el.classList.contains('on'));});}
  bind('swPlay',function(v){playing=v;});
  bind('swLabel',function(v){showLabel=v;});
  bind('swStars',function(v){showStars=v;stars.visible=v;sky.visible=v;});
  bind('swClouds',function(v){showClouds=v;clouds.visible=v&&(cur==='overview');mClouds.visible=v&&(cur==='moon');});
  bind('swOrbit',function(v){showOrbit=v;seasonOrbitLine.visible=v;moonOrbitLine.visible=v;});
  var spEl=document.getElementById('speed'),vSp=document.getElementById('vSpeed');
  spEl.addEventListener('input',function(){speedMul=spEl.value/100;vSp.textContent=speedMul.toFixed(1)+'×';});
  document.getElementById('bReset').addEventListener('click',function(){var p=PRESETS[cur]();thetaG=p[0];phiG=p[1];radiusG=p[2];userZoomed=false;});
  document.getElementById('bTop').addEventListener('click',function(){phiG=0.02;});
  var sheet=document.getElementById('sheet'),scrim=document.getElementById('scrim');
  function openSheet(v){sheet.classList.toggle('show',v);scrim.classList.toggle('show',v);}
  document.getElementById('gear').addEventListener('click',function(){openSheet(true);});
  document.getElementById('sClose').addEventListener('click',function(){openSheet(false);});
  scrim.addEventListener('click',function(){openSheet(false);});

  // 知识卡片常驻展开（折叠功能已移除）

  // ===== 标签投影 =====
  var _v=new THREE.Vector3(),_c=new THREE.Vector3(),_n=new THREE.Vector3(),_d=new THREE.Vector3();
  // 引线层：标签被推开后，从锚点连一条细线指向标签
  var SVGNS='http://www.w3.org/2000/svg';
  var leaders=document.createElementNS(SVGNS,'svg');
  leaders.setAttribute('class','leaders');
  document.body.appendChild(leaders);
  var _lines=[];
  function leaderLine(i){
    var l=_lines[i];
    if(!l){l=document.createElementNS(SVGNS,'line');l.setAttribute('stroke','rgba(150,185,235,.55)');l.setAttribute('stroke-width','1');l.setAttribute('stroke-dasharray','3 3');leaders.appendChild(l);_lines[i]=l;}
    return l;
  }
  var _items=[];
  function collectTags(){
    _items.length=0;
    for(var i=0;i<tags.length;i++){
      var tg=tags[i],el=tg.el;
      if(tg.mode!==cur||!showLabel){el.style.opacity='0';continue;}
      _v.setFromMatrixPosition(tg.obj.matrixWorld);_v.project(camera);
      if(_v.z>=1){el.style.opacity='0';continue;}
      if(tg.nrm){
        if(tg.nrm==='self'){
          tg.obj.getWorldPosition(_n);
          if(tg.ctr){tg.ctr.getWorldPosition(_c);_n.sub(_c);}
          _n.normalize();
        }else{_n.copy(tg.nrm);}
        if(tg.ctr){tg.ctr.getWorldPosition(_c);_d.copy(camera.position).sub(_c).normalize();}
        else{_d.copy(camera.position).normalize();}
        if(_n.dot(_d)<0.12){el.style.opacity='0';continue;}
      }
      if(!tg.w){var ww=el.offsetWidth,hh=el.offsetHeight;if(ww>0){tg.w=ww;tg.h=hh;}}
      _items.push({el:el,ax:(_v.x*0.5+0.5)*W,ay:(-_v.y*0.5+0.5)*H,w:tg.w||90,h:tg.h||18});
    }
  }
  function layoutTags(){
    var n=_items.length,i,j,it;
    var PAD=6,M=8; // 标签最小间距 / 视口边距
    // 初始位置即锚点投影；标签盒中心比锚点高 0.9 个字高（对应 .tag 的 translate(-50%,-140%)）
    for(i=0;i<n;i++){it=_items[i];it.cx=it.ax;it.cy=it.ay-it.h*0.9;}
    var cardEl=document.getElementById('card');
    var cr=cardEl.classList.contains('show')?cardEl.getBoundingClientRect():null;
    var ccx=0,ccy=0,cw=0,ch=0;
    if(cr){ccx=(cr.left+cr.right)*0.5;ccy=(cr.top+cr.bottom)*0.5;cw=cr.right-cr.left;ch=cr.bottom-cr.top;}
    // 只对「确实撞上」的标签做最小位移修正，不做整组平移：
    // 整组平移会让一个越界标签把同一模式下所有标签一起拖走（四季模式就是这么变形的）
    for(var pass=0;pass<4;pass++){
      // 标签互相重叠 → 沿重叠更小的方向对半推开
      for(i=0;i<n;i++)for(j=i+1;j<n;j++){
        var a=_items[i],b=_items[j];
        var ox=(a.w+b.w)*0.5+PAD-Math.abs(b.cx-a.cx);
        var oy=(a.h+b.h)*0.5+PAD-Math.abs(b.cy-a.cy);
        if(ox>0&&oy>0){
          if(ox<oy){var sx=(b.cx<a.cx?-1:1)*ox*0.5;a.cx-=sx;b.cx+=sx;}
          else{var sy=(b.cy<a.cy?-1:1)*oy*0.5;a.cy-=sy;b.cy+=sy;}
        }
      }
      // 被底部知识卡片遮住 → 往更近的一侧让开
      for(i=0;i<n;i++){
        it=_items[i];
        if(cr){
          var ox2=(it.w+cw)*0.5+10-Math.abs(ccx-it.cx);
          var oy2=(it.h+ch)*0.5+10-Math.abs(ccy-it.cy);
          if(ox2>0&&oy2>0){
            if(ox2<oy2)it.cx+=(it.cx<ccx?-1:1)*(ox2+2);
            else it.cy-=(oy2+2);
          }
        }
        // 视口边界（只收该标签自己）
        it.cx=Math.max(M+it.w*0.5,Math.min(W-M-it.w*0.5,it.cx));
        it.cy=Math.max(M+it.h*0.5,Math.min(H-M-it.h*0.5,it.cy));
      }
    }
    // 落位 + 引线（只在标签被挪开时画）
    var used=0;
    for(i=0;i<n;i++){
      it=_items[i];
      it.tx=it.cx;it.ty=it.cy+it.h*0.9;
      it.el.style.left=it.tx.toFixed(1)+'px';it.el.style.top=it.ty.toFixed(1)+'px';it.el.style.opacity='1';
      if(Math.abs(it.tx-it.ax)<3&&Math.abs(it.ty-it.ay)<3)continue;
      var rx0=it.cx-it.w*0.5,rx1=it.cx+it.w*0.5,ry0=it.cy-it.h*0.5,ry1=it.cy+it.h*0.5;
      var px=Math.max(rx0,Math.min(it.ax,rx1)),py=Math.max(ry0,Math.min(it.ay,ry1));
      if(px===it.ax&&py===it.ay){
        var dl=it.ax-rx0,dr=rx1-it.ax,dt=it.ay-ry0,db=ry1-it.ay,m=Math.min(dl,dr,dt,db);
        if(m===dl)px=rx0;else if(m===dr)px=rx1;else if(m===dt)py=ry0;else py=ry1;
      }
      var l=leaderLine(used++);
      l.setAttribute('x1',it.ax.toFixed(1));l.setAttribute('y1',it.ay.toFixed(1));
      l.setAttribute('x2',px.toFixed(1));l.setAttribute('y2',py.toFixed(1));
      l.style.display='';
    }
    for(i=used;i<_lines.length;i++)_lines[i].style.display='none';
  }
  function updateTags(){collectTags();layoutTags();}

  // ===== 月相指示器（站在地球上看到的月亮）=====
  // 亮面比例 k=(1+cos a)/2；晨昏线在视圆面上的投影是半轴为 r·|cos a| 的椭圆，
  // 半轴符号决定它是"缺"（凸向亮侧）还是"凸"（凹向亮侧）。
  var TAU=Math.PI*2;
  var pcv=document.getElementById('phaseCv'),pctx=pcv?pcv.getContext('2d'):null;
  var pNameEl=document.getElementById('phaseName'),pAgeEl=document.getElementById('phaseAge');
  var lastPName='';
  // 相位判定与 moon-3d 保持一致：四个关键相位收窄，过渡段给凸/眉月
  function phaseName(deg){
    var d=(deg%360+360)%360;
    if(d<8||d>352)return '新月';
    if(d<82)return '蛾眉月';
    if(d<98)return '上弦月';
    if(d<172)return '盈凸月';
    if(d<188)return '满月';
    if(d<262)return '亏凸月';
    if(d<278)return '下弦月';
    return '残月';
  }
  function updatePhase(){
    var a=((mAng%TAU)+TAU)%TAU;
    var k=(1+Math.cos(a))/2,waxing=a>Math.PI,t=-Math.cos(a);
    var age=((a-Math.PI)%TAU+TAU)%TAU/TAU*SYNODIC;
    var name=phaseName(age/SYNODIC*360);
    if(name!==lastPName){pNameEl.textContent=name;lastPName=name;}
    pAgeEl.textContent='月龄 '+age.toFixed(1)+' 天';
    if(!pctx)return;
    var S=pcv.width,cx=S/2,r=S*0.37;
    pctx.clearRect(0,0,S,S);
    pctx.beginPath();pctx.arc(cx,cx,r,0,TAU);
    pctx.fillStyle='rgba(206,222,246,.07)';pctx.fill();
    pctx.lineWidth=1.2;pctx.strokeStyle='rgba(150,180,220,.32)';pctx.stroke();
    if(k<0.005)return; // 新月：整面都是暗的
    pctx.save();pctx.translate(cx,cx);if(!waxing)pctx.scale(-1,1); // 北半球：盈月亮面在右
    pctx.beginPath();
    pctx.arc(0,0,r,-Math.PI/2,Math.PI/2,false);
    pctx.ellipse(0,0,r*Math.abs(t),r,0,Math.PI/2,-Math.PI/2,t>0);
    pctx.closePath();
    pctx.fillStyle='#eef1f7';pctx.shadowColor='rgba(190,214,255,.8)';pctx.shadowBlur=S*0.08;
    pctx.fill();
    pctx.restore();
  }

  // ===== 动画 =====
  var clock=new THREE.Clock();
  var running=true,perfAccum=0,perfCount=0,dprStep=DPR;
  var eSpin=2.68; // 初始让北京朝向默认相机
  var now=new Date(),doy=Math.floor((now-new Date(now.getFullYear(),0,0))/864e5);
  var seasonAng=((doy-172)/365.25)*Math.PI*2; // 按今天日期定位公转位置
  var EARTH_SPIN=0.7,SEASON_REV=0.07,MOON_REV=0.26,MOON_SPIN=0.35;
  var mAng=Math.PI*1.25,mSpinAng=0; // 初始停在新月之后的娥眉月位置
  function animate(){
    if(!running)return;
    requestAnimationFrame(animate);
    var dt=clock.getDelta(),t=performance.now()*0.001;
    if(playing){
      var s=dt*speedMul;
      eSpin+=s*EARTH_SPIN;seasonAng+=s*SEASON_REV;mAng+=s*MOON_REV;mSpinAng+=s*MOON_SPIN;
      mainSpin.rotation.y=eSpin;clouds.rotation.y=eSpin*1.12;
      seasonSpin.rotation.y=eSpin*2.2;
      orbitGroup.position.set(Math.cos(seasonAng)*ORBIT,0,Math.sin(seasonAng)*ORBIT);
      sun.rotation.y+=s*0.05;
      stars.rotation.y+=s*0.003;sky.rotation.y+=s*0.001;
    }
    // 地月系统：月球公转 + 潮汐锁定（始终以同一面朝向地球）+ 地球自转。
    // 潮汐锁定 = 自转角速度与公转相同；但 SphereGeometry 把贴图 u=0 贴在局部 -X、
    // u=0.5 贴在局部 +X，而 moon.jpg 是"正面（近地面）居中"的全月图，
    // 所以要让 +X 朝向地球，得在公转相位上再加 π —— 否则锁给地球的是背面。
    moonOrbit.position.copy(moonPosOn(mAng,MOON_ORBIT));
    moon.rotation.y=mAng+Math.PI;
    mSpin.rotation.y=mSpinAng;mClouds.rotation.y=mSpinAng*1.12;
    zhi.position.set(-Math.cos(seasonAng)*R*1.03,0,-Math.sin(seasonAng)*R*1.03);
    zhiDot.scale.setScalar(1+0.25*Math.sin(t*3.2));
    theta+=(thetaG-theta)*0.12;phi+=(phiG-phi)*0.12;radius+=(radiusG-radius)*0.1;
    camPos();
    renderer.render(scene,camera);
    updateTags();
    if(cur==='moon'&&(perfCount&1)===0)updatePhase();
    perfAccum+=dt;perfCount++;
    if(perfCount>=30){var avg=perfAccum/perfCount;perfAccum=0;perfCount=0;if(avg>0.04&&dprStep>1){dprStep=Math.max(1,dprStep-0.25);renderer.setPixelRatio(dprStep);renderer.setSize(W,H,false);}}
  }
  addEventListener('resize',function(){
    W=innerWidth;H=innerHeight;camera.aspect=W/H;camera.updateProjectionMatrix();renderer.setSize(W,H,false);
    if(!userZoomed){radiusG=PRESETS[cur]()[2];}
    setCardMode(false);
  });
  addEventListener('visibilitychange',function(){if(document.hidden){running=false;}else if(!running){running=true;clock.getDelta();animate();}});
  cv.addEventListener('webglcontextlost',function(e){e.preventDefault();running=false;document.getElementById('loader').classList.add('hide');document.getElementById('fallback').classList.add('show');},false);

  setMode('overview');
  setCardMode(false);
  animate();
  setTimeout(function(){document.getElementById('loader').classList.add('hide');},600);
  setTimeout(function(){var tp=document.getElementById('tip');tp.classList.add('show');setTimeout(function(){tp.classList.remove('show');},3400);},1400);
})();
