// ========== Three.js 初始化 ==========
let W=900,H=520;
function _rz3d(){var el=renderer.domElement;var r=el.getBoundingClientRect();if(r.width>0&&r.height>0){W=Math.round(r.width);H=Math.round(r.height);renderer.setSize(W,H);camera.aspect=W/H;camera.updateProjectionMatrix();}}
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(50,W/H,0.1,1000);
camera.position.set(0,2,9);
const renderer=new THREE.WebGLRenderer({antialias:true});
renderer.setSize(W,H);
renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
renderer.setClearColor(0xeef2f7,1);
document.getElementById('cv').style.display='none';
document.getElementById('hud').parentNode.insertBefore(renderer.domElement,document.getElementById('hud'));
renderer.domElement.style.borderRadius='14px';
renderer.domElement.style.width='100%';

// ========== 多光源系统（营造立体深度感）==========
scene.add(new THREE.HemisphereLight(0xffffff,0x94a3b8,0.4));
const keyLight=new THREE.DirectionalLight(0xffffff,0.8);
keyLight.position.set(6,8,8);scene.add(keyLight);
const fillLight=new THREE.DirectionalLight(0x93c5fd,0.3);
fillLight.position.set(-6,-2,4);scene.add(fillLight);
const rimLight=new THREE.DirectionalLight(0xfde68a,0.25);
rimLight.position.set(0,4,-8);scene.add(rimLight);

function clamp(v,a,b){return Math.max(a,Math.min(b,v));}

// ========== CPK 元素定义 ==========
const ELEM={
  H:{c:0xf0f0f0,glow:0xf8fafc,r:0.32},
  O:{c:0xe74c3c,glow:0xfca5a5,r:0.55},
  C:{c:0x334155,glow:0x64748b,r:0.5},
  N:{c:0x2d6cdf,glow:0x93c5fd,r:0.52},
  F:{c:0x27ae60,glow:0x86efac,r:0.45},
  B:{c:0xf5b041,glow:0xfcd34d,r:0.48}
};
const L=1.6;
const D2R=Math.PI/180;

// ========== 标签精灵 ==========
function label(text,color){
  const c=document.createElement('canvas');c.width=200;c.height=56;
  const ctx=c.getContext('2d');
  ctx.fillStyle='rgba(255,255,255,0.92)';ctx.fillRect(0,0,200,56);
  ctx.strokeStyle=color;ctx.lineWidth=3;ctx.strokeRect(2,2,196,52);
  ctx.fillStyle=color;ctx.font='600 24px -apple-system,"Microsoft YaHei",sans-serif';
  ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillText(text,100,30);
  const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),transparent:true,depthTest:false}));
  sp.scale.set(1.4,0.4,1);
  return sp;
}

function atomLabel(text,hexColor){
  const c=document.createElement('canvas');c.width=128;c.height=128;
  const ctx=c.getContext('2d');
  ctx.font='700 56px -apple-system,"Microsoft YaHei",sans-serif';
  ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.strokeStyle='rgba(255,255,255,0.85)';ctx.lineWidth=6;ctx.lineJoin='round';
  ctx.strokeText(text,64,64);
  ctx.fillStyle=hexColor;ctx.fillText(text,64,64);
  const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),transparent:true,depthTest:false}));
  sp.scale.set(0.55,0.55,1);
  return sp;
}

// ========== 分子定义 ==========
const M={
  H2O:{name:'H₂O',shape:'V形',angle:'104.5°',hyb:'sp³',lone:2,
    atoms:[{el:'O',pos:[0,0,0]},{el:'H',pos:[Math.sin(52.25*D2R)*L,Math.cos(52.25*D2R)*L,0]},{el:'H',pos:[-Math.sin(52.25*D2R)*L,Math.cos(52.25*D2R)*L,0]}],
    bonds:[{a:0,b:1,order:1},{a:0,b:2,order:1}]},
  CO2:{name:'CO₂',shape:'直线形',angle:'180°',hyb:'sp',lone:0,
    atoms:[{el:'C',pos:[0,0,0]},{el:'O',pos:[0,L,0]},{el:'O',pos:[0,-L,0]}],
    bonds:[{a:0,b:1,order:2},{a:0,b:2,order:2}]},
  CH4:{name:'CH₄',shape:'正四面体',angle:'109.5°',hyb:'sp³',lone:0,
    atoms:(()=>{const v=[[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]];const a=[{el:'C',pos:[0,0,0]}];v.forEach(p=>{const n=Math.sqrt(3);a.push({el:'H',pos:[p[0]/n*L,p[1]/n*L,p[2]/n*L]});});return a;})(),
    bonds:[{a:0,b:1,order:1},{a:0,b:2,order:1},{a:0,b:3,order:1},{a:0,b:4,order:1}]},
  NH3:{name:'NH₃',shape:'三角锥形',angle:'107°',hyb:'sp³',lone:1,
    atoms:(()=>{const cosT=0.3721,sinT=0.9282;const phis=[0,120,240];const a=[{el:'N',pos:[0,0,0]}];phis.forEach(ph=>{a.push({el:'H',pos:[sinT*Math.cos(ph*D2R)*L, sinT*Math.sin(ph*D2R)*L, -cosT*L]});});return a;})(),
    bonds:[{a:0,b:1,order:1},{a:0,b:2,order:1},{a:0,b:3,order:1}]},
  BF3:{name:'BF₃',shape:'平面三角形',angle:'120°',hyb:'sp²',lone:0,
    atoms:(()=>{const phis=[0,120,240];const a=[{el:'B',pos:[0,0,0]}];phis.forEach(ph=>{a.push({el:'F',pos:[Math.cos(ph*D2R)*L,Math.sin(ph*D2R)*L,0]});});return a;})(),
    bonds:[{a:0,b:1,order:1},{a:0,b:2,order:1},{a:0,b:3,order:1}]},
  C2H4:{name:'C₂H₄',shape:'平面型',angle:'120°',hyb:'sp²',lone:0,
    atoms:[
      {el:'C',pos:[-L,0,0]},{el:'C',pos:[L,0,0]},
      {el:'H',pos:[-L-L*0.5, L*0.866,0]},{el:'H',pos:[-L-L*0.5,-L*0.866,0]},
      {el:'H',pos:[ L+L*0.5, L*0.866,0]},{el:'H',pos:[ L+L*0.5,-L*0.866,0]}
    ],
    bonds:[{a:0,b:1,order:2},{a:0,b:2,order:1},{a:0,b:3,order:1},{a:1,b:4,order:1},{a:1,b:5,order:1}]}
};

// ========== 创建原子（CPK材质 + 外发光层）==========
function createAtom(el,scale){
  const e=ELEM[el];
  const r=Math.max(e.r*scale,0.05);
  const group=new THREE.Group();
  // 主体球
  const mesh=new THREE.Mesh(
    new THREE.SphereGeometry(r,32,28),
    new THREE.MeshPhongMaterial({
      color:e.c,shininess:el==='H'?50:90,specular:0x555555,
      emissive:e.c,emissiveIntensity:0.06
    })
  );
  group.add(mesh);
  // 外发光层
  const glow=new THREE.Mesh(
    new THREE.SphereGeometry(r*1.18,24,20),
    new THREE.MeshBasicMaterial({color:e.glow,transparent:true,opacity:0.12,depthWrite:false})
  );
  group.add(glow);
  group.userData.mesh=mesh;
  group.userData.glow=glow;
  group.userData.baseR=r;
  return group;
}

// ========== 创建化学键（顶点色渐变 A→B）==========
function createBond(p1,p2,el1,el2,order){
  const dir=new THREE.Vector3().subVectors(p2,p1);
  const len=Math.max(dir.length(),0.001);
  const mid=new THREE.Vector3().copy(p1).add(p2).multiplyScalar(0.5);
  const c1=new THREE.Color(ELEM[el1].c);
  const c2=new THREE.Color(ELEM[el2].c);
  const group=new THREE.Group();

  const mkCyl=(off)=>{
    const geo=new THREE.CylinderGeometry(0.08,0.08,len,18,1,false);
    // 顶点色渐变
    const positions=geo.attributes.position;
    const colors=new Float32Array(positions.count*3);
    for(let i=0;i<positions.count;i++){
      const y=positions.getY(i);
      const t=clamp((y+len/2)/len,0,1);
      const c=c1.clone().lerp(c2,t);
      colors[i*3]=c.r;colors[i*3+1]=c.g;colors[i*3+2]=c.b;
    }
    geo.setAttribute('color',new THREE.BufferAttribute(colors,3));
    const mat=new THREE.MeshPhongMaterial({vertexColors:true,shininess:60,specular:0x444444});
    const cyl=new THREE.Mesh(geo,mat);
    cyl.position.copy(mid);
    if(off!==0){
      let perp=new THREE.Vector3(0,0,1).cross(dir);
      if(perp.length()<0.01)perp=new THREE.Vector3(1,0,0).cross(dir);
      perp.normalize();
      cyl.position.add(perp.multiplyScalar(off));
    }
    cyl.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),dir.clone().normalize());
    return cyl;
  };

  if(order>=2){group.add(mkCyl(0.16));group.add(mkCyl(-0.16));}
  else group.add(mkCyl(0));
  return group;
}

// ========== 孤电子对可视化 ==========
function createLonePairs(centerPos,bondDirs,loneCount,atomRadius){
  const group=new THREE.Group();
  if(loneCount===0)return group;

  // 孤电子对方向 = 键方向之和的反方向
  const sum=new THREE.Vector3();
  bondDirs.forEach(d=>sum.add(d));
  const baseDir=sum.negate().normalize();

  // 垂直参考向量
  let perp=new THREE.Vector3(0,0,1).cross(baseDir);
  if(perp.length()<0.1)perp=new THREE.Vector3(1,0,0).cross(baseDir);
  perp.normalize();

  const dirs=[];
  if(loneCount===1){
    dirs.push(baseDir);
  }else{
    const spread=35*D2R;
    dirs.push(baseDir.clone().applyAxisAngle(perp,spread).normalize());
    dirs.push(baseDir.clone().applyAxisAngle(perp,-spread).normalize());
    for(let i=2;i<loneCount;i++){
      dirs.push(baseDir.clone());
    }
  }

  const lpDist=atomRadius*1.35;
  dirs.forEach(dir=>{
    const cloudPos=centerPos.clone().add(dir.clone().multiplyScalar(lpDist));
    // 两个小圆点表示一对电子
    const dotPerp=perp.clone();
    for(let j=0;j<2;j++){
      const offset=dotPerp.clone().multiplyScalar(j===0?0.12:-0.12);
      const dot=new THREE.Mesh(
        new THREE.SphereGeometry(0.1,16,14),
        new THREE.MeshPhongMaterial({
          color:0x6366f1,emissive:0x6366f1,emissiveIntensity:0.35,
          transparent:true,opacity:0.7,shininess:80
        })
      );
      dot.position.copy(cloudPos).add(offset);
      group.add(dot);
    }
    // 云雾包裹
    const cloud=new THREE.Mesh(
      new THREE.SphereGeometry(0.22,16,14),
      new THREE.MeshBasicMaterial({color:0x818cf8,transparent:true,opacity:0.1,depthWrite:false})
    );
    cloud.position.copy(cloudPos);
    group.add(cloud);
  });
  return group;
}

// ========== 键角弧线 ==========
function createAngleArc(center,dir1,dir2,radius,color){
  const dot=clamp(dir1.dot(dir2),-1,1);
  const angle=Math.acos(dot);
  if(angle<0.05||angle>Math.PI-0.05)return null;
  const segments=Math.max(12,Math.floor(angle*24));
  const points=[];
  for(let i=0;i<=segments;i++){
    const t=i/segments;
    const sinO=Math.sin(angle);
    const a=Math.sin((1-t)*angle)/sinO;
    const b=Math.sin(t*angle)/sinO;
    const p=dir1.clone().multiplyScalar(a).add(dir2.clone().multiplyScalar(b));
    p.multiplyScalar(radius).add(center);
    points.push(p);
  }
  const geo=new THREE.BufferGeometry().setFromPoints(points);
  const mat=new THREE.LineBasicMaterial({color:color,transparent:true,opacity:0.6});
  return new THREE.Line(geo,mat);
}

// ========== 构建/重建分子 ==========
const molGroup=new THREE.Group();scene.add(molGroup);
let curKey='H2O',atomScale=1.0;
let atomGroups=[];
let vibTime=0;

function build(){
  while(molGroup.children.length){
    const c=molGroup.children[0];
    molGroup.remove(c);
    if(c.geometry)c.geometry.dispose();
    if(c.material){
      if(Array.isArray(c.material))c.material.forEach(m=>m.dispose());
      else c.material.dispose();
    }
  }
  const m=M[curKey];
  atomGroups=[];
  const centerAtom=m.atoms[0];
  const centerPos=new THREE.Vector3(...centerAtom.pos);

  // 创建原子
  m.atoms.forEach((at,i)=>{
    const ag=createAtom(at.el,atomScale);
    ag.position.set(...at.pos);
    ag.userData.basePos=new THREE.Vector3(...at.pos);
    ag.userData.el=at.el;
    ag.userData.vibPhase=i*1.7;
    ag.userData.vibAmp=at.el===centerAtom.el?0.012:0.02;
    molGroup.add(ag);
    atomGroups.push(ag);

    // 元素标签
    const hex='#'+ELEM[at.el].c.toString(16).padStart(6,'0');
    const lbColor=at.el==='H'?'#94a3b8':at.el==='C'?'#475569':hex;
    const al=atomLabel(at.el,lbColor);
    al.position.set(0,0,0);
    ag.add(al);
  });

  // 创建化学键
  m.bonds.forEach(b=>{
    const p1=new THREE.Vector3(...m.atoms[b.a].pos);
    const p2=new THREE.Vector3(...m.atoms[b.b].pos);
    const bondGroup=createBond(p1,p2,m.atoms[b.a].el,m.atoms[b.b].el,b.order);
    molGroup.add(bondGroup);
  });

  // 孤电子对
  if(m.lone>0){
    const bondDirs=[];
    m.bonds.forEach(b=>{
      let otherIdx,centralIdx;
      if(b.a===0){centralIdx=0;otherIdx=b.b;}
      else if(b.b===0){centralIdx=0;otherIdx=b.a;}
      else return;
      const d=new THREE.Vector3(...m.atoms[otherIdx].pos)
        .sub(new THREE.Vector3(...m.atoms[centralIdx].pos)).normalize();
      bondDirs.push(d);
    });
    const lp=createLonePairs(centerPos,bondDirs,m.lone,ELEM[centerAtom.el].r*atomScale);
    molGroup.add(lp);
  }

  // 键角弧线（前两个键之间的角度）
  if(m.bonds.length>=2){
    const b0=m.bonds[0],b1=m.bonds[1];
    const cIdx=0;
    const d0=new THREE.Vector3(...m.atoms[b0.a===0?b0.b:b0.a].pos).sub(centerPos).normalize();
    const d1=new THREE.Vector3(...m.atoms[b1.a===0?b1.b:b1.a].pos).sub(centerPos).normalize();
    const arcR=ELEM[centerAtom.el].r*atomScale+0.35;
    const arc=createAngleArc(centerPos,d0,d1,arcR,0xb45309);
    if(arc)molGroup.add(arc);
  }

  // 键角文字标签
  const angleLb=label(m.angle,'#b45309');
  const labelOffset=m.atoms.length<=3?1.6:1.8;
  angleLb.position.set(centerPos.x,centerPos.y+labelOffset,centerPos.z);
  molGroup.add(angleLb);

  // 居中到原点
  const all=m.atoms.map(a=>new THREE.Vector3(...a.pos));
  const cen=new THREE.Vector3();
  all.forEach(v=>cen.add(v));
  cen.multiplyScalar(1/Math.max(all.length,1));
  molGroup.position.set(-cen.x,-cen.y,-cen.z);
}
build();

// ========== 拖拽旋转 ==========
let angleY=0.6,angleX=0.35,dragging=false,lx=0,ly=0,autoRot=false;
const el=renderer.domElement;
el.addEventListener('mousedown',e=>{dragging=true;lx=e.clientX;ly=e.clientY;});
window.addEventListener('mouseup',()=>dragging=false);
window.addEventListener('mousemove',e=>{if(!dragging)return;angleY+=(e.clientX-lx)*0.008;angleX+=(e.clientY-ly)*0.008;angleX=clamp(angleX,-1.2,1.2);lx=e.clientX;ly=e.clientY;});
el.addEventListener('touchstart',e=>{dragging=true;lx=e.touches[0].clientX;ly=e.touches[0].clientY;},{passive:true});
window.addEventListener('touchend',()=>dragging=false);
window.addEventListener('touchmove',e=>{if(!dragging||!e.touches[0])return;angleY+=(e.touches[0].clientX-lx)*0.008;angleX+=(e.touches[0].clientY-ly)*0.008;angleX=clamp(angleX,-1.2,1.2);lx=e.touches[0].clientX;ly=e.touches[0].clientY;},{passive:true});

// ========== 动画循环（含分子振动）==========
function animate(){
  requestAnimationFrame(animate);
  vibTime+=0.016;

  // 分子振动效果
  atomGroups.forEach(ag=>{
    const phase=ag.userData.vibPhase;
    const amp=ag.userData.vibAmp;
    const base=ag.userData.basePos;
    ag.position.set(
      base.x+Math.sin(vibTime*3+phase)*amp,
      base.y+Math.cos(vibTime*2.7+phase*1.3)*amp,
      base.z+Math.sin(vibTime*3.3+phase*0.7)*amp
    );
  });

  if(autoRot)angleY+=0.004;
  const r=9;
  camera.position.x=Math.sin(angleY)*Math.cos(angleX)*r;
  camera.position.y=Math.sin(angleX)*r;
  camera.position.z=Math.cos(angleY)*Math.cos(angleX)*r;
  camera.lookAt(0,0,0);
  renderer.render(scene,camera);
}
animate();

// ========== UI 交互 ==========
const narrMap={
  H2O:'根据<span class="hl">价层电子对互斥模型(VSEPR)</span>，中心氧有 <span class="hl">2 对孤电子对</span>，挤压成键电子对，使 H₂O 呈 <span class="hl2">V 形</span>，键角被压缩到 104.5°。',
  CO2:'CO₂ 中碳为 <span class="hl">sp 杂化</span>，无孤电子对，两个双键电子对相互排斥至最远，分子呈<span class="hl2">直线形</span>，键角 180°。',
  CH4:'甲烷碳为 <span class="hl">sp³ 杂化</span>，4 个 C-H 键电子对等价排斥，形成<span class="hl2">正四面体</span>，键角 109.5°。',
  NH3:'氨分子氮为 sp³ 杂化，但有 <span class="hl">1 对孤电子对</span>占据一个杂化轨道，挤压成键电子对，使 NH₃ 呈<span class="hl2">三角锥形</span>，键角 107°。',
  BF3:'BF₃ 中硼为 <span class="hl">sp² 杂化</span>，无孤电子对，3 个 B-F 键均匀分布于平面，呈<span class="hl2">平面三角形</span>，键角 120°。',
  C2H4:'乙烯中每个碳为 <span class="hl">sp² 杂化</span>，C=C 双键与两个 C-H 键共面，键角约 120°，分子整体<span class="hl2">平面型</span>，存在π键不能旋转。'
};
function setMol(key,btn){
  curKey=key;
  Object.keys(M).forEach(k=>document.getElementById('mol-'+k).classList.remove('active'));
  btn.classList.add('active');
  const m=M[key];
  document.getElementById('hud-mol').textContent=m.name;
  document.getElementById('hud-shape').textContent=m.shape;
  document.getElementById('hud-angle').textContent=m.angle;
  document.getElementById('hud-hyb').textContent=m.hyb;
  document.getElementById('r-formula').textContent=m.name;
  document.getElementById('r-shape').textContent=m.shape;
  document.getElementById('r-angle').textContent=m.angle;
  document.getElementById('r-hyb').textContent=m.hyb;
  document.getElementById('r-lone').textContent=m.lone;
  document.getElementById('narr-text').innerHTML=narrMap[key];
  build();
}
Object.keys(M).forEach(k=>{
  document.getElementById('mol-'+k).addEventListener('click',e=>setMol(k,e.target));
});
const sizeS=document.getElementById('size'),szV=document.getElementById('sz-val');
sizeS.addEventListener('input',()=>{atomScale=sizeS.value/100;szV.textContent=atomScale.toFixed(2);build();});
document.getElementById('reset').addEventListener('click',()=>{angleY=0.6;angleX=0.35;});
const autoBtn=document.getElementById('auto');
autoBtn.addEventListener('click',()=>{autoRot=!autoRot;autoBtn.textContent=autoRot?'停止旋转':'自动旋转';autoBtn.classList.toggle('primary',autoRot);});
_rz3d();if(window.ResizeObserver)new ResizeObserver(_rz3d).observe(renderer.domElement);addEventListener('resize',_rz3d);

